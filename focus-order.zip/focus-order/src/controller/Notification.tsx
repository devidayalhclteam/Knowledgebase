export const Notification = (text: string): void => {
	figma.notify(text)
}
