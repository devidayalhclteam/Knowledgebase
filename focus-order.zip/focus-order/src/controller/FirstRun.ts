import { MessageType } from './MessageType'

export const storageID = 'Microsoft-FocusOrder-FirstRun'

/** User has seen FRE (First run experience) */
export const SetFirstRunStorage = () => {
	figma.clientStorage.setAsync(storageID, true)
}

/** Check storage to see if user has seen first run experience */
export const CheckForFirstRun = async (): Promise<void> => {
	const result = await figma.clientStorage.getAsync(storageID)

	// Send message to Plugin
	figma.ui.postMessage({
		type: MessageType.IsFirstRun,
		isCompleted: result,
	})
}
