/** Post message handling  */
export enum MessageType {
	IsFirstRun,
	/** Get annotation list from scene */
	Annotations,
	/** Create new annotation(s).  Users can multiselect and create multiple annotations at once */
	NewAnnotations,
	/** Update annotations in the scene */
	UpdateSet,
	/** Delete an annotation set in the scene */
	DeleteSet,
	/** Move viewport to selected annotation */
	SelectAnnotation,
	/** Load annotations when user opens the plugin */
	LoadAnnotations,
	/** Display notification */
	Notification,
}
