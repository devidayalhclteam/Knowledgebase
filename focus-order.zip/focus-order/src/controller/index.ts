import { CheckForFirstRun, SetFirstRunStorage } from './FirstRun'
import { Init } from './Init'
import { NewAnnotations } from './NewAnnotations'
import { MessageType } from './MessageType'
import { UpdateSet } from './UpdateSet'
import { SelectAnnotation } from './SelectAnnotation'
import { IAnnotation, ISet } from './IAnnotation'
import { DeleteSet } from './DeleteSet'
import { LoadAnnotations } from './LoadAnnotations'
import { Notification } from './Notification'
/* Initiate Plugin */
Init()

/* Runs before Plugin closes */
figma.on('close', () => {
	SetFirstRunStorage()
})

/*
 * Listen for post messages from the plugin
 * Enums break when sent
 */
figma.ui.onmessage = (pluginMessage: {
	type: MessageType | string
	list?: IAnnotation[]
	id?: string
	text?: string
	scrollIntoView?: boolean
	set?: ISet
	newParentContainer?: string
}) => {
	try {
		switch (pluginMessage.type) {
			case MessageType.LoadAnnotations:
				CheckForFirstRun()
				LoadAnnotations()
				break
			case MessageType.NewAnnotations:
				NewAnnotations({ set: pluginMessage.set })
				break
			case MessageType.UpdateSet:
				UpdateSet({ list: pluginMessage.list, setId: pluginMessage.id, newParentContainer: pluginMessage.newParentContainer })
				break
			case MessageType.DeleteSet:
				DeleteSet({ id: pluginMessage.id })
				break
			case MessageType.SelectAnnotation:
				SelectAnnotation({ id: pluginMessage.id, scrollIntoView: pluginMessage.scrollIntoView })
				break
			case MessageType.Notification:
				Notification(pluginMessage.text)
				break
			default:
				break
		}
	} catch (err) {
		console.warn(pluginMessage.type, err)
	}
}
