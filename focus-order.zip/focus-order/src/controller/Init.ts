
export const Init = () => {
	/*
	 * Call Figma to show a UI panel with the contents of __html__ global at our desrired width & height
	 */
	figma.showUI(__html__, { width: 304, height: 528 })
	
}
