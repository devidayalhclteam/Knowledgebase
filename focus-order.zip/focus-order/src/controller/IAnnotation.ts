import { ComponentType, PropertyTypes } from 'ui/components/CurrentAnnotations/Edit/Role'
import { IRGB } from 'ui/components/Shared/ColorPicker/utilities/consts'

export interface IAnnotation {
	/** This is the layer id.  Example 247:37 */
	id: string
	name: string
	component?: ComponentType
	role: string
	value: string | PropertyTypes[]
	properties: PropertyTypes[]
	description?: string
	set: ISet
}

export interface ISet {
	/** This is the id we generate for the set based on timestamp */
	id: string
	name: string
	artboard: IArtboard
	color: IRGBA
	date: string
	coordinates?: ICoordinates
}

export interface IArtboard {
	id: string
	name: string
}

export interface ICoordinates {
	/** This is the layer id.  Example 247:37 */
	id: string
	x: number
	y: number
	width: number
	height: number
}

export interface IRGBA extends IRGB {
	a: number
}
