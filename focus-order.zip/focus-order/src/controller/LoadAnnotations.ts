import { annotationLayerName, CreateAnnotations } from './CreateAnnotations'
import { CreateReadout, readoutLayerName } from './CreateReadout'
import { MessageType } from './MessageType'
import { IAnnotation, ICoordinates, ISet } from './IAnnotation'
import { Sanitize } from 'ui/components/Shared/Sanitize'
import { GetParentArtboard } from './NewAnnotations'
import { defaultAnnotationColor } from 'ui/components/Shared/SharedColors'
import { ComponentType } from 'ui/components/CurrentAnnotations/Edit/Role'

/**
 * 	User may have shifted layout sizes and shapes,
 * 	we want to reload all annotations and readouts so that they are positioned correctly
 */
export const LoadAnnotations = async () => {
	let annotationList: IAnnotation[] = GetExistingData()

	if (annotationList?.length) {
		// Send annotations to plugin
		figma.ui.postMessage({
			type: MessageType.Annotations,
			annotations: annotationList,
		})

		/** Group annotation sets together */
		annotationList.sort((a, b) => Number(a.set.id) - Number(b.set.id))

		/** Add readout coords to annotation sets */
		// Get coords here before they are deleted in the next step
		annotationList = AddCoordsToSets(annotationList)

		/** Find/Remove Annotation Layer and Readout.  Layout may have shifted around */
		RemoveAnnotations()

		CreateAnnotations(annotationList)

		const groupAnnotationSets = GroupAnnotationSets(annotationList) // Group sets to create readouts
		CreateReadout({ sets: groupAnnotationSets })
	}
}

const RemoveAnnotations = () => {
	/** Find Annotation Layer */
	const layers = figma.currentPage.children
	const annotationGroup = layers.find((layer) => layer.name === annotationLayerName) as GroupNode
	if (annotationGroup) {
		annotationGroup.remove()
	}
}

/**
 * Add readout coordinates to annotation sets
 * @returns IAnnotation[]
 */
export const AddCoordsToSets = (annotations: IAnnotation[]): IAnnotation[] =>
	annotations.map((annotation) => {
		annotation.set.coordinates = ReadoutCoords(annotation.set.id)
		return annotation
	})

/**
 * Return list of a single readout's coords
 * @returns ICoordinates
 */
export const ReadoutCoords = (id: string): ICoordinates => {
	const layers = figma.currentPage.children

	/** Find Annotation Layer */
	const annotationGroup = layers.find((layer) => layer.name === annotationLayerName) as GroupNode

	const coords: ICoordinates = { id: null, x: 0, y: 0, width: 0, height: 0 }

	/**
	 *  Find Readout Layer
	 * 	Postmessage issue, multiple readouts may build up on screen.  Remove "all" readouts
	 */
	const readouts = annotationGroup?.children.filter((layer) => layer.name === readoutLayerName) as GroupNode[]

	/**  ReadoutSet */
	const readoutSet = readouts[0]?.children?.find((layer) => layer.name === id) as GroupNode

	if (readoutSet) {
		coords.x = (readoutSet as FrameNode).x
		coords.y = (readoutSet as FrameNode).y
		return coords
	}
	return null
}

export const GetExistingAnnotations = () => {
	/** Find Annotation Layer */
	const layers = figma.currentPage.children.find((layer) => layer.name === annotationLayerName) as GroupNode
	return layers && layers.children.filter((layer) => layer.name !== readoutLayerName)
}

export const GetExistingData = (): IAnnotation[] => {
	const annotationNodes = GetExistingAnnotations()

	if (annotationNodes) {
		// Legacy update variables
		let containsLegacy: boolean = false
		let previousSet = null
		let currentIndex = 0
		let pivotIndex = 1

		let annotations = annotationNodes.map((node) => {
			const data = node.getSharedPluginData('a11y', 'data')
			const parsedData: IAnnotation = data && JSON.parse(data)

			/* Check for legacy annotation
				1. !parsedData : Legacy annotations do not have data 
				2. !Boolean(parsedData && parsedData.set) : Legacy data isn't organized into sets
			*/
			const isLegacyData: boolean = !parsedData || !Boolean(parsedData && parsedData.set)
			if (!containsLegacy) {
				containsLegacy = isLegacyData
			}

			// Number annotations based on their position in a set
			currentIndex = previousSet !== parsedData?.set?.id ? 0 : currentIndex + 1
			pivotIndex = currentIndex === 0 ? 1 : pivotIndex

			const text =
				parsedData?.component === ComponentType.PivotChild
					? (pivotIndex + 9).toString(36).toUpperCase()
					: (currentIndex + 1).toString()

			pivotIndex = parsedData?.component === ComponentType.PivotChild ? pivotIndex + 1 : pivotIndex
			previousSet = parsedData?.set?.id

			return isLegacyData ? ConvertLegacyAnnotation(node, text) : parsedData
		}) as IAnnotation[]

		// Remove legacy readout
		if (containsLegacy) {
			const readout = figma.currentPage.children.find((layer) => layer.name === readoutLayerName) as GroupNode
			if (readout) {
				readout.remove()
			}
		}

		// Remove annotation if the linked object has been deleted
		annotations = annotations && annotations.filter((item) => item && figma.getNodeById(item.id) !== null)

		return annotations
	}
}

export const GetExistingSetData = (id: string): IAnnotation[] => {
	const annotationNodes = GetExistingAnnotations()
	const annotationSet = annotationNodes && annotationNodes.filter((layer) => layer.name === id)
	if (annotationSet) {
		const annotations = annotationSet.map((node) => {
			const data = node.getSharedPluginData('a11y', 'data')
			return data && JSON.parse(data)
		}) as IAnnotation[]

		return annotations?.length ? annotations : []
	}
}

// Legacy annotation
const ConvertLegacyAnnotation = (annotation: BaseNode, text: string): IAnnotation => {
	const id = annotation.getSharedPluginData('a11y', 'source')
	const node = figma.getNodeById(id) as FrameNode
	if (node === null) {
		return
	}

	// Convert legacy data (Original Plugin)
	let name = Sanitize(node.name)
	let role = null
	let value = null
	let properties = []
	let description = null
	let component = ComponentType.Standard
	let set: ISet = {
		id: '1234',
		name: 'Untitled',
		artboard: GetParentArtboard(node),
		date: new Date().getTime().toString(),
		color: defaultAnnotationColor,
	}

	const nodeData = annotation.getSharedPluginData('a11y', 'data')
	const data: IAnnotation = nodeData && JSON.parse(nodeData)

	// Convert legacy data to IAnnotation
	if (data) {
		name = data.name ? data.name : name
		component = data.component ? data.component : component
		role = data.role ? data.role : role
		value = data.value ? data.value : value
		properties = data.properties ? data.properties : properties
		description = data.description ? data.description : description
		set = data.set ? data.set : set
	}

	const newAnnotation: IAnnotation = {
		name,
		id,
		component,
		role,
		value,
		properties,
		description,
		set,
	}

	// Overwrite annotation data
	annotation.setSharedPluginData('a11y', 'type', 'annotation')
	annotation.setSharedPluginData('a11y', 'source', id)
	annotation.setSharedPluginData('a11y', 'data', JSON.stringify(newAnnotation))

	return newAnnotation
}

const GroupAnnotationSets = (list: IAnnotation[]): IAnnotation[][] => {
	// Group annotations into array of sets
	const groupedSets: IAnnotation[][] = []
	let currentId = list[0].set.id
	list.map((item) => {
		// Is new group
		if (groupedSets.length === 0 || currentId !== item.set.id) {
			groupedSets.push([item])
			currentId = item.set.id
		} else {
			groupedSets[groupedSets.length - 1].push(item)
		}
	})

	return groupedSets
}
