export const SelectAnnotation = (props: { id: string; scrollIntoView: boolean }) => {
	const nodeToSelect: any = figma.getNodeById(props.id)
	if (nodeToSelect) {
		figma.currentPage.selection = [nodeToSelect]

		if (props.scrollIntoView) {
			figma.viewport.scrollAndZoomIntoView([nodeToSelect])
		}
	}
}
