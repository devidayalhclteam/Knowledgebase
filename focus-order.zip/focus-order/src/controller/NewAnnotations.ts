import { MessageType } from './MessageType'
import { GetExistingAnnotations, GetExistingData, GetExistingSetData } from './LoadAnnotations'
import { Sanitize } from 'ui/components/Shared/Sanitize'
import { IAnnotation, IArtboard, ISet } from './IAnnotation'
import { UpdateSet } from './UpdateSet'
import { ComponentType } from 'ui/components/CurrentAnnotations/Edit/Role'

/** Add new annotations from the scene */
export const NewAnnotations = (props: { set: ISet }) => {
	const selections = figma.currentPage.selection
	const set = props.set
	if (selections.length) {
		/** Get existing annotations */
		const exisitingSetData = GetExistingSetData(props.set.id)
		const newAnnotations: IAnnotation[] = exisitingSetData ? exisitingSetData : []
		// Get artboard name
		set.artboard = props.set.artboard ? props.set.artboard : GetParentArtboard(selections[0])
		const exisitingAnnotations = GetExistingAnnotations()
		selections.forEach((selection) => {
			// Run checks to see if we can annotate this selection
			const annotateSelection = VerifyAnnotation(selection, exisitingAnnotations)

			if (annotateSelection) {
				const parentData = Boolean(newAnnotations?.length) && newAnnotations.find((data) => data.id === selection.parent.id)
				const component = parentData?.component === ComponentType.PivotParent ? ComponentType.PivotChild : ComponentType.Standard

				const newAnnotation: IAnnotation = {
					name: Sanitize(selection.name),
					id: selection.id,
					component,
					role: null,
					value: null,
					properties: [],
					set,
				}

				newAnnotations.push(newAnnotation)
			}
		})

		UpdateSet({ list: newAnnotations, setId: set.id })

		const existingData = GetExistingData() // Get all annotation data
		const annotationList = existingData ? [...existingData, ...newAnnotations] : newAnnotations
		// Send message to Plugin
		// Create annotation in plugin list
		figma.ui.postMessage({
			type: MessageType.Annotations,
			annotations: annotationList, // send back full list of annotations
			amount: selections && selections.length, // send back new annotations amount for insights
		})
	}
}

const VerifyAnnotation = (selection: SceneNode, exisitingAnnotations: BaseNode[]): boolean => {
	/* Do not add annotations to annotations */
	const isAnnotation = selection.getSharedPluginData('a11y', 'type') === 'annotation'
	/* Do not add annotations to readout */
	const isReadout = selection.getSharedPluginData('a11y', 'type') === 'readout'

	// Do not create a new annotation if one already exisits
	const isNewID = exisitingAnnotations
		? !exisitingAnnotations.find((child) => child.getSharedPluginData('a11y', 'source') === selection.id)
		: true

	return !isAnnotation && !isReadout && isNewID
}

/** Get the parent artboard.  This is only set once, if the user choses to manipulate artboards deliberately, it won't be updated */
export const GetParentArtboard = (currentNode: SceneNode | DocumentNode | PageNode): IArtboard => {
	const parentNode = currentNode.parent

	if (!parentNode || parentNode.type === 'PAGE') {
		return { name: currentNode.name, id: currentNode.id }
	} else {
		return GetParentArtboard(parentNode)
	}
}
