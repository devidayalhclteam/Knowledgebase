import { annotationLayerName } from "./CreateAnnotations"
import { readoutLayerName } from "./CreateReadout"

/** Delete set from the scene */
export const DeleteSet = (props: { id: string; }) => {
    RemoveSetById(props.id)
    RemoveReadoutById(props.id)
}

const RemoveSetById =(id: string) =>{
   /** Find Annotation Layer */
   const layers = figma.currentPage.children
   const annotationGroup = layers.find((layer) => layer.name === annotationLayerName) as GroupNode

   /**  Delete Annotations */
   if(annotationGroup){
       annotationGroup.children.map((layer) => {
           if(layer.name === id)
           {
            layer.remove()
           }
       }) 
   }
}

const RemoveReadoutById =(id: string) =>{
    const layers = figma.currentPage.children
    /** Find Annotation Layer */
    const annotationGroup = layers.find((layer) => layer.name === annotationLayerName) as GroupNode

    /** 
     *  Find Readout Layer 
     * 	Postmessage issue, multiple readouts may build up on screen.  Remove "all" readouts
     */
    const readouts = annotationGroup && annotationGroup.children.filter((layer) => layer.name === readoutLayerName) as GroupNode[]
    /**  ReadoutSet */
    const readoutSet = readouts && readouts[0].children.find((layer) => layer.name === id) as GroupNode

    if(readoutSet){
        readoutSet.remove()
    }
}