import { CreateAnnotations } from './CreateAnnotations'
import { CreateReadout } from './CreateReadout'

import { IAnnotation } from './IAnnotation'

import { DeleteSet } from './DeleteSet'
import { AddCoordsToSets, GetExistingAnnotations } from './LoadAnnotations'
import { ComponentType } from 'ui/components/CurrentAnnotations/Edit/Role'
import { MessageType } from './MessageType'

export const UpdateSet = async (props: { list: IAnnotation[]; setId: string; newParentContainer?: IAnnotation }) => {
	let annotationList: IAnnotation[] = props.list

	if (annotationList?.length) {
		const existingAnnotations = GetExistingAnnotations()
		const oldSet = existingAnnotations && (existingAnnotations.find((layer) => layer.name === props.setId) as GroupNode)

		if (oldSet) {
			annotationList = AddCoordsToSets(annotationList)
			DeleteSet({ id: props.setId })
		}

		if (props.newParentContainer) {
			let updateChild = false
			const newChild: ComponentType =
				props.newParentContainer.component === ComponentType.Standard ? ComponentType.Standard : ComponentType.PivotChild
			annotationList = annotationList.map((annotation) => {
				// Check to see if there are annotation children under the new parent container
				if (updateChild && annotation.component !== newChild) {
					const childNode = figma.getNodeById(annotation.id)
					updateChild = checkForParent(childNode, props.newParentContainer.id)
					if (updateChild) {
						annotation.component = newChild
					}
				} else {
					updateChild = false
				}

				// This is the parent container.  Check next annotations for children
				if (annotation.id === props.newParentContainer.id) {
					updateChild = true
				}
				return annotation
			})

			// Send annotations to plugin
			figma.ui.postMessage({
				type: MessageType.Annotations,
				annotations: annotationList,
			})
		}

		CreateAnnotations(annotationList)

		// Create annotation readout if user has not deleted it
		CreateReadout({ sets: [annotationList] })
	} else if (props.list?.length === 0) {
		DeleteSet({ id: props.setId })
	}
}

// Check to see if child is within this parent
const checkForParent = (child: BaseNode, parentId: string): boolean => {
	if (child?.parent?.id === parentId) {
		return true
	} else if (child?.parent) {
		checkForParent(child.parent, parentId)
	}
	return false
}
