import { ComponentType, defaultRoleText } from 'ui/components/CurrentAnnotations/Edit/Role'
import { IAnnotation, ICoordinates, IRGBA } from './IAnnotation'
import { annotationLayerName, findNextText, getZeroStateText, Rgb2Percent } from './CreateAnnotations'
import { defaultAnnotationColor } from 'ui/components/Shared/SharedColors'
import { GetValueString } from 'ui/components/Shared/GetValueString'
import { GetPropsString } from 'ui/components/Shared/GetPropsString'
import { IRGB } from 'ui/components/Shared/ColorPicker/utilities/consts'

export const readoutLayerName = '**~~ Focus-order readout ~~**'
const readoutFontSize = 12
const READOUT_SPACING = 40
const READOUT_WIDTH = 275

/** Readout allows engineers to see the annotation details withouth downloading the plugin */
export const CreateReadout = async (props: { sets: IAnnotation[][] }) => {
	await figma.loadFontAsync({ family: 'Roboto Mono', style: 'Regular' })
	await figma.loadFontAsync({ family: 'Roboto Mono', style: 'Bold' })

	const mainLayer = figma.currentPage.children.find((layer) => layer.name === annotationLayerName) as GroupNode
	let readoutLayer = mainLayer.children.find((layer) => layer.name === readoutLayerName) as GroupNode

	props.sets.map((set) => {
		let readoutFrame: FrameNode = CreateReadoutFrame()
		readoutFrame.name = set[0].set.id
		readoutFrame.setSharedPluginData('a11y', 'type', 'readout')

		// TITLE
		const setTitle = createSetTitle(set[0].set.name)
		readoutFrame.appendChild(setTitle as any)

		let currentIndex: string = '0'
		let retainLastTextIndex: number = 0

		const accentColor = set[0].set.color ? set[0].set.color : defaultAnnotationColor
		const accentColorPercent = Rgb2Percent(accentColor)
		// ANNOTATION LIST
		set.map((annotation, annotationIndex) => {
			retainLastTextIndex = Number.isNaN(Number(currentIndex)) ? retainLastTextIndex : Number(currentIndex)
			currentIndex =
				annotationIndex === 0
					? getZeroStateText(annotation.component)
					: findNextText(currentIndex, annotation.component, retainLastTextIndex)
			const readout = CreateRedoutUI(annotation, annotationIndex + 1, currentIndex, accentColor, accentColorPercent)
			readoutFrame.appendChild(readout)
		})

		const coords = set[0].set.coordinates

		readoutFrame = PositionReadout(readoutFrame, set[0].id, coords)
		readoutFrame = CheckForOverlap(readoutFrame)

		// Does readout layer exist?
		if (readoutLayer) {
			readoutLayer.appendChild(readoutFrame)
		} else {
			readoutLayer = figma.group([readoutFrame], mainLayer)
			readoutLayer.name = readoutLayerName
		}
	})
}

const CreateReadoutFrame = () => {
	/** Create new Readout Layer */
	const newFrame = figma.createFrame() as FrameNode

	// Frame styles
	newFrame.horizontalPadding = 23
	newFrame.verticalPadding = 20
	newFrame.fills = [{ type: 'SOLID', color: { r: 0.81, g: 0.81, b: 0.81 } }]
	newFrame.cornerRadius = 4

	newFrame.layoutMode = 'VERTICAL'
	newFrame.itemSpacing = 10
	newFrame.counterAxisSizingMode = 'AUTO'
	newFrame.resize(READOUT_WIDTH, newFrame.height)

	return newFrame
}

const CreateSectionFrame = () => {
	/** Create new Readout Layer */
	const newFrame = figma.createFrame() as FrameNode

	// Frame styles
	newFrame.verticalPadding = 10
	newFrame.fills = [{ type: 'SOLID', color: { r: 0.81, g: 0.81, b: 0.81 } }]
	newFrame.cornerRadius = 4

	newFrame.layoutMode = 'HORIZONTAL'
	newFrame.itemSpacing = 10
	newFrame.layoutAlign = 'STRETCH'
	newFrame.primaryAxisSizingMode = 'FIXED'
	newFrame.counterAxisSizingMode = 'AUTO'

	return newFrame
}

const CreateRightFrame = () => {
	/** Create new Readout Layer */
	const newFrame = figma.createFrame() as FrameNode

	// Frame styles
	newFrame.fills = [{ type: 'SOLID', color: { r: 0.81, g: 0.81, b: 0.81 } }]
	newFrame.cornerRadius = 4

	newFrame.layoutMode = 'VERTICAL'
	newFrame.itemSpacing = 5
	newFrame.primaryAxisSizingMode = 'AUTO'
	newFrame.layoutAlign = 'INHERIT'
	newFrame.layoutGrow = 1

	return newFrame
}

const CreateListFrame = () => {
	/** Create new Readout Layer */
	const newFrame = figma.createFrame() as FrameNode

	// Frame styles
	newFrame.fills = [{ type: 'SOLID', color: { r: 0.81, g: 0.81, b: 0.81 } }]
	newFrame.cornerRadius = 4

	newFrame.layoutMode = 'HORIZONTAL'
	newFrame.itemSpacing = 10
	newFrame.layoutAlign = 'STRETCH'
	newFrame.primaryAxisSizingMode = 'FIXED'
	newFrame.counterAxisSizingMode = 'AUTO'

	return newFrame
}

const CreateDescriptionFrame = () => {
	/** Create new Readout Layer */
	const newFrame = figma.createFrame() as FrameNode

	// Frame styles
	newFrame.fills = [{ type: 'SOLID', color: { r: 0.81, g: 0.81, b: 0.81 } }]
	newFrame.cornerRadius = 4

	newFrame.layoutMode = 'VERTICAL'
	newFrame.itemSpacing = 10
	newFrame.counterAxisSizingMode = 'FIXED'
	newFrame.layoutAlign = 'STRETCH'

	return newFrame
}
const CreateRedoutUI = (item: IAnnotation, index: number, text: string, accentColor: IRGBA, accentColorPercent: IRGB): FrameNode => {
	const rightFrame: FrameNode = CreateRightFrame()

	// BUBBLE SVG
	const bubbleSVG = createBubble(item.component, text, accentColor, accentColorPercent)
	bubbleSVG.opacity = accentColor.a

	// NAME
	const name = createRegularText('Name:')
	const nameText = createBoldText(item.name)
	nameText.layoutGrow = 1

	const nameGroup = CreateListFrame()
	nameGroup.appendChild(name)
	nameGroup.appendChild(nameText)
	rightFrame.appendChild(nameGroup)

	// ROLE
	const role = createRegularText('Role:')

	const textForRole = item.role ? item.role : defaultRoleText
	const roleText = createBoldText(textForRole)

	const roleGroup = CreateListFrame()
	roleGroup.appendChild(role)
	roleGroup.appendChild(roleText)
	rightFrame.appendChild(roleGroup)

	// VALUE
	const value = createRegularText('Value:')

	const textForValue = GetValueString(item.value)
	const valueText = createBoldText(textForValue)
	valueText.layoutGrow = 1

	const valueGroup = CreateListFrame()
	valueGroup.appendChild(value)
	valueGroup.appendChild(valueText)
	rightFrame.appendChild(valueGroup)

	// PROPS
	const properties = createRegularText('Props:')

	const textForProperties = GetPropsString(item.properties)
	const propertiesText = createBoldText(textForProperties.charAt(0).toUpperCase() + textForProperties.slice(1))
	propertiesText.layoutGrow = 1

	const propGroup = CreateListFrame()
	propGroup.appendChild(properties)
	propGroup.appendChild(propertiesText)
	rightFrame.appendChild(propGroup)

	if (item.description) {
		// DESCRIPTION
		const description = createRegularText('Description:')
		const descriptionText = createBoldText(item.description)
		descriptionText.layoutAlign = 'STRETCH'

		const descGroup = CreateDescriptionFrame()
		descGroup.appendChild(description)
		descGroup.appendChild(descriptionText)
		rightFrame.appendChild(descGroup)
	}

	const sectionFrame: FrameNode = CreateSectionFrame()
	sectionFrame.name = index.toString()
	sectionFrame.appendChild(bubbleSVG)
	sectionFrame.appendChild(rightFrame)

	return sectionFrame
}

const createSetTitle = (text: string) => {
	const newFrame = figma.createFrame() as FrameNode

	newFrame.fills = [{ type: 'SOLID', color: { r: 0.81, g: 0.81, b: 0.81 } }]
	newFrame.layoutMode = 'VERTICAL'
	newFrame.itemSpacing = 10
	newFrame.counterAxisSizingMode = 'FIXED'
	newFrame.layoutAlign = 'STRETCH'

	const newText = figma.createText()
	newText.fontName = { family: 'Roboto Mono', style: 'Regular' }

	newText.fontSize = readoutFontSize
	newText.characters = text
	newText.name = text
	newText.layoutAlign = 'STRETCH'

	newFrame.appendChild(newText)

	// UNDERLINE
	if (text) {
		const underline = figma.createLine()
		underline.layoutAlign = 'STRETCH'
		newFrame.appendChild(underline)
	}

	return newFrame
}

export const createBubble = (component: ComponentType, text: string, accentColor: IRGBA, accentColorPercent: IRGB) => {
	const circleWidth = 28

	let bubble = null
	let parentArrow = null
	if (component === ComponentType.PivotChild) {
		// Triangle
		const Triangle = `<svg width="21" height="28" viewBox="0 0 21 28" fill="rgba(${accentColor.r},${accentColor.g},${accentColor.b},${accentColor.a})" xmlns="http://www.w3.org/2000/svg">
			<path d="M8.05481 2.11784C5.11808 -0.245919 0.751953 1.84455 0.751953 5.6144V22.3719C0.751953 26.1418 5.11808 28.2323 8.05481 25.8685L18.4646 17.4897C20.6967 15.6931 20.6967 12.2933 18.4646 10.4966L8.05481 2.11784Z" stroke="#FFFFFF" stroke-width="2"/>
		</svg>`
		bubble = figma.createNodeFromSvg(Triangle)
		bubble.resize(21, 28)
	} else {
		// Circle
		bubble = figma.createEllipse()
		bubble.resize(circleWidth, circleWidth)
		bubble.strokeWeight = 2
		bubble.strokes = [
			{
				color: { r: 1, g: 1, b: 1 },
				opacity: 1,
				type: 'SOLID',
				visible: true,
			},
		]
		bubble.fills = [{ type: 'SOLID', color: accentColorPercent, opacity: accentColor.a }]

		if (component === ComponentType.PivotParent) {
			const Triangle = `<svg width="21" height="28" viewBox="0 0 21 28" fill="rgb(${accentColor.r},${accentColor.g},${accentColor.b})" xmlns="http://www.w3.org/2000/svg">
			<path d="M8.05481 2.11784C5.11808 -0.245919 0.751953 1.84455 0.751953 5.6144V22.3719C0.751953 26.1418 5.11808 28.2323 8.05481 25.8685L18.4646 17.4897C20.6967 15.6931 20.6967 12.2933 18.4646 10.4966L8.05481 2.11784Z" stroke="#FFFFFF" stroke-width="2"/>
			</svg>`
			parentArrow = figma.createNodeFromSvg(Triangle)
			parentArrow.resize(21 / 1.5, 28 / 1.5)
			parentArrow.constraints = { horizontal: 'MIN', vertical: 'MIN' }

			parentArrow.x = bubble.x + bubble.width - 2
			parentArrow.y = bubble.y + bubble.height / 2 - parentArrow.height / 2
			parentArrow.name = 'Ellipse background'
		}
	}
	bubble.constraints = { horizontal: 'MIN', vertical: 'MIN' }
	bubble.name = 'Ellipse background'

	const newText = figma.createText()
	newText.fontName = { family: 'Roboto Mono', style: 'Bold' }
	newText.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }]
	newText.textAlignHorizontal = 'CENTER'
	newText.textAlignVertical = 'CENTER'
	newText.fontSize = readoutFontSize
	newText.resize(bubble.width, bubble.height)
	newText.x = bubble.x - (component === ComponentType.PivotChild && 2)
	newText.y = bubble.y - (component === ComponentType.PivotChild && 1)

	newText.characters = text
	newText.name = text
	newText.constraints = { horizontal: 'MIN', vertical: 'MIN' }

	return figma.group(parentArrow ? [bubble, parentArrow, newText] : [bubble, newText], figma.currentPage)
}

const createRegularText = (text: string) => {
	const newText = figma.createText()
	newText.fontName = { family: 'Roboto Mono', style: 'Regular' }
	newText.fills = [{ type: 'SOLID', color: { r: 0.35, g: 0.35, b: 0.35 } }]
	newText.textAlignHorizontal = 'LEFT'
	newText.fontSize = readoutFontSize
	newText.characters = text
	newText.name = text
	return newText
}

const createBoldText = (text: string) => {
	const newText = figma.createText()
	newText.fontName = { family: 'Roboto Mono', style: 'Regular' }
	newText.fills = [{ type: 'SOLID', color: { r: 0, g: 0, b: 0 } }]
	newText.textAlignHorizontal = 'LEFT'
	newText.fontSize = readoutFontSize
	newText.characters = text
	newText.name = text
	return newText
}

/** Position readout at the top right of the parent frame */
const PositionReadout = (readout: FrameNode, id: string, coords: ICoordinates) => {
	const currentNode = figma.getNodeById(id) as FrameNode
	const parentNode = GetTopNode(currentNode)

	// Use current coordinates or generate new coords if there is none
	readout.x = coords ? coords.x : parentNode.absoluteTransform[0][2] + parentNode.width + READOUT_SPACING
	readout.y = coords ? coords.y : parentNode.absoluteTransform[1][2]

	return readout
}

export const GetTopNode = (currentNode: any) => {
	const parentNode = currentNode.parent

	// If you reach a PageNode, you have gone too far
	if (parentNode.type === 'PAGE' || !parentNode) {
		return currentNode
	} else {
		return GetTopNode(parentNode)
	}
}

/** Prevent overlapping of new readouts. */
/** Move new readouts to the first available y position */
const CheckForOverlap = (readout: FrameNode) => {
	let coords = AllReadoutCoords()
	// Sort coords from top to bottom
	coords = coords.sort((a, b) => a.y - b.y)

	coords.forEach((coord) => {
		const readoutRight = readout.x + readout.width
		const readoutBottom = readout.y + readout.height
		const footprintRight = coord.x + coord.width
		const footprintBottom = coord.y + coord.height

		const isOverlapping = !(
			readoutRight < coord.x ||
			readout.x > footprintRight ||
			readoutBottom < coord.y ||
			readout.y > footprintBottom
		)

		if (isOverlapping) {
			readout.y = footprintBottom + READOUT_SPACING
		}
	})

	return readout
}

/**
 * Return list of all the readout coords
 * @returns ICoordinates[]
 */
const AllReadoutCoords = (): ICoordinates[] => {
	const layers = figma.currentPage.children
	const coords: ICoordinates[] = []

	/** Find Annotation Layer */
	const annotationGroup = layers.find((layer) => layer.name === annotationLayerName) as GroupNode

	/**
	 *  Find Readout Layer
	 * 	Postmessage issue, multiple readouts may build up on screen.  Remove "all" readouts
	 */
	const readouts = annotationGroup && (annotationGroup.children.filter((layer) => layer.name === readoutLayerName) as GroupNode[])

	if (readouts?.length) {
		readouts.forEach((readout, index) => {
			// We really only expect one Readout Layer to be in this array, but in case there are more, remove the extras
			if (index === 0) {
				readout.children.forEach((item) => {
					coords.push({
						id: item.id,
						x: (item as FrameNode).x,
						y: (item as FrameNode).y,
						width: (item as FrameNode).width,
						height: (item as FrameNode).height,
					})
				})
			}
		})
	}

	return coords
}
