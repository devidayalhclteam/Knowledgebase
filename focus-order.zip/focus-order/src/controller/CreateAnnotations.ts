import { ComponentType } from 'ui/components/CurrentAnnotations/Edit/Role'
import { IRGB } from 'ui/components/Shared/ColorPicker/utilities/consts'
import { defaultAnnotationColor } from 'ui/components/Shared/SharedColors'
import { IAnnotation, IRGBA } from './IAnnotation'

export const annotationLayerName = '**~~ Focus-order annotations ~~**'

export const CreateAnnotations = async (list: IAnnotation[]) => {
	let previousSet = null
	let currentIndex: string = '0'
	let retainLastTextIndex: number = 0
	let parentTabOverlapsArrow: string = null

	let mainLayer = figma.currentPage.children.find((layer) => layer.name === annotationLayerName) as GroupNode

	list.map(async (item, index) => {
		const nodeToAnnotate = figma.getNodeById(item.id) as FrameNode
		if (nodeToAnnotate === null) {
			console.warn('Object does not exist')
			return
		}
		retainLastTextIndex = Number.isNaN(Number(currentIndex)) ? retainLastTextIndex : Number(currentIndex)
		// Number annotations based on their position in a set
		currentIndex =
			previousSet !== item.set.id ? getZeroStateText(item.component) : findNextText(currentIndex, item.component, retainLastTextIndex)

		previousSet = item.set.id

		const overlapContent = parentTabOverlapsArrow && item.component === ComponentType.PivotChild ? parentTabOverlapsArrow : null

		if (item.component === ComponentType.PivotParent && list[index + 1] && list[index + 1].component === ComponentType.PivotChild) {
			const parentPos = { x: nodeToAnnotate.absoluteTransform[0][2], y: nodeToAnnotate.absoluteTransform[1][2] }

			const nextNode = figma.getNodeById(list[index + 1].id) as FrameNode
			const childPos = { x: nextNode.absoluteTransform[0][2], y: nextNode.absoluteTransform[1][2] }
			parentTabOverlapsArrow = parentPos.x === childPos.x && parentPos.y === childPos.y ? currentIndex : null
		} else {
			parentTabOverlapsArrow = null
		}

		const annotation = await CreateAnnotationUI(
			nodeToAnnotate,
			currentIndex,
			item.set.color,
			item.component,
			overlapContent || parentTabOverlapsArrow
		)

		annotation.locked = true
		annotation.name = item.set.id

		// Add data to annotation layer
		annotation.setSharedPluginData('a11y', 'type', 'annotation')
		annotation.setSharedPluginData('a11y', 'source', item.id)
		annotation.setSharedPluginData('a11y', 'data', JSON.stringify(item))

		// Add annotations to main layer
		if (mainLayer) {
			mainLayer.appendChild(annotation)
		} else {
			mainLayer = figma.group([annotation], figma.currentPage)
			mainLayer.name = annotationLayerName
		}
	})
}

const CreateAnnotationUI = async (
	nodeToAnnotate: FrameNode,
	text: string,
	color: IRGBA,
	component: ComponentType,
	overlap: string
): Promise<GroupNode> => {
	const switchImage = overlap && component === ComponentType.PivotChild

	await figma.loadFontAsync({ family: 'Roboto', style: 'Regular' })
	await figma.loadFontAsync({ family: 'Roboto', style: 'Bold' })

	const annotationWidth = 28

	const parentX = nodeToAnnotate.absoluteTransform[0][2]
	const parentY = nodeToAnnotate.absoluteTransform[1][2]

	const borderW = nodeToAnnotate.width > 0 ? nodeToAnnotate.width : 1
	const borderH = nodeToAnnotate.height > 0 ? nodeToAnnotate.height : 1
	const borderRotation = nodeToAnnotate.rotation ? nodeToAnnotate.rotation : 0

	const accentColor = Rgb2Percent(color ? color : defaultAnnotationColor)

	const border = figma.createRectangle()
	border.x = 0
	border.y = 0
	border.resize(borderW, borderH)
	border.strokeWeight = 2
	border.strokeAlign = 'OUTSIDE'
	border.cornerRadius = 4
	border.strokes = [
		{
			color: accentColor,
			opacity: color.a,
			type: 'SOLID',
			visible: true,
		},
	]
	border.fills = []
	border.name = 'Border 1'
	border.constraints = { horizontal: 'STRETCH', vertical: 'STRETCH' }

	const border2 = figma.createRectangle()
	border2.x = 0
	border2.y = 0
	border2.resize(borderW, borderH)
	border2.strokeWeight = 2
	border2.cornerRadius = 4
	border2.strokes = [
		{
			color: { r: 1, g: 1, b: 1 },
			opacity: 1,
			type: 'SOLID',
			visible: true,
		},
	]
	border2.fills = []
	border2.name = 'Border 2'
	border2.constraints = { horizontal: 'STRETCH', vertical: 'STRETCH' }

	const focusBorder = figma.group([border, border2], figma.currentPage)
	focusBorder.name = 'Borders'
	focusBorder.rotation = borderRotation

	let circle = null

	if (component === ComponentType.PivotChild && !switchImage) {
		const Triangle = `<svg width="21" height="28" viewBox="0 0 21 28" fill="rgb(${color.r},${color.g},${color.b})" xmlns="http://www.w3.org/2000/svg">
			<path d="M8.05481 2.11784C5.11808 -0.245919 0.751953 1.84455 0.751953 5.6144V22.3719C0.751953 26.1418 5.11808 28.2323 8.05481 25.8685L18.4646 17.4897C20.6967 15.6931 20.6967 12.2933 18.4646 10.4966L8.05481 2.11784Z" stroke="#FFFFFF" stroke-width="2"/>
		</svg>`
		circle = figma.createNodeFromSvg(Triangle)
		circle.resize(21, 28)
		circle.x = -circle.width / 2 + 4
		circle.y = -circle.height / 2 + 2
	} else if (!overlap || switchImage) {
		circle = figma.createEllipse()
		circle.resize(annotationWidth, annotationWidth)
		circle.strokeWeight = 2
		circle.strokes = [
			{
				color: { r: 1, g: 1, b: 1 },
				opacity: 1,
				type: 'SOLID',
				visible: true,
			},
		]
		circle.fills = [{ type: 'SOLID', color: accentColor, opacity: color.a }]
		circle.x = -circle.width / 2 + 2
		circle.y = -circle.width / 2 + 2
	}

	let circleText = null
	if (circle) {
		circle.constraints = { horizontal: 'MIN', vertical: 'MIN' }
		circle.name = 'Ellipse background'

		circleText = figma.createText()
		circleText.fontName = { family: 'Roboto', style: 'Bold' }
		circleText.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }]
		circleText.textAlignHorizontal = 'CENTER'
		circleText.textAlignVertical = 'CENTER'
		circleText.fontSize = 12
		circleText.resize(circle.width, circle.height)
		circleText.x = circle.x - (component === ComponentType.PivotChild && !switchImage && 1)
		circleText.y = circle.y

		circleText.characters = switchImage ? overlap : text
		circleText.name = 'Order'
		circleText.constraints = { horizontal: 'MIN', vertical: 'MIN' }
	}

	const annotationFrame = figma.createFrame()
	annotationFrame.resize(borderW, borderH)
	annotationFrame.x = parentX
	annotationFrame.y = parentY
	annotationFrame.fills = [{ type: 'SOLID', color: accentColor, visible: false, opacity: color.a }]
	annotationFrame.clipsContent = false
	annotationFrame.name = 'Annotation'

	annotationFrame.appendChild(border)
	annotationFrame.appendChild(border2)

	if (circle) {
		annotationFrame.appendChild(circle)
		annotationFrame.appendChild(circleText)
	}

	if ((component === ComponentType.PivotParent && !overlap) || switchImage) {
		const Triangle = `<svg width="21" height="28" viewBox="0 0 21 28" fill="rgb(${color.r},${color.g},${color.b})" xmlns="http://www.w3.org/2000/svg">
			<path d="M8.05481 2.11784C5.11808 -0.245919 0.751953 1.84455 0.751953 5.6144V22.3719C0.751953 26.1418 5.11808 28.2323 8.05481 25.8685L18.4646 17.4897C20.6967 15.6931 20.6967 12.2933 18.4646 10.4966L8.05481 2.11784Z" stroke="#FFFFFF" stroke-width="2"/>
		</svg>`
		const componentParent = figma.createNodeFromSvg(Triangle)
		componentParent.resize(21 / 1.5, 28 / 1.5)
		componentParent.constraints = { horizontal: 'MIN', vertical: 'MIN' }

		componentParent.x = circle.x + circle.width - 2
		componentParent.y = circle.y + circle.height / 2 - componentParent.height / 2
		componentParent.name = 'Ellipse background'

		annotationFrame.appendChild(componentParent)
	}

	const annotation = figma.group([annotationFrame], figma.currentPage)

	return annotation
}

export const Rgb2Percent = (props: IRGB) => {
	return {
		r: Number((props.r / 255).toFixed(2)),
		g: Number((props.g / 255).toFixed(2)),
		b: Number((props.b / 255).toFixed(2)),
	}
}

export const getZeroStateText = (component: ComponentType) => {
	return component === ComponentType.PivotChild ? 'A' : '1'
}

export const findNextText = (currentIndex: string, component: ComponentType, retainLastTextIndex: number): string => {
	if (component === ComponentType.PivotChild) {
		return Number.isNaN(Number(currentIndex)) ? String.fromCharCode(currentIndex.charCodeAt(currentIndex.length - 1) + 1) : 'A'
	} else {
		return Number.isNaN(Number(currentIndex)) ? (retainLastTextIndex + 1).toString() : (Number(currentIndex) + 1).toString()
	}
}
