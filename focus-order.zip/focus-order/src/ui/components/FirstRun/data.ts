interface IFirstRun {
	header: string
	description: string
	lottieAnimationData?: any
}

import Lottie1 from 'assets/lottie/fre-1.json'
import Lottie2 from 'assets/lottie/fre-2.json'
import Lottie3 from 'assets/lottie/fre-3.json'

export const firstRun: IFirstRun[] = [
	{
		lottieAnimationData: Lottie1,
		header: 'Welcome to the Focus Order plugin',
		description: 'This plugin will help you create designs for keyboarding and screen reader users.',
	},
	{
		lottieAnimationData: Lottie2,
		header: 'Adding a control to the tab order',
		description: 'Select the first interactive control in your design, and then click “Add”',
	},
	{
		lottieAnimationData: Lottie3,
		header: 'Edit and rearrange focusable controls',
		description: 'Reordering tabs is as simple as drag and drop, and reader output is fully editable.',
	},
]
