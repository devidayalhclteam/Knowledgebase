import * as React from 'react'
import styled from '@emotion/styled'
import { appInsights } from 'shared/AppInsights'
import { standardBgColor } from 'shared/SharedColors'
import { firstRun } from './data'
import { FirstRun } from '@ms-design/figma-ui-components'

interface IFirstRunProps {
	endFRE: () => void
}

export const FRE = (props: IFirstRunProps) => {
	const handleButtonClick = (index: number, text: string) => {
		appInsights.trackEvent({ name: `FRE/${index + 1}/${text}` })
		if (index === firstRun.length - 1) {
			/* FRE is complete */
			props.endFRE()
		}
	}

	return (
		<Container>
			<FirstRun data={firstRun} onButtonClick={handleButtonClick} />
		</Container>
	)
}

const Container = styled.div`
	position: absolute;
	top: 0;
	display: flex;
	flex-direction: column;
	width: 100%;
	height: 100%;
	min-height: 100%;
	background-color: ${standardBgColor};
`
