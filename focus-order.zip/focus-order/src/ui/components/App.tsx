import * as React from 'react'

import styled from '@emotion/styled'
import { FRE } from './FirstRun/FirstRun'
import { About } from './About/About'
import { MessageType } from 'controller/MessageType'
import { textPrimaryColor, defaultAnnotationColor } from './Shared/SharedColors'
import { Home } from './Home'
import { IAnnotation, ISet } from 'controller/IAnnotation'
import { TabHeader } from './Shared/TabHeader/TabHeader'
import { appInsights } from './Shared/AppInsights'
import { CurrentAnnotations } from './CurrentAnnotations'
import { Progress } from '@ms-design/figma-ui-components'

export enum LocationType {
	Home,
	Current,
	Edit,
}

const App = () => {
	const ref = React.useRef()
	let loaderFallback: number = null
	const [location, setLocation] = React.useState(LocationType.Home)
	/* In order to preserve state and history of the current screen we overlay About instead of closing the current active page */
	const [isAboutVisible, setIsAboutVisible] = React.useState(false)
	/* In order to preserve state and history of the current screen we overlay the FRE instead of closing the current active page */
	const [isFREVisible, setIsFREVisible] = React.useState(false)
	const [isLoading, setIsLoading] = React.useState(true)

	const [list, setList] = React.useState<IAnnotation[]>([])
	const [newSetName, setNewSetName] = React.useState(null) // Used when creating a new set only
	const [currentSet, setCurrentSet] = React.useState<ISet>(null)
	const [isWin, setIsWin] = React.useState(null)

	React.useEffect(() => {
		/* Listen for post messages from the scene */
		onmessage = (event: MessageEvent) => {
			const message = event.data.pluginMessage

			if (message.type === MessageType.IsFirstRun) {
				// If FRE has not been completed run FRE
				if (!message.isCompleted) {
					setIsFREVisible(true)
					setIsLoading(false)
					clearTimeout(loaderFallback)

					appInsights.trackEvent({ name: `FRE` })
				}
			} else if (message.type === MessageType.Annotations) {
				/* Receive existing annotations from the scene */
				if (message.annotations) {
					setLocation(LocationType.Current)
					setList(message.annotations)

					setIsLoading(false)
					clearTimeout(loaderFallback)

					if (message.amount) {
						appInsights.trackEvent({ name: `CurrentAnnotations/Add` }, { amount: message.amount })
					}
				} else {
					setList([])
				}
			}
		}

		if (isLoading) {
			// If we don't get a message back in 1s stop the loader
			loaderFallback = window.setTimeout(() => {
				setIsLoading(false)
			}, 1000)
		}

		// Need to add special scroll styles to fix PC scrollbars
		// Once isWin is set, do not check again
		if (isWin === null) {
			if (navigator && navigator.appVersion.indexOf('Win') !== -1) {
				setIsWin(true)
			} else {
				setIsWin(false)
			}

			// Let the scene know the plugin has loaded
			// In Safari the plugin does not load fast enough and messages from the scene are lost
			parent.postMessage({ pluginMessage: { type: MessageType.LoadAnnotations } }, '*')
		}
	}, [])

	React.useEffect(() => {
		/* 
			When we recieve a list for the first time (the app is opening).  Set location to home
		*/
		if (list.length && !currentSet) {
			setLocation(LocationType.Home)
		}
	}, [list])

	/** Create new set of Annotations */
	const createNewSet = () => {
		const newSet: ISet = {
			id: new Date().getTime().toString(),
			name: newSetName,
			artboard: null,
			date: new Date().getTime().toString(),
			color: defaultAnnotationColor,
		}
		setCurrentSet(newSet)
		parent.postMessage({ pluginMessage: { type: MessageType.NewAnnotations, set: newSet } }, '*')
	}

	const openIntro = () => {
		setIsFREVisible(true)
		appInsights.trackEvent({ name: `About/Intro` })
	}

	const isCurrentAnnotations = location === LocationType.Current
	const isHome = location === LocationType.Home

	return (
		<Container ref={ref} tabIndex={0} isWin={isWin}>
			<TabHeader
				annotationsPresent={Boolean(list.length)}
				isHome={isHome}
				isCurrentAnnotations={isCurrentAnnotations}
				isAboutVisible={isAboutVisible}
				setLocation={setLocation}
				setIsAboutVisible={setIsAboutVisible}
			/>
			{isHome && (
				<Home
					list={list}
					setList={setList}
					currentSetId={currentSet && currentSet.id}
					newSetName={newSetName}
					setNewSetName={setNewSetName}
					setLocation={setLocation}
					createNewSet={createNewSet}
					setCurrentSet={setCurrentSet}
				/>
			)}
			{isCurrentAnnotations && (
				<CurrentAnnotations
					currentSet={currentSet}
					setCurrentSet={setCurrentSet}
					list={list}
					setList={setList}
					setTabLocation={setLocation}
					newSetName={newSetName}
					setNewSetName={setNewSetName}
					createNewSet={createNewSet}
				/>
			)}
			{isAboutVisible && <About openIntro={openIntro} />}
			{isFREVisible && <FRE endFRE={() => setIsFREVisible(false)} />}
			<Progress isLoading={isLoading} />
		</Container>
	)
}

interface IStyles {
	isWin: boolean
}

const Container = styled.div<IStyles>`
	display: flex;
	flex-direction: column;
	width: 100%;
	height: 100%;

	color: ${textPrimaryColor};
	font-size: 11px;

	*::-webkit-scrollbar {
		-webkit-appearance: ${(props) => props.isWin && 'none'};
		width: ${(props) => props.isWin && '10px'};
	}

	*::-webkit-scrollbar-thumb {
		border-radius: ${(props) => props.isWin && '7px'};
		background-color: ${(props) => props.isWin && 'rgba(0, 0, 0, 0.3)'};
		background-clip: ${(props) => props.isWin && 'padding-box'};
		border: ${(props) => props.isWin && '2px solid rgba(255, 255, 255, 255)'};
	}
`

export default App
