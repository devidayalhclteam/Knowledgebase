import * as React from 'react'

import styled from '@emotion/styled'
import { standardBgColor } from 'shared/SharedColors'
import { BaseIntro, Button } from '@ms-design/figma-ui-components'
import { mainImg } from 'assets/svgs/'
import { appInsights } from 'shared/AppInsights'

interface IAboutProps {
	openIntro: () => void
}

export const About = (props: IAboutProps) => {
	const handleLicenseClick = () => {
		appInsights.trackEvent({ name: `About/Microsoft Software License Terms` })
	}

	const handlePrivacyClick = () => {
		appInsights.trackEvent({ name: `About/Microsoft Privacy Statement` })
	}
	return (
		<Container>
			<BaseIntro
				img={<Hero src={mainImg} />}
				header={'Focus Order Plugin'}
				subheader={'Add focus order to your work to help improve accessibility'}
				isFooterVisible={true}
				onLicenseClick={handleLicenseClick}
				onPrivacyClick={handlePrivacyClick}>
				<Content>
					<Button
						label="Tutorial"
						onClick={() => {
							appInsights.trackEvent({ name: `About/Tutorial` })
							window.open(
								'https://www.figma.com/proto/MvwfJiAq2uQ9O1GYiTtNs4/Focus-Order?page-id=2386%3A7510&node-id=2430%3A7961&viewport=314%2C48%2C0.14&scaling=contain&starting-point-node-id=2430%3A7961',
								'_blank'
							)
						}}
					/>
					<Button label="Intro" onClick={props.openIntro} />
				</Content>
			</BaseIntro>
		</Container>
	)
}

const Container = styled.div`
	position: absolute;
	top: 40px;
	display: flex;
	flex: 1;
	align-items: center;
	flex-direction: column;
	width: 100%;
	height: 488px;
	padding: 0 16px;
	background-color: ${standardBgColor};
`
const Content = styled.div`
	text-align: center;
	> button {
		margin-right: 10px;
		margin-bottom: 10px;
	}
`

export const Hero = styled.img`
	width: 160px;
`
