import * as React from 'react'
import styled from '@emotion/styled'
import { Button, Checkbox, Dropdown, Value } from '@ms-design/figma-ui-components'
import { textSecondaryColor, borderColor } from 'shared/SharedColors'
import { roleList, roles, PropertyTypes, ComponentType } from './Role'
import { IAnnotation } from 'controller/IAnnotation'
import { appInsights } from '../../Shared/AppInsights'
import { CircleNumber } from '../List/ListItem'
import { Sanitize } from 'shared/Sanitize'
import ArrowParent from 'assets/svgs/arrow-parent.svg'
import ArrowChild from 'assets/svgs/arrow-child.svg'
import InfoIcon from 'assets/svgs/info.svg'

const interactionList = ['Tab stop', 'Tab stop with arrow children', 'Arrow stop']

interface IEditItemProps {
	item: IAnnotation
	text: string
	cancelClick: () => void
	saveClick: (listItem: IAnnotation) => void
}

export const Edit = (props: IEditItemProps) => {
	const [name, setName] = React.useState(props.item?.name)
	const [role, setRole] = React.useState(props.item?.role)
	const [component, setComponent] = React.useState(props.item?.component)
	const [value, setValue] = React.useState(props.item?.value)
	const [valueItems, setValueItems] = React.useState(null)
	const [propertyItems, setPropertyItems] = React.useState(null)
	const [properties, setProperties] = React.useState(props.item?.properties)
	const [description, setDescription] = React.useState(props.item?.description)

	const [insightsName, setInsightsName] = React.useState(false)
	const [insightsDescription, setInsightsDescription] = React.useState(false)
	const [insightsValue, setInsightsValue] = React.useState(false)

	React.useEffect(() => {
		if (role) {
			const newRole = roleList.find((item) => item.role === role)

			// Value could be array or string
			if (Array.isArray(newRole.value)) {
				setValueItems(newRole.value)
			} else {
				setValueItems(null)
				setValue(newRole.value)
			}

			setPropertyItems(newRole.properties)
		} else {
			setValueItems(null)
			setValue(null)
			setPropertyItems(null)
		}
	}, [role])

	const handleSaveClick = () => {
		// Update edit date on set
		props.item.set.date = new Date().getTime().toString()

		const newItem: IAnnotation = {
			...props.item,
			name,
			component,
			role,
			value,
			properties,
			description,
		}

		props.saveClick(newItem)
	}

	const handleUpdateRole = (index: number) => {
		const newRole = index >= 0 ? roles[index] : null
		setRole(newRole)
		setValue(null)
		setProperties([])

		appInsights.trackEvent({ name: `CurrentAnnotations/Edit/Role/Item` }, { value: newRole })
	}

	const handleUpdateComponent = (index: number) => {
		const newComponent = index
		setComponent(newComponent)

		appInsights.trackEvent({ name: `CurrentAnnotations/Edit/Component/Item` }, { value: newComponent })
	}

	const handleCheckTheProp = (isChecked: boolean, label: PropertyTypes) => {
		if (isChecked) {
			setProperties([...properties, label])
		} else {
			const newValue = properties.filter((e) => e !== label)
			setProperties(newValue)
		}

		appInsights.trackEvent({ name: `CurrentAnnotations/Edit/Property` }, { value: label, isChecked })
	}

	const handleCheckTheValue = (isChecked: boolean, label: PropertyTypes) => {
		const myValue: PropertyTypes[] = value ? (value as PropertyTypes[]) : []
		if (isChecked) {
			setValue([...myValue, label])
		} else {
			const newValue = myValue.filter((e) => e !== label)
			setValue(newValue)
		}

		appInsights.trackEvent({ name: `CurrentAnnotations/Edit/Value` }, { value: label, isChecked })
	}

	const handleSetName = (text: string) => {
		setName(Sanitize(text))

		if (!insightsName) {
			setInsightsName(true)
			appInsights.trackEvent({ name: `CurrentAnnotations/Edit/NameField` })
		}
	}

	const handleSetValue = (text: string) => {
		setValue(Sanitize(text))

		if (!insightsValue) {
			setInsightsValue(true)
			appInsights.trackEvent({ name: `CurrentAnnotations/Edit/ValueField` })
		}
	}

	const handleDescriptionUpdate = (e) => {
		setDescription(Sanitize(e.currentTarget.innerText))

		if (!insightsDescription) {
			setInsightsDescription(true)
			appInsights.trackEvent({ name: `CurrentAnnotations/Edit/Description` })
		}
	}

	const roleClick = (isOpen: boolean) => {
		appInsights.trackEvent({ name: `CurrentAnnotations/Edit/Role` }, { isOpen })
	}

	const componentClick = (isOpen: boolean) => {
		appInsights.trackEvent({ name: `CurrentAnnotations/Edit/Component` }, { isOpen })
	}

	return (
		<Container>
			<List>
				<Header>
					<CircleNumber
						style={{
							border: component === ComponentType.PivotChild && '0',
							background: component === ComponentType.PivotChild && 'none',
						}}>
						{component === ComponentType.PivotChild && <Child src={ArrowChild} />}
						<NumberIndex>{props.text}</NumberIndex>
					</CircleNumber>
					{component === ComponentType.PivotParent && <Parent src={ArrowParent} />}

					<HeaderTitle>
						<Value style={{ fontWeight: 600 }} defaultValue={name} onChange={handleSetName} />
					</HeaderTitle>
				</Header>

				<Title>
					Interaction type
					<Info title="Tab stop: Tab or the standard focus interaction.  Tab stop with arrow childen: Identifies a group of elements that require arrow navigation.  Arrow stop: An element that requires arrow navigation.">
						<img src={InfoIcon} />
					</Info>
				</Title>
				<SectionColumn>
					<Dropdown
						list={interactionList}
						selected={component ? component : ComponentType.Standard}
						onListClick={handleUpdateComponent}
						onClick={componentClick}
					/>
				</SectionColumn>

				<Title>
					Role
					<Info title="Prioritize semantic html tags over aria-roles as a best practice for accessibility.  Selecting a role is a helpful way to communicate the type of interactive element.">
						<img src={InfoIcon} />
					</Info>
				</Title>
				<SectionColumn>
					<Dropdown
						list={roles}
						selected={getSelectedIndex(props.item?.role)}
						onListClick={handleUpdateRole}
						onClick={roleClick}
						placeholder={'Type for quick select'}
					/>
				</SectionColumn>

				{(typeof value === 'string' || valueItems) && (
					<>
						<Title>Value</Title>
						{valueItems && (
							<SectionColumn>
								{valueItems.map((item: PropertyTypes) => (
									<Checkbox key={item} checked={value?.includes(item)} label={item} onClick={handleCheckTheValue} />
								))}
							</SectionColumn>
						)}
						{typeof value === 'string' && (
							<SectionColumn>
								<Value defaultValue={value} onChange={handleSetValue} />
							</SectionColumn>
						)}
					</>
				)}

				{propertyItems?.length > 0 && (
					<>
						<Title>Properties</Title>

						<SectionRow>
							{propertyItems.map((item: PropertyTypes) => (
								<Checkbox key={item} checked={properties.includes(item)} label={item} onClick={handleCheckTheProp} />
							))}
						</SectionRow>
					</>
				)}

				<Title>Description</Title>
				<TextWrapper>
					<TextArea
						contentEditable={true}
						suppressContentEditableWarning={true}
						onInput={handleDescriptionUpdate}
						dangerouslySetInnerHTML={{ __html: props.item?.description }}
					/>
				</TextWrapper>
			</List>
			<Footer>
				<SpacingWrapper>
					<Button label={'Cancel'} onClick={props.cancelClick} outline={true} />
				</SpacingWrapper>
				<SpacingWrapper>
					<Button label={'Save'} onClick={handleSaveClick} />
				</SpacingWrapper>
			</Footer>
		</Container>
	)
}

const getSelectedIndex = (text: string): number => {
	const index = roles.indexOf(text)
	return index !== -1 ? index : 0
}

const Container = styled.div`
	display: flex;
	flex: 1;
	align-items: center;
	flex-direction: column;
	width: 100%;
`

const List = styled.div`
	display: flex;
	flex: 1;
	flex-direction: column;
	overflow: hidden;
	overflow-y: auto;
	width: 100%;
	padding: 3px 0;
`

const Header = styled.div`
	display: flex;
	align-items: center;
	height: 40px;
	min-height: 40px;
	padding: 0 14px;
`
const HeaderTitle = styled.div`
	font-weight: 600;
	padding-left: 15px;
	width: 100%;
	margin-top: -2px;
`
const Title = styled.div`
	display: flex;
	align-items: center;
	height: 32px;
	min-height: 32px;
	color: ${textSecondaryColor};
	padding: 0 16px;
`

const Parent = styled.img`
	width: 10px;
	top: 12px;
	left: 40px;
	position: absolute;
`

const NumberIndex = styled.span``
const Child = styled.img`
	left: 4px;
	position: absolute;
`

const SectionColumn = styled.div`
	display: flex;
	flex-direction: column;
	padding: 0px 7px;
`
const SectionRow = styled.div`
	display: flex;
	padding: 0px 7px;
`
const TextWrapper = styled.div`
	padding: 5px 16px;
`
const TextArea = styled.div`
	padding: 8px;
	padding-bottom: 30px; /* Min height does not allow height to expand for long text blocks */
	border: 1px solid ${borderColor};
	white-space: pre-wrap;
`

const Footer = styled.footer`
	display: flex;
	justify-content: flex-end;
	align-items: center;
	width: 100%;
	height: 65px;
	min-height: 65px;
	border-top: 1px solid ${borderColor};
	padding: 0 8px;
`

const SpacingWrapper = styled.div`
	padding: 0 8px;
`

const Info = styled.div`
	margin-left: 5px;

	img {
		width: 10px;
		top: -1px;
	}
`
