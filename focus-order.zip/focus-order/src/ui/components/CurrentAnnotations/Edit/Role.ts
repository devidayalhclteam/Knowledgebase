export enum ComponentType {
	Standard,
	PivotParent,
	PivotChild,
}

interface IRole {
	role: string
	value?: string | PropertyTypes[]
	properties: PropertyTypes[]
}

export enum PropertyTypes {
	Checked = 'checked',
	Disabled = 'disabled',
	Expanded = 'expanded',
	Haspopup = 'haspopup',
}

export const defaultRoleText = '—'
export const defaultPropertiesText = '—'
export const defaultValueText = '—'

export const roleList: IRole[] = [
	{ role: 'Alert', properties: [PropertyTypes.Haspopup] },
	{ role: 'Alertdialog', properties: [] },
	{ role: 'Button', properties: [PropertyTypes.Disabled, PropertyTypes.Expanded, PropertyTypes.Haspopup] },
	{
		role: 'Checkbox',
		value: [PropertyTypes.Checked],
		properties: [PropertyTypes.Disabled, PropertyTypes.Expanded, PropertyTypes.Haspopup],
	},
	{ role: 'Dialog', properties: [] },
	{ role: 'Img', properties: [] },
	{ role: 'Link', properties: [PropertyTypes.Disabled] },
	{ role: 'Select', properties: [PropertyTypes.Disabled, PropertyTypes.Expanded] },
	{ role: 'Option', properties: [] },
	{ role: 'Switch', properties: [PropertyTypes.Disabled, PropertyTypes.Checked] },
	{ role: 'Progressbar', properties: [] },
	{ role: 'Radiogroup', properties: [] },
	{ role: 'Radio', value: [PropertyTypes.Checked], properties: [PropertyTypes.Disabled, PropertyTypes.Haspopup] },
	{ role: 'Searchbox', properties: [] },
	{ role: 'Scrollbar', properties: [] },
	{ role: 'Slider', value: defaultValueText, properties: [PropertyTypes.Disabled] },
	{ role: 'Spinbutton', value: defaultValueText, properties: [] },
	{ role: 'Status', properties: [] },
	{ role: 'Tab', properties: [PropertyTypes.Disabled, PropertyTypes.Expanded, PropertyTypes.Haspopup] },
	{ role: 'Tablist', properties: [] },
	{ role: 'Tabpanel', properties: [] },
	{ role: 'Textbox', properties: [] },
	{ role: 'Timer', properties: [] },
	{ role: 'Tooltip', properties: [] },
	{ role: 'Combobox', value: defaultValueText, properties: [PropertyTypes.Disabled] },
	{ role: 'Grid', properties: [] },
	{ role: 'Gridcell', properties: [] },
	{ role: 'Navigation', properties: [] },
	{ role: 'List', properties: [] },
	{ role: 'Listbox', value: defaultValueText, properties: [PropertyTypes.Disabled] },
	{ role: 'Listitem', properties: [] },
	{ role: 'Menu', properties: [] },
	{ role: 'Menubar', properties: [] },
	{ role: 'Menuitem', properties: [] },
	{ role: 'Menuitemcheckbox', properties: [] },
	{ role: 'Menuitemradio', properties: [] },
	{ role: 'Tree', properties: [] },
	{ role: 'Treegrid', properties: [] },
	{ role: 'Treeitem', properties: [] },
	{ role: 'Article', properties: [] },
	{ role: 'Columnheader', properties: [] },
	{ role: 'Definition', properties: [] },
	{ role: 'Directory', properties: [] },
	{ role: 'Document', properties: [] },
	{ role: 'Group', properties: [] },
	{ role: 'Presentation', properties: [] },
	{ role: 'Row', properties: [] },
	{ role: 'Rowgroup', properties: [] },
	{ role: 'Rowheader', properties: [] },
	{ role: 'Toolbar', properties: [] },
]

export const roles: string[] = roleList.map((x) => x.role)
roles.sort()
