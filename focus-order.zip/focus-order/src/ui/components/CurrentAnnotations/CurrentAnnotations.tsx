import * as React from 'react'

import styled from '@emotion/styled'
import { LocationType } from '../App'
import { MessageType } from 'controller/MessageType'
import { IAnnotation, ISet } from 'controller/IAnnotation'
import { appInsights } from 'shared/AppInsights'
import { List, Edit } from '.'
import { ComponentType } from './Edit/Role'

interface ICurrentProps {
	currentSet: ISet
	setCurrentSet: (set: ISet) => void
	list: IAnnotation[]
	setList: (list: IAnnotation[]) => void
	setTabLocation: (location: LocationType) => void
	newSetName: string
	setNewSetName: (name: string) => void
	createNewSet: () => void
}

export const CurrentAnnotations = (props: ICurrentProps) => {
	const [location, setLocation] = React.useState(LocationType.Current)
	const [editItem, setEditItem] = React.useState(0)
	const [editItemText, setEditItemText] = React.useState(null)

	const handleEditClick = (index: number, text: string) => {
		setLocation(LocationType.Edit)

		// Find the current set's starting index
		let locationInList = props.list.findIndex((annotation) => annotation.set.id === props.currentSet.id)
		locationInList = locationInList ? locationInList : 0
		setEditItemText(text)
		setEditItem(locationInList + index)

		appInsights.trackEvent({ name: `CurrentAnnotations/Edit` })
	}

	const handleDeleteClick = (id: string) => {
		let newList: IAnnotation[] = []

		if (props.list.length === 1) {
			// We have no more sets.  All deleted
			props.setList(newList)
			props.setTabLocation(LocationType.Home)
			props.setCurrentSet(null)
		} else {
			// Check how many annotations are left in the set
			const currentSet = props.list.filter((annotation) => annotation.set.id === props.currentSet.id)
			const amountInSet = currentSet && currentSet.length

			const index: number = props.list.findIndex((item) => item.id === id)
			props.list.splice(index, 1)
			newList = props.list
			props.setList([...newList])

			// If we are deleting the last annotation in a set, the set is deleted, return to home
			if (amountInSet === 1) {
				props.setTabLocation(LocationType.Home)
				props.setCurrentSet(null)
			}
		}

		let setList: IAnnotation[] = newList.filter((annotation) => annotation.set.id === props.currentSet.id)
		setList = setList ? setList : []
		parent.postMessage({ pluginMessage: { type: MessageType.UpdateSet, list: setList, id: props.currentSet.id } }, '*')

		appInsights.trackEvent({ name: `CurrentAnnotations/Delete` })
	}

	/** Save update to annotation */
	const handleSaveClick = (newItem: IAnnotation) => {
		const newParentContainer = props.list[editItem].component !== newItem.component && newItem.component !== ComponentType.PivotChild
		props.list[editItem] = newItem

		setLocation(LocationType.Current)
		const setList: IAnnotation[] = props.list.filter((annotation) => annotation.set.id === props.currentSet.id)
		parent.postMessage(
			{
				pluginMessage: {
					type: MessageType.UpdateSet,
					list: setList,
					id: props.currentSet.id,
					newParentContainer: newParentContainer && props.list[editItem],
				},
			},
			'*'
		)

		appInsights.trackEvent({ name: `CurrentAnnotations/Edit/Save` })
	}

	/** Cancel update to annotation */
	const handleCancelClick = () => {
		setLocation(LocationType.Current)
		appInsights.trackEvent({ name: `CurrentAnnotations/Edit/Cancel` })
	}

	return (
		<Container>
			{location === LocationType.Current && (
				<List
					list={props.list}
					updateList={props.setList}
					editClick={handleEditClick}
					deleteClick={handleDeleteClick}
					currentSet={props.currentSet}
					setCurrentSet={props.setCurrentSet}
					setTabLocation={props.setTabLocation}
				/>
			)}
			{location === LocationType.Edit && (
				<Edit text={editItemText} item={props.list[editItem]} cancelClick={handleCancelClick} saveClick={handleSaveClick} />
			)}
		</Container>
	)
}

const Container = styled.div`
	display: flex;
	overflow: hidden;
	width: 100%;
	height: 100%;
`
