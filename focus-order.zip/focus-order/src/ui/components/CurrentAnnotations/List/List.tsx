import * as React from 'react'

import styled from '@emotion/styled'
import { Button, Value } from '@ms-design/figma-ui-components'
import { ListItem } from './ListItem'
import { MessageType } from 'controller/MessageType'
import { borderColor, buttonPrimaryColor, textSecondaryColor } from 'shared/SharedColors'
import { SortableItem, move, SortableList } from '../../Shared/SortList'
import { IAnnotation, IRGBA, ISet } from 'controller/IAnnotation'
import { Sanitize } from 'shared/Sanitize'
import { ColorPicker } from 'shared/ColorPicker/ColorPicker'
import { LocationType } from '../../App'
import { appInsights } from 'shared/AppInsights'
import { getZeroStateText, findNextText } from 'controller/CreateAnnotations'
import { ComponentType } from '../Edit/Role'

interface IAnnotationProps {
	list: IAnnotation[]
	editClick: (index: number, text: string) => void
	deleteClick: (id: string) => void
	updateList: (list: IAnnotation[]) => void
	currentSet: ISet
	setCurrentSet: (set: ISet) => void
	setTabLocation: (location: LocationType) => void
}

export const List = (props: IAnnotationProps) => {
	const ref = React.useRef()
	const listRefs = []
	const [input, setInput] = React.useState(props.currentSet ? props.currentSet.name : '')
	const [color, setColor] = React.useState<IRGBA>(props.currentSet ? props.currentSet.color : null)
	const [isColoPickerVisible, setIsColorPickerVisible] = React.useState(false)
	const [testIndex, setTestIndex] = React.useState(null)
	const [annotations, setAnnotations] = React.useState<IAnnotation[]>([])
	const [isEditingHeader, setIsEditingHeader] = React.useState(false)

	const [insightsName, setInsightsName] = React.useState(false)

	React.useEffect(() => {
		if (props.list?.length && props.currentSet) {
			const annotationList = props.list.filter((annotation) => annotation.set.id === props.currentSet.id)
			setAnnotations(annotationList)
		} else {
			setAnnotations([])
		}
	}, [props.list, props.currentSet])

	React.useEffect(() => {
		if (props.currentSet) {
			if (props.currentSet.name !== input || props.currentSet.color !== color) {
				setIsEditingHeader(true)
			}
		}
	}, [color, input])

	const onSortEnd = ({ oldIndex, newIndex }) => {
		// Find the current set's starting index
		let locationInList = props.list.findIndex((annotation) => annotation.set.id === props.currentSet.id)
		locationInList = locationInList ? locationInList : 0

		// Update list positions in Mega list
		const newList: IAnnotation[] = move(props.list, oldIndex + locationInList, newIndex + locationInList)
		props.updateList(newList)

		const setList: IAnnotation[] = newList.filter((annotation) => annotation.set.id === props.currentSet.id)
		parent.postMessage({ pluginMessage: { type: MessageType.UpdateSet, list: setList, id: props.currentSet.id } }, '*')

		appInsights.trackEvent({ name: `CurrentAnnotations/DragAnnotation` })
	}

	/** Cancel edits to header */
	const handleCancelClick = () => {
		if (props.currentSet) {
			setInput(props.currentSet.name)
			setColor(props.currentSet.color)
			setIsEditingHeader(false)
		}

		appInsights.trackEvent({ name: `CurrentAnnotations/Header/Cancel` })
	}

	/** Save edits to header */
	const handleSaveClick = () => {
		/* Update set name and color */
		annotations.map((annotation) => {
			annotation.set.name = input
			annotation.set.color = color
		})

		props.setCurrentSet({
			id: props.currentSet.id,
			name: input,
			artboard: props.currentSet.artboard,
			color,
			date: props.currentSet.date,
		})

		setIsEditingHeader(false)

		parent.postMessage({ pluginMessage: { type: MessageType.UpdateSet, list: annotations, id: props.currentSet.id } }, '*')

		appInsights.trackEvent({ name: `CurrentAnnotations/Header/Save` })
	}

	/** Test annotations */
	const handleTestClick = (e?: MouseEvent) => {
		e.stopPropagation()
		const nextIndex = annotations.findIndex((x) => x.component !== ComponentType.PivotChild)
		if (nextIndex >= 0) {
			setTestIndex(nextIndex)
			parent.postMessage({ pluginMessage: { type: MessageType.SelectAnnotation, id: annotations[0].id, scrollIntoView: true } }, '*')
		}
		appInsights.trackEvent({ name: `CurrentAnnotations/Test` })
	}

	const handleEndTestClick = () => {
		setTestIndex(null)
		appInsights.trackEvent({ name: `CurrentAnnotations/End Test` })
	}

	const changeTestIndex = (e: any) => {
		let nextIndex = testIndex

		if (!e.shiftKey && e.key === 'Tab' && nextIndex < annotations.length - 1) {
			// Next index
			nextIndex = annotations.findIndex((x, index) => x.component !== ComponentType.PivotChild && nextIndex < index)
		} else if (e.shiftKey && e.key === 'Tab' && nextIndex) {
			// Prev index
			const reverseArray = [...annotations].reverse()
			const reversedIndex = annotations.length - 1 - nextIndex
			nextIndex = reverseArray.findIndex((x, index) => x.component !== ComponentType.PivotChild && reversedIndex < index)
			nextIndex = reverseArray.length - 1 - nextIndex
		} else if ((!e.shiftKey && e.key === 'Tab') || (e.shiftKey && e.key === 'Tab')) {
			parent.postMessage({ pluginMessage: { type: MessageType.Notification, text: 'No tab stop in that direction' } }, '*')
		}

		if (nextIndex >= 0) {
			setTestIndex(nextIndex)
			parent.postMessage(
				{ pluginMessage: { type: MessageType.SelectAnnotation, id: annotations[nextIndex].id, scrollIntoView: true } },
				'*'
			)
		} else {
			parent.postMessage({ pluginMessage: { type: MessageType.Notification, text: 'No tab stop in that direction' } }, '*')
		}
	}

	/** Add new annotation to list */
	const handleAddClick = () => {
		// Update annotation set date
		props.currentSet.date = new Date().getTime().toString()

		parent.postMessage({ pluginMessage: { type: MessageType.NewAnnotations, set: props.currentSet } }, '*')
	}

	const handleSetNameInput = (value: string) => {
		setInput(Sanitize(value))

		if (!insightsName) {
			setInsightsName(true)
			appInsights.trackEvent({ name: `CurrentAnnotations/Header/NameField` })
		}
	}

	const handleBackClick = () => {
		props.setTabLocation(LocationType.Home)
		appInsights.trackEvent({ name: `CurrentAnnotations/Back` })
	}

	const openColorPicker = () => {
		setIsColorPickerVisible(true)
		appInsights.trackEvent({ name: `CurrentAnnotations/Header/ColorPicker` })
	}

	let currentIndex: string = '0'
	let retainLastTextIndex: number = 0
	return (
		<Container ref={ref} onClick={() => setTestIndex(null)}>
			<Header>
				<Title> Annotation set name </Title>
				<SetDetails>
					<ColorButton onClick={openColorPicker}>
						<Swatch style={{ backgroundColor: `rgba(${color?.r},${color?.g},${color?.b},${color?.a})` }} />
					</ColorButton>
					<Value defaultValue={input} onChange={handleSetNameInput} />
				</SetDetails>

				{isColoPickerVisible && (
					<ColorPicker
						color={color}
						close={(newColor: IRGBA) => {
							setIsColorPickerVisible(false)
							if (newColor) {
								setColor(newColor)
								appInsights.trackEvent({ name: `CurrentAnnotations/Header/ColorPicker/Color` })
							}
						}}
					/>
				)}
			</Header>
			<SortableList helperContainer={ref.current} lockAxis="y" distance={2} onSortEnd={onSortEnd}>
				<ListWrapper>
					{annotations.map((item: IAnnotation, index: number) => {
						listRefs.push(React.createRef<HTMLDivElement>())
						retainLastTextIndex = Number.isNaN(Number(currentIndex)) ? retainLastTextIndex : Number(currentIndex)
						currentIndex =
							index === 0 ? getZeroStateText(item.component) : findNextText(currentIndex, item.component, retainLastTextIndex)
						return (
							item && (
								<SortableItem key={index} index={index}>
									<ListItem
										ref={listRefs[index]}
										index={index}
										text={currentIndex}
										item={item}
										editClick={props.editClick}
										deleteClick={props.deleteClick}
										isTesting={testIndex !== null}
										testIndex={testIndex === index}
										changeTestIndex={changeTestIndex}
										isLastItem={index === annotations.length - 1 && annotations.length > 3}
									/>
								</SortableItem>
							)
						)
					})}
				</ListWrapper>
			</SortableList>
			<Footer>
				<BackButton onClick={handleBackClick}>Back</BackButton>
				<ButtonSpacer />
				{isEditingHeader ? (
					<>
						{annotations.length > 0 && (
							<SpacingWrapper>
								<Button label={'Cancel'} onClick={handleCancelClick} outline={true} />
							</SpacingWrapper>
						)}
						<SpacingWrapper>
							<Button label={'Save'} onClick={handleSaveClick} />
						</SpacingWrapper>
					</>
				) : testIndex === null ? (
					<>
						{annotations.length > 0 && (
							<SpacingWrapper>
								<Button label={'Test'} onClick={handleTestClick} outline={true} />
							</SpacingWrapper>
						)}
						<SpacingWrapper>
							<Button label={'Add'} onClick={handleAddClick} />
						</SpacingWrapper>
					</>
				) : (
					<SpacingWrapper>
						<Button label={'End Test'} onClick={handleEndTestClick} outline={true} />
					</SpacingWrapper>
				)}
			</Footer>
		</Container>
	)
}

const Container = styled.div`
	display: flex;
	flex-direction: column;
	flex: 1;
	width: 100%;
`

const ListWrapper = styled.div`
	display: flex;
	flex: 1;
	flex-direction: column;
	overflow: hidden;
	overflow-y: auto;
	width: 100%;
`

const Header = styled.div`
	display: flex;
	flex-direction: column;
	padding: 8px 15px 8px;
	border-bottom: 1px solid ${borderColor};
`
const Title = styled.div`
	display: flex;
	align-items: center;
	height: 32px;
	color: ${textSecondaryColor};
	padding: 8px;
	padding-left: 0;
`
const SetDetails = styled.div`
	display: flex;
	align-items: center;
`
const ColorButton = styled.button`
	display: flex;
	align-items: center;
	border-radius: 3px;
	border: 1px solid ${borderColor};
	padding: 5px;
	height: 25px;
	width: 33px;
	margin-right: 5px;
`

const Swatch = styled.div`
	display: flex;
	width: 100%;
	height: 100%;
`

export const BackButton = styled.button`
	cursor: pointer;
	display: flex;
	padding: 9px;
	color: ${buttonPrimaryColor};
`

export const ButtonSpacer = styled.div`
	display: flex;
	flex: 1;
`

export const Footer = styled.footer`
	display: flex;
	justify-content: flex-end;
	align-items: center;
	width: 100%;
	height: 65px;
	min-height: 65px;
	border-top: 1px solid ${borderColor};
	padding: 0 8px;
`

export const SpacingWrapper = styled.div`
	padding: 0 8px;
`
