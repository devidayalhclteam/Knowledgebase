import * as React from 'react'

import styled from '@emotion/styled'
import Gripper from 'assets/svgs/gripper.svg'
import Edit from 'assets/svgs/pencil.svg'
import Delete from 'assets/svgs/trash.svg'
import ArrowParent from 'assets/svgs/arrow-parent.svg'
import ArrowChild from 'assets/svgs/arrow-child.svg'

import {
	borderColor,
	hoverItemColor,
	textSecondaryColor,
	circleBorderColor,
	activeItemColor,
	standardBgColor,
	transitionTiming,
} from 'shared/SharedColors'
import { MessageType } from 'controller/MessageType'
import { IAnnotation } from 'controller/IAnnotation'
import { ComponentType, defaultRoleText } from '../Edit/Role'
import { GetValueString } from 'ui/components/Shared/GetValueString'
import { GetPropsString } from 'ui/components/Shared/GetPropsString'
import { IconButton } from '@ms-design/figma-ui-components'

interface IOrderItemProps {
	index: number
	text: string
	item: IAnnotation
	testIndex: boolean
	isTesting: boolean
	editClick: (index: number, text: string) => void
	deleteClick: (id: string) => void
	changeTestIndex: (e: any) => void
	isLastItem: boolean
}

export const ListItem = React.forwardRef((props: IOrderItemProps, ref: React.RefObject<HTMLDivElement>) => {
	const [isHover, setIsHover] = React.useState(false)

	React.useEffect(() => {
		if (props.testIndex) {
			ref.current.focus()
		}
	}, [props.testIndex])

	const handleClick = () => {
		parent.postMessage({ pluginMessage: { type: MessageType.SelectAnnotation, id: props.item.id } }, '*')
	}

	return (
		<ItemContainer
			ref={ref}
			tabIndex={-1}
			onKeyDown={props.changeTestIndex}
			onFocus={handleClick}
			onMouseEnter={() => !props.isTesting && setIsHover(true)}
			onMouseLeave={() => !props.isTesting && setIsHover(false)}
			onMouseMove={() => !props.isTesting && setIsHover(true)}
			onClick={handleClick}
			style={{
				backgroundColor: props.testIndex ? activeItemColor : isHover ? hoverItemColor : 'transparent',
				borderBottom: props.isLastItem ? 'none' : `1px solid ${borderColor}`,
			}}>
			<Handle style={{ opacity: isHover ? 1 : 0 }}>
				<img src={Gripper} />
			</Handle>
			<CircleNumber
				style={{
					border: props.item.component === ComponentType.PivotChild && '0',
					background: props.item.component === ComponentType.PivotChild && 'none',
				}}>
				{props.item.component === ComponentType.PivotChild && <Child src={ArrowChild} />}
				<NumberIndex>{props.text}</NumberIndex>
			</CircleNumber>
			{props.item.component === ComponentType.PivotParent && <Parent src={ArrowParent} />}
			<Content>
				<Name>{props.item.name}</Name>

				<Detail>
					<Title>Role:</Title> <Item>{props.item.role ? props.item.role : defaultRoleText}</Item>
				</Detail>
				<Detail>
					<Title>Value:</Title>
					<Item>
						<Ellipse>{GetValueString(props.item.value)}</Ellipse>
					</Item>
				</Detail>

				<Detail>
					<Title>Props:</Title>
					<Item>
						<Ellipse>{GetPropsString(props.item.properties)}</Ellipse>
					</Item>
				</Detail>
			</Content>
			<Buttons className="buttons">
				<IconButton onClick={() => props.editClick(props.index, props.text)}>
					<img src={Edit} />
				</IconButton>
				<IconButton onClick={() => props.deleteClick(props.item.id)}>
					<img src={Delete} />
				</IconButton>
			</Buttons>
		</ItemContainer>
	)
})

const ItemContainer = styled.div`
	display: flex;
	height: 80px;
	padding: 6px 0;
	padding-right: 5px;

	transition: background-color ${transitionTiming}ms ease-in;

	&:hover {
		> .buttons {
			opacity: 1;
		}
	}

	> .buttons {
		opacity: 0;
		transition: opacity ${transitionTiming}ms ease-in;
	}
`

const Name = styled.div`
	font-weight: 600;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	padding-bottom: 1;
`
const Detail = styled.div`
	display: flex;
`
const Title = styled.div`
	width: 40px;
	color: ${textSecondaryColor};
	padding-right: 5px;
`
const Ellipse = styled.span`
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
`
const Item = styled.div`
	display: flex;
	overflow: hidden;
`
const Handle = styled.div`
	display: flex;
	margin-top: 3px;
	justify-content: center;
	align-items: center;
	width: 16px;
	height: 100%;
	transition: opacity ${transitionTiming}ms ease-in;

	img {
		height: 16px;
	}
`
export const CircleNumber = styled.div`
	display: flex;
	justify-content: center;
	align-items: center;
	width: 24px;
	height: 24px;
	min-width: 24px;
	border-radius: 100%;
	border: 0.5px solid ${circleBorderColor};
	background-color: ${standardBgColor};
	font-size: 11px;
`
const Parent = styled.img`
	width: 10px;
	top: 11px;
	left: 42px;
	position: absolute;
`
const NumberIndex = styled.span``
const Child = styled.img`
	left: 4px;
	position: absolute;
`

const Content = styled.div`
	flex: 1;
	display: flex;
	flex-direction: column;
	padding: 0 5px 0 20px;

	max-width: 195px;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
`
const Buttons = styled.div`
	display: flex;
	align-items: center;
`
