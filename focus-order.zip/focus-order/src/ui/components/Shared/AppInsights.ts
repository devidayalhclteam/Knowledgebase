import { ApplicationInsights } from '@microsoft/applicationinsights-web'

const instrumentationKey =
	process.env.NODE_ENV === 'production' ? process.env.REACT_APP_INSIGHTS_KEY_PROD : process.env.REACT_APP_INSIGHTS_KEY_DEV

/** appInsights events and tracking run in UI only.  Figma does not allow in Controller (no errors are thrown, fails silently ) */
export const appInsights = new ApplicationInsights({
	config: {
		instrumentationKey,
		/* ...Other Configuration Options... */
	},
})

appInsights.loadAppInsights()
appInsights.trackPageView({ name: 'Focus Orderer' })
