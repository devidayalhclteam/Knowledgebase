import * as React from 'react'
import styled from '@emotion/styled'
import { LocationType } from 'ui/components/App'
import { borderColor, textPrimaryColor, textSecondaryColor } from '../SharedColors'
import { appInsights } from '../AppInsights'

interface ITabHeaderProps {
	isHome: boolean
	isAboutVisible: boolean
	isCurrentAnnotations: boolean
	setIsAboutVisible: (isVisible: boolean) => void
	setLocation: (location: LocationType) => void
	annotationsPresent?: boolean
}

export const TabHeader = (props: ITabHeaderProps) => {
	return (
		<Header>
			<HeaderButton
				onClick={() => {
					props.setIsAboutVisible(false)
					props.setLocation(LocationType.Home)
					appInsights.trackEvent({ name: `Home` })
				}}
				style={{
					color: (!props.isHome || props.isAboutVisible) && textSecondaryColor,
				}}>
				Home
			</HeaderButton>

			<HeaderButton
				onClick={() => {
					props.setIsAboutVisible(false)
					props.setLocation(LocationType.Current)
					appInsights.trackEvent({ name: `CurrentAnnotations` })
				}}
				style={{
					color: (!props.isCurrentAnnotations || props.isAboutVisible) && textSecondaryColor,
					pointerEvents: !props.annotationsPresent ? 'none' : 'initial',
				}}>
				Current Annotations
			</HeaderButton>

			<HeaderButton
				onClick={() => {
					props.setIsAboutVisible(true)
					appInsights.trackEvent({ name: `About` })
				}}
				style={{
					color: !props.isAboutVisible && textSecondaryColor,
				}}>
				About
			</HeaderButton>
		</Header>
	)
}

const Header = styled.div`
	display: flex;
	height: 40px;
	min-height: 40px;
	padding: 0 8px;
	font-size: 14px;
	border-bottom: 1px solid ${borderColor};
`
const HeaderButton = styled.button`
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100%;
	font-weight: 600;
	padding: 0 8px;

	&:hover {
		color: ${textPrimaryColor} !important;
	}
`
