import { defaultValueText, PropertyTypes } from '../CurrentAnnotations/Edit/Role'

export const GetPropsString = (props: PropertyTypes[]): string => {
	if (props?.length) {
		const propsString = props.join(', ')
		return propsString.charAt(0).toUpperCase() + propsString.slice(1)
	}

	return defaultValueText
}
