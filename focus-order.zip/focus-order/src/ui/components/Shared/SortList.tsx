import { IAnnotation } from 'controller/IAnnotation'
import * as React from 'react'

import { SortableContainer, SortableElement } from 'react-sortable-hoc'

export const SortableList = SortableContainer(({ children }) => <>{children}</>)

// Div wrapper required for animation
export const SortableItem = SortableElement(({ children }) => <div>{children}</div>)

// Using move function instead of using moveArray package
// https://codesandbox.io/s/pbey6?file=/src/index.js:236-260
export const move = (collection: IAnnotation[], fromIndex: number, toIndex: number) => {
	const result: IAnnotation[] = []
	const shift = toIndex - fromIndex > 0 ? 1 : -1
	const start = toIndex < fromIndex ? toIndex : fromIndex
	const end = start < toIndex ? toIndex : fromIndex

	for (let index = 0; index < collection.length; index++) {
		const offset = index >= start && index <= end ? shift : 0
		result[index] = collection[index + offset]
	}

	result[toIndex] = collection[fromIndex]

	return result
}
