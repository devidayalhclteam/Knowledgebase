import * as React from 'react'
import styled from '@emotion/styled'
import FilterIcon from './assets/filter.svg'
import { hoverItemColor } from '../SharedColors'
import { OutsideClick } from '../OutsideClick'
import { IconButton, Menu } from '@ms-design/figma-ui-components'

const selectionList = [
	{
		text: 'Recent',
	},
	{
		text: 'A - Z',
	},
	{
		text: 'Z - A',
	},
]

interface IFilterButtonProps {
	filterDate: () => void
	filterAscending: () => void
	filterDescending: () => void
	filterClick: (isOpen: boolean) => void
}

export const FilterButton = (props: IFilterButtonProps) => {
	const ref = React.useRef()
	const [isFilterVisible, setIsFilterVisible] = React.useState(false)
	const [isActive, setIsActive] = React.useState(0)

	OutsideClick(ref, () => {
		if (isFilterVisible) {
			props.filterClick(false)
			setIsFilterVisible(false)
		}
	})

	const handleFilterClick = () => {
		props.filterClick(!isFilterVisible)

		setIsFilterVisible(!isFilterVisible)
	}

	return (
		<Container>
			<IconButton onClick={handleFilterClick} backgroundColor={isFilterVisible && hoverItemColor}>
				<img src={FilterIcon} />
			</IconButton>
			{isFilterVisible && (
				<Dropdown ref={ref}>
					<Menu
						list={selectionList}
						selected={isActive}
						onClick={(item, index) => {
							switch (item.text) {
								case selectionList[1].text:
									props.filterAscending()
									break
								case selectionList[2].text:
									props.filterDescending()
									break
								default:
									props.filterDate()
									break
							}
							setIsActive(index)
							setIsFilterVisible(false)
						}}
					/>
				</Dropdown>
			)}
		</Container>
	)
}

const Container = styled.div``
const Dropdown = styled.ul`
	position: absolute;
	top: 35px;
	right: 0;
	width: 288px;
	list-style: none;
	z-index: 100;
`
