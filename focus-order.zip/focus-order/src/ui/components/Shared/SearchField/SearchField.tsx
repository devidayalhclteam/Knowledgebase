import * as React from 'react'
import styled from '@emotion/styled'
import { borderColor, textPrimaryColor, transitionTiming } from '../SharedColors'
import SearchIcon from './assets/search.svg'
import CloseIcon from './assets/close.svg'
import { FilterButton } from './FilterButton'
import { Sanitize } from '../Sanitize'

interface ISearchFieldProps {
	setSearch: (value: string) => void
	searchValue?: string
	filterDate: () => void
	filterAscending: () => void
	filterDescending: () => void
	filterClick: (isOpen: boolean) => void
	cancelClick: () => void
}

export const SearchField = (props: ISearchFieldProps) => {
	const inputRef = React.useRef<HTMLInputElement>()
	const [value, setValue] = React.useState(props.searchValue ? props.searchValue : '')

	React.useEffect(() => {
		if (value?.length) {
			props.setSearch(value)
		} else {
			props.setSearch(null)

			if (inputRef && inputRef.current) {
				inputRef.current.focus()
			}
		}
	}, [value])

	const handleCancelClick = () => {
		props.cancelClick()
		setValue('')
	}

	return (
		<SearchContainer>
			<Input ref={inputRef} placeholder="Search" value={value} onChange={(e) => setValue(Sanitize(e.target.value))} />
			<Icon src={SearchIcon} />
			{value?.length > 0 && <CancelButton onClick={handleCancelClick} src={CloseIcon} />}
			<FilterButton
				filterClick={props.filterClick}
				filterDate={props.filterDate}
				filterAscending={props.filterAscending}
				filterDescending={props.filterDescending}
			/>
		</SearchContainer>
	)
}

const SearchContainer = styled.div`
	display: flex;
	align-items: center;
	height: 40px;
	width: 100%;
	border-bottom: 1px solid ${borderColor};
	padding: 8px;
`

const Icon = styled.img`
	position: absolute;
	top: 14px;
	left: 19px;
`

const CancelButton = styled.img`
	opacity: 0.3;
	transition: opacity ${transitionTiming} ease-in;

	&:hover {
		opacity: 1;
	}
`

const Input = styled.input`
	width: 100%;
	height: 32px;
	min-height: 32px;
	border: 0;
	padding: 0 8px;
	padding-left: 32px;
	font-size: 11px;
	color: ${textPrimaryColor};

	&::placeholder {
		font-size: 11px;
	}
`
