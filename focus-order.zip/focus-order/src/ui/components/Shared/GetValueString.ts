import { PropertyTypes } from '../CurrentAnnotations/Edit/Role'
import { GetPropsString } from './GetPropsString'

export const GetValueString = (value: string | PropertyTypes[]): string => {
	// Value can be string or array
	if (typeof value === 'string' && value?.length) {
		return value
	}
	// Get string of props
	return GetPropsString(value as PropertyTypes[])
}
