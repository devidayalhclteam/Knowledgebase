import { IRGBA } from "controller/IAnnotation"

/* Default text colors */
export const textPrimaryColor = 'rgba(0,0,0,0.8)'
export const textSecondaryColor = 'rgba(0, 0, 0, 0.3)'

export const standardBgColor = '#ffffff'
export const purpleBgColor = '#7b61ff'
export const borderColor = '#e5e5e5'

/* List colors */
export const activeItemColor = '#EDF5FA'
export const hoverItemColor = 'rgba(0, 0, 0, 0.06)'
export const circleBorderColor = '#e4e4e4'

/* Button colors */
export const buttonTextColor = 'rgba(0,0,0,0.8)'
export const buttonPrimaryColor = '#18A0FB'
export const buttonPrimaryTextColor = '#ffffff'

export const transitionTiming = 250


/* Dropdown colors */
export const dropDownBgColor = '#222222'

/* Annotation colors */
export const defaultAnnotationColor:IRGBA = {
    r:194,
    g:38,
    b:222,
    a:1
}

/* Overlay */
export const overlayBgColor = 'rgba(0, 0, 0, 0.1)'