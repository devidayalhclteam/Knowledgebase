import * as React from 'react'

import styled from '@emotion/styled'
import { overlayBgColor, standardBgColor } from '../SharedColors'
import { Slider } from './Slider'
import { ColorSquare } from './ColorSquare'
import { IHSV } from './utilities/consts'
import { Rgb2Hsv } from './utilities/Rgb2Hsv'
import { IRGBA } from 'controller/IAnnotation'
import { Rgb2Hex } from './utilities/Rgb2Hex'
import { Sanitize } from 'shared/Sanitize'
import { Hex2Rgb } from './utilities/Hex2Rgb'
import { Value } from '@ms-design/figma-ui-components'

interface IColorPickerProps {
	color: IRGBA
	close: (newColor: IRGBA) => void
}

export const ColorPicker = (props: IColorPickerProps) => {
	const [color, setColor] = React.useState(props.color)
	const [hsv, setHsv] = React.useState<IHSV>(Rgb2Hsv(color))
	const [hexInput, setHexInput] = React.useState('#' + Rgb2Hex(color).toUpperCase())
	const [percentInput, setPercentInput] = React.useState(color.a * 100 + '%')
	const [isDragging, setIsDragging] = React.useState(false)

	const handleOnBlurHex = (e) => {
		let newColor = Sanitize(e?.target?.value?.replace('#', '').toUpperCase())
		newColor = newColor.length === 3 ? newColor + newColor : newColor
		if (newColor.length === 6) {
			const rgb = Hex2Rgb('#' + newColor)
			setColor({ ...rgb, a: color.a })
			setHsv(Rgb2Hsv(rgb))
			setHexInput('#' + newColor)
		}
	}

	const handleOnBlurPercent = (e) => {
		let newPercent = parseInt(Sanitize(e?.target?.value), 10)
		if (newPercent) {
			newPercent = newPercent > 100 ? 100 : newPercent
			setColor({ ...color, a: newPercent / 100 })
			setPercentInput(newPercent + '%')
		}
	}

	const handleSetColor = (newColor: IRGBA) => {
		setColor(newColor)
		setHsv(Rgb2Hsv(newColor))
		setHexInput('#' + Rgb2Hex(newColor).toUpperCase())
		setPercentInput(newColor.a * 100 + '%')
	}

	return (
		<Background
			onClick={() => !isDragging && props.close(color !== props.color && color)}
			onMouseDown={() => setIsDragging(true)}
			onMouseUp={() => setIsDragging(false)}>
			<Container onClick={(e) => e.stopPropagation()}>
				<Wrapper>
					<ColorSquare isDragging={isDragging} color={color} hsv={hsv} updateColor={handleSetColor} />
					<Sliders>
						<SelectedColor style={{ backgroundColor: `rgba(${color.r},${color.g},${color.b},${color.a})` }} />
						<SliderWrapper>
							<Slider isDragging={isDragging} color={color} hsv={hsv} updateColor={handleSetColor} />
							<Slider isDragging={isDragging} color={color} updateColor={handleSetColor} />
						</SliderWrapper>
					</Sliders>
					<Readout>
						<FormatButton>HEX</FormatButton>
						<Value defaultValue={hexInput} blur={handleOnBlurHex} submit={handleOnBlurHex} />
						<Value
							defaultValue={percentInput}
							blur={handleOnBlurPercent}
							submit={handleOnBlurPercent}
							style={{ width: '50px', marginLeft: '10px' }}
						/>
					</Readout>
				</Wrapper>
			</Container>
		</Background>
	)
}

const Background = styled.div`
	position: fixed;
	position: fixed;
	left: 0;
	top: 0;
	z-index: 1000;
	display: flex;
	justify-content: center;
	align-items: center;
	width: 100%;
	height: 100%;
	box-shadow: 0px 2px 14px rgba(0, 0, 0, 0.15);
	background-color: ${overlayBgColor};
`
const Container = styled.div`
	display: flex;
	flex-direction: column;
	width: 240px;
	height: 344px;
	border: 4px solid transparent;
	box-sizing: content-box;
`
const Wrapper = styled.div`
	background-color: ${standardBgColor};
`
const Sliders = styled.div`
	display: flex;
	padding: 16px 8px 0px 8px;
`
const SelectedColor = styled.div`
	display: flex;
	width: 40px;
	height: 40px;
	min-width: 40px;
	margin-right: 8px;
`

const SliderWrapper = styled.div`
	display: flex;
	width: 100%;
	flex-direction: column;
	justify-content: space-between;
`

const Readout = styled.div`
	display: flex;
	align-items: center;
	padding: 8px;
`
const FormatButton = styled.button`
	display: flex;
	align-items: center;
	width: 85px;
	height: 32px;
	padding: 8px;
`
