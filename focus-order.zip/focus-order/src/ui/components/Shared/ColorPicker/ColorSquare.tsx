import * as React from 'react'
import styled from '@emotion/styled'
import { IHSV, MAX_COLOR_SATURATION, MAX_COLOR_VALUE } from './utilities/consts'
import { Clamp } from './utilities/Clamp'
import { Hsv2Rgb } from './utilities/Hsv2Rgb'
import { GetFullColorString } from './utilities/GetFullColorString'
import { IRGBA } from 'controller/IAnnotation'

interface IColorSquareProps {
	color: IRGBA
	hsv: IHSV
	updateColor: (color: IRGBA) => void
	isDragging: boolean
}

export const ColorSquare = (props: IColorSquareProps) => {
	const ref = React.useRef<HTMLDivElement>()
	const { s, v } = props.hsv
	const handleClick = (e: any) => {
		const newColor = GetNewColor(e, ref, props)
		if (newColor) {
			props.updateColor(newColor)
		}
	}

	const handleMouseMove = (e: any) => {
		if (props.isDragging) {
			handleClick(e)
		}
	}

	return (
		<Container
			ref={ref}
			style={{ backgroundColor: props.hsv && GetFullColorString(props.hsv) }}
			onMouseDown={handleClick}
			onMouseMove={handleMouseMove}>
			<Light />
			<Dark />
			<Thumb
				style={{
					left: s + '%',
					top: MAX_COLOR_VALUE - v + '%',
					backgroundColor: `rgb(${props.color.r},${props.color.g},${props.color.b})`,
				}}
			/>
		</Container>
	)
}

const GetNewColor = (e: MouseEvent, containerRef: any, props: IColorSquareProps): IRGBA => {
	const squareSize = containerRef.current.getBoundingClientRect()

	let s = (e.clientX - squareSize.left) / squareSize.width
	s = Clamp(Math.round(s * MAX_COLOR_SATURATION), MAX_COLOR_SATURATION)
	let v = (e.clientY - squareSize.top) / squareSize.height
	v = Clamp(Math.round(MAX_COLOR_VALUE - v * MAX_COLOR_VALUE), MAX_COLOR_VALUE)

	const rgb = Hsv2Rgb(props.hsv.h, s, v)

	return { ...rgb, a: props.color.a }
}

const Container = styled.div`
	position: relative;
	width: 240px;
	height: 240px;
`
const Light = styled.div`
	position: absolute;
	left: 0;
	right: 0;
	top: 0;
	bottom: 0;
	background: linear-gradient(to right, white 0%, transparent 100%);
`

const Dark = styled.div`
	position: absolute;
	left: 0;
	right: 0;
	top: 0;
	bottom: 0;
	background: linear-gradient(to bottom, transparent 0, #000 100%);
`

export const Thumb = styled.div`
	position: absolute;
	width: 12px;
	height: 12px;
	background: white;
	border-radius: 100%;
	border: 2px solid white;
	transform: translate(-50%, -50%);
`
