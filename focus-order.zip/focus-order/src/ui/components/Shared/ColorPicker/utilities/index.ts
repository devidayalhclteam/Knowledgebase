export { IRGB } from './consts'
