import { Hsv2Rgb } from './Hsv2Rgb';
import { Rgb2Hex } from './Rgb2Hex';

/** Converts HSV components to a hex color string (without # prefix). */
export function Hsv2Hex(h: number, s: number, v: number): string {
  const rgb = Hsv2Rgb(h, s, v);

  return Rgb2Hex(rgb);
}