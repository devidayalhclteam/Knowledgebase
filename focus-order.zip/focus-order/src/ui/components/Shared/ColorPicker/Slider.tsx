import * as React from 'react'
import styled from '@emotion/styled'
import { Thumb } from './ColorSquare'
import { IHSV, MAX_COLOR_ALPHA, MAX_COLOR_HUE } from './utilities/consts'
import { Clamp } from './utilities/Clamp'
import { GetFullColorString } from './utilities/GetFullColorString'
import { IRGBA } from 'controller/IAnnotation'
import { Hsv2Rgb } from './utilities/Hsv2Rgb'

interface ISliderProps {
	color: IRGBA
	hsv?: IHSV
	updateColor: (color: IRGBA) => void
	isDragging: boolean
}

const hueStyle = {
	background: `linear-gradient(${[
		'to left',
		'red 0',
		'#f09 10%',
		'#cd00ff 20%',
		'#3200ff 30%',
		'#06f 40%',
		'#00fffd 50%',
		'#0f6 60%',
		'#35ff00 70%',
		'#cdff00 80%',
		'#f90 90%',
		'red 100%',
	].join(',')})`,
}

const alphaStyle = {
	backgroundImage:
		'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAJUlEQVQYV2N89erVfwY0ICYmxoguxjgUFKI7GsTH5m4M3w1ChQC1/Ca8i2n1WgAAAABJRU5ErkJggg==)',
}

export const Slider = (props: ISliderProps) => {
	const ref = React.useRef<HTMLDivElement>()
	const [percent, setPercent] = React.useState(0)

	const thumbBackground = props.hsv
		? GetFullColorString(props.hsv)
		: props.color && `rgba(${props.color.r},${props.color.g},${props.color.b},${props.color.a})`

	React.useEffect(() => {
		const value = props.hsv ? props.hsv.h : props.color.a * 100
		const maxValue = props.hsv ? MAX_COLOR_HUE : MAX_COLOR_ALPHA
		const p = (100 * value) / maxValue
		setPercent(p)
	}, [props.color, props.hsv])

	const handleClick = (e: any) => {
		const newColor = GetNewColor(e, ref, props, setPercent)
		if (newColor) {
			props.updateColor(newColor)
		}
	}

	const handleMouseMove = (e: any) => {
		if (props.isDragging) {
			handleClick(e)
		}
	}

	return (
		<Container ref={ref} style={props.hsv ? hueStyle : alphaStyle} onMouseDown={handleClick} onMouseMove={handleMouseMove}>
			{!props.hsv && (
				<Transparency
					style={{
						background: `linear-gradient(to right, transparent, rgb(${props.color.r},${props.color.g},${props.color.b}))`,
					}}
				/>
			)}
			<Thumb style={{ backgroundColor: thumbBackground, top: '50%', left: percent + '%' }} />
		</Container>
	)
}

const GetNewColor = (e: MouseEvent, containerRef: any, props: ISliderProps, setPercent: (percent: number) => void): IRGBA => {
	const maxValue = props.hsv ? MAX_COLOR_HUE : MAX_COLOR_ALPHA
	const rectSize = containerRef.current.getBoundingClientRect()

	const currentPercent = (e.clientX - rectSize.left) / rectSize.width
	const newVal = Clamp(Math.round(currentPercent * maxValue), maxValue)

	setPercent((100 * newVal) / maxValue)
	const rgba = props.hsv ? { ...Hsv2Rgb(newVal, props.hsv!.s, props.hsv!.v), a: props.color.a } : { ...props.color, a: newVal / 100 }

	return rgba
}

const Container = styled.div`
	position: relative;
	height: 12px;
	border-radius: 10px;
	box-sizing: content-box;
	border: 3px solid white;
`
const Transparency = styled.div`
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	border-radius: 10px;
`
