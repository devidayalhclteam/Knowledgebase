export const Sanitize = (text: string) => {
	return text?.replace(/(<([^>]+)>)/gi, '')
}
