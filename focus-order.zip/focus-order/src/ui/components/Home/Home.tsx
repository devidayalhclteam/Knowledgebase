import * as React from 'react'

import styled from '@emotion/styled'

import { SearchField } from 'shared/SearchField/SearchField'
import { SpacingWrapper, Footer } from '../CurrentAnnotations/List/List'
import { Button } from '@ms-design/figma-ui-components'
import { ListItem } from './ListItem'
import { CreateNewSet } from './CreateNewSet'
import { IAnnotation, ISet } from 'controller/IAnnotation'
import { LocationType } from '../App'
import { MessageType } from 'controller/MessageType'
import { appInsights } from 'shared/AppInsights'

interface IHomeProps {
	list: IAnnotation[]
	setList: (list: IAnnotation[]) => void
	currentSetId: string
	setCurrentSet: (set: ISet) => void
	setLocation: (location: LocationType) => void
	newSetName: string
	setNewSetName: (name: string) => void
	createNewSet: () => void
}

export const Home = (props: IHomeProps) => {
	const [createNewSet, setCreateNewSet] = React.useState(false)
	const [search, setSearch] = React.useState(null)
	const [sets, setSets] = React.useState<ISet[]>(null)

	React.useEffect(() => {
		if (props.list?.length) {
			let allSets = [
				...props.list
					.reduce((a, c) => {
						a.set(c.set.id, c.set)
						return a
					}, new Map())
					.values(),
			]
			allSets = filterDate(allSets)
			setSets(allSets)

			// If no setId we are just opening the app
			if (!props.currentSetId) {
				props.setCurrentSet(allSets[0])
			}
		} else {
			setSets(null)
		}
	}, [props.list])

	const handleSearch = (value: string) => {
		if (value) {
			// Filter names and channel names
			const filterList: ISet[] = sets.filter(
				(item) =>
					item.name.toLowerCase().includes(value.toLowerCase()) || item.artboard.name.toLowerCase().includes(value.toLowerCase())
			)

			setSearch(filterList)

			if (value.length === 1) {
				appInsights.trackEvent({ name: `Home/Search` })
			}
		} else {
			setSearch(null)
		}
	}

	const handleFilterDate = () => {
		const sortList = filterDate(sets)
		setSets(() => [...sortList])

		appInsights.trackEvent({ name: `Home/Filter/Item` }, { value: 'Recent' })
	}

	const filterDate = (list?: ISet[]): ISet[] => {
		return list.sort((a, b) => Number(b.date) - Number(a.date))
	}

	const handleFilterAscending = () => {
		sets.sort((a, b) => a.name.localeCompare(b.name))

		setSets(() => [...sets])

		appInsights.trackEvent({ name: `Home/Filter/Item` }, { value: 'A-Z' })
	}

	const handleFilterDescending = () => {
		sets.sort((a, b) => b.name.localeCompare(a.name))
		setSets(() => [...sets])

		appInsights.trackEvent({ name: `Home/Filter/Item` }, { value: 'Z-A' })
	}

	const handleFilterClick = (isOpen: boolean) => {
		appInsights.trackEvent({ name: `Home/Filter` }, { isOpen })
	}

	const handleSearchCancelClick = () => {
		appInsights.trackEvent({ name: `Home/Search/Cancel` })
	}

	/** Open set of Annotations */
	const openSet = () => {
		props.setLocation(LocationType.Current)

		appInsights.trackEvent({ name: `Home/Edit` })
	}

	/** Select set in scene (zoom in to first annotation) */
	const selectSet = (set: ISet) => {
		props.setCurrentSet(set)
		const annotationSet = props.list.find((annotation) => annotation.set.id === set.id)
		if (annotationSet) {
			parent.postMessage({ pluginMessage: { type: MessageType.SelectAnnotation, id: annotationSet.id, scrollIntoView: true } }, '*')
		}
	}

	const deleteSet = (e: React.MouseEvent, id: string) => {
		e.stopPropagation()
		let newList: IAnnotation[] = []
		if (sets.length === 1) {
			props.setList(newList)
		} else {
			newList = props.list.filter((item) => item.set.id !== id)
			props.setList([...newList])
		}
		const nextSet = sets.find((set) => set.id !== id)
		props.setCurrentSet(nextSet)
		parent.postMessage({ pluginMessage: { type: MessageType.DeleteSet, id } }, '*')

		appInsights.trackEvent({ name: `Home/Delete` })
	}

	return (
		<Container>
			{!sets || createNewSet ? (
				<CreateNewSet
					newSetName={props.newSetName}
					setCreateNewSet={setCreateNewSet}
					setNewSetName={props.setNewSetName}
					createNewSet={() => {
						props.setLocation(LocationType.Current)
						props.createNewSet()
						props.setNewSetName(null)
					}}
				/>
			) : (
				<>
					<SearchField
						setSearch={handleSearch}
						filterDate={handleFilterDate}
						filterAscending={handleFilterAscending}
						filterDescending={handleFilterDescending}
						filterClick={handleFilterClick}
						cancelClick={handleSearchCancelClick}
					/>
					<List>
						{(search ? search : sets).map((set, index) => (
							<ListItem
								key={set.name + index}
								isActive={props.currentSetId === set.id}
								set={set}
								selectSet={selectSet}
								openSet={openSet}
								deleteSet={deleteSet}
							/>
						))}
					</List>
					<Footer>
						<SpacingWrapper>
							<Button
								label={'New'}
								onClick={() => {
									props.setNewSetName(null)
									setCreateNewSet(true)
									appInsights.trackEvent({ name: `Home/New` })
								}}
							/>
						</SpacingWrapper>
					</Footer>
				</>
			)}
		</Container>
	)
}

const Container = styled.div`
	display: flex;
	flex: 1;
	align-items: center;
	flex-direction: column;
	width: 100%;
`

const List = styled.ul`
	flex: 1;
	width: 100%;
	padding: 8px;
	list-style: none;
`
