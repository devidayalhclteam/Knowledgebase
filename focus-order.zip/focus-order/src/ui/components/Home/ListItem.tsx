import * as React from 'react'

import styled from '@emotion/styled'

import { borderColor, hoverItemColor, standardBgColor, textSecondaryColor, transitionTiming } from 'shared/SharedColors'

import FocusIcon from 'assets/svgs/focus.svg'
import Delete from 'assets/svgs/trash.svg'
import Edit from 'assets/svgs/pencil.svg'
import { ISet } from 'controller/IAnnotation'

interface IHomeListProps {
	isActive: boolean
	set: ISet
	selectSet: (set: ISet) => void
	deleteSet: (e: React.MouseEvent, id: string) => void
	openSet: () => void
}

export const ListItem = (props: IHomeListProps) => {
	return (
		<Item style={{ backgroundColor: props.isActive ? hoverItemColor : '' }} onClick={() => props.selectSet(props.set)}>
			<Logo style={{ borderColor: `rgba(${props.set.color.r},${props.set.color.g},${props.set.color.b},${props.set.color.a})` }}>
				<img src={FocusIcon} />
			</Logo>
			<Content>
				<Text style={{ fontWeight: 600 }}>{props.set.name}</Text>
				<Text style={{ color: textSecondaryColor }}>
					{props.set.artboard.name} {new Date(Number(props.set.date)).toLocaleDateString('en-US')}
				</Text>
			</Content>

			<IconButton onClick={props.openSet}>
				<img src={Edit} />
			</IconButton>

			<IconButton onClick={(e) => props.deleteSet(e, props.set.id)}>
				<img src={Delete} />
			</IconButton>
		</Item>
	)
}

const Item = styled.li`
	display: flex;
	align-items: center;
	height: 48px;
	padding: 0 8px;
	background-color: transparent;
	border-radius: 2px;

	transition: background-color ${transitionTiming}ms ease-in;

	&:hover {
		background-color: ${hoverItemColor};

		> button {
			opacity: 1;
		}
	}

	> button {
		opacity: 0;
		transition: opacity ${transitionTiming}ms ease-in;
	}
`
const Content = styled.div`
	flex: 1;
	display: flex;
	flex-direction: column;
	overflow: hidden;
`
const Text = styled.div`
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
`
const Logo = styled.div`
	width: 24px;
	height: 24px;
	margin-right: 8px;
	display: flex;
	align-items: center;
	justify-content: center;
	border-radius: 100%;
	border: 2px solid ${borderColor};
	background-color: ${standardBgColor};
`

const IconButton = styled.button`
	width: 32px;
	height: 32px;
`
