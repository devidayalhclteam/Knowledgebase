import * as React from 'react'

import styled from '@emotion/styled'
import { BaseIntro, Button } from '@ms-design/figma-ui-components'
import { mainImg } from 'ui/assets/svgs'
import { BackButton, ButtonSpacer, Footer, SpacingWrapper } from 'ui/components/CurrentAnnotations/List/List'
import { Hero } from 'ui/components/About/About'

interface ICreateNewSetProps {
	addClick: () => void
	backClick: () => void
}

/** Add a new annotation to your list */
export const AddAnnotation = (props: ICreateNewSetProps) => {
	return (
		<Container>
			<BaseIntro
				img={<Hero src={mainImg} />}
				header={'Select a frame and Add an annotation'}
				subheader={
					'Select the first interactive control in your design, and then click “Add”. Once applied, hover to edit. Drag and drop each frame to reorder the sequence.'
				}
			/>

			<Footer>
				<BackButton onClick={props.backClick}>Back</BackButton>
				<ButtonSpacer />
				<SpacingWrapper>
					<Button label={'Add'} onClick={props.addClick} />
				</SpacingWrapper>
			</Footer>
		</Container>
	)
}
const Container = styled.div`
	display: flex;
	flex-direction: column;
	justify-content: space-between;
	height: 100%;
`
