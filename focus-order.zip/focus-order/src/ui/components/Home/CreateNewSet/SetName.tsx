import * as React from 'react'
import styled from '@emotion/styled'
import { BaseIntro, Button, Value } from '@ms-design/figma-ui-components'
import { mainImg } from 'ui/assets/svgs'
import { Sanitize } from 'shared/Sanitize'
import { appInsights } from '../../Shared/AppInsights'
import { BackButton, ButtonSpacer, Footer, SpacingWrapper } from 'ui/components/CurrentAnnotations/List/List'
import { Hero } from 'ui/components/About/About'

interface ISetNameProps {
	setName: (name: string) => void
	setCreateNewSet: (createSet: boolean) => void
}

/** Add a new annotation to your list */
export const SetName = (props: ISetNameProps) => {
	const inputRef = React.useRef<HTMLInputElement>(null)
	const [input, setInput] = React.useState(null)

	React.useEffect(() => {
		inputRef!.current!.focus()
	}, [])

	const handleSubmitClick = () => {
		const name = input && Sanitize(input)
		if (name && name.replace(/\s/g, '').length !== 0) {
			props.setName(name)
		} else {
			/* If the user clicks submit without naming the new set, use the current date for the name */
			const newName = new Date().toLocaleDateString('en-US')
			props.setName(newName)
		}

		appInsights.trackEvent({ name: `Home/New/Submit` })
	}

	const handleBackClick = () => {
		props.setCreateNewSet(false)
		appInsights.trackEvent({ name: `Home/New/Back` })
	}

	return (
		<Container>
			<BaseIntro
				img={<Hero src={mainImg} />}
				header={'Start a new set of annotations'}
				subheader={'Let’s get started. First up, let’s name your annotations, so it’s easily found for later.'}>
				<Value
					ref={inputRef}
					placeholder={'Name your annotations'}
					onChange={setInput}
					submit={handleSubmitClick}
					hasBorder={true}
				/>
			</BaseIntro>
			<Footer>
				<BackButton onClick={handleBackClick}>Back</BackButton>
				<ButtonSpacer />
				<SpacingWrapper>
					<Button label={'Submit'} onClick={handleSubmitClick} />
				</SpacingWrapper>
			</Footer>
		</Container>
	)
}

const Container = styled.div`
	display: flex;
	flex-direction: column;
	justify-content: space-between;
	height: 100%;
`
