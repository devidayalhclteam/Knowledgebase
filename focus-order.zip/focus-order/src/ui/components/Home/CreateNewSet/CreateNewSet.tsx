import * as React from 'react'
import { appInsights } from 'ui/components/Shared/AppInsights'

import { AddAnnotation } from './AddAnnotation'
import { SetName } from './SetName'

interface ICreateNewSetProps {
	createNewSet: () => void
	newSetName: string
	setNewSetName: (name: string) => void
	setCreateNewSet: (createSet: boolean) => void
}

/** Name and create a new annotation set */
export const CreateNewSet = (props: ICreateNewSetProps) => {
	return props.newSetName ? (
		<AddAnnotation
			addClick={props.createNewSet}
			backClick={() => {
				props.setNewSetName(null)
				appInsights.trackEvent({ name: `Home/New/AddAnnotation/Back` })
			}}
		/>
	) : (
		<SetName setName={props.setNewSetName} setCreateNewSet={props.setCreateNewSet} />
	)
}
