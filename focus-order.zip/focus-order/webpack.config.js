const webpack = require('webpack')
const path = require('path')
const HtmlWebpackInlineSourcePlugin = require('html-webpack-inline-source-plugin')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const Dotenv = require('dotenv-webpack')

module.exports = (env, argv) => ({
	mode: argv.mode === 'production' ? 'production' : 'development',

	entry: {
		controller: './src/controller/index.ts',
		ui: './src/ui/index.tsx',
	},

	output: {
		filename: '[name].js',
		path: path.resolve(__dirname, 'build'),
		pathinfo: false,
	},

	devtool: argv.mode === 'production' ? false : 'inline-source-map',

	module: {
		rules: [
			{
				test: /\.tsx?$/,
				use: [
					{
						loader: 'ts-loader',
						options: {
							happyPackMode: true,
						},
					},
				],
				exclude: /node_modules/,
			},
			{
				test: /\.(css|scss)$/,
				use: ['style-loader', 'css-loader'],
				exclude: /node_modules/,
			},
			{
				test: /\.svg$/,
				use: [
					{
						loader: 'svg-url-loader',
						options: {
							limit: 10000,
							iesafe: true,
						},
					},
				],
			},
			{
				test: /\.(ttf|eot|woff2?|jpe?g|png|gif)$/,
				loader: 'file-loader',
				options: {
					name: '[path][name].[ext]',
				},
			},
		],
	},

	plugins: [
		new webpack.NoEmitOnErrorsPlugin(),

		new HtmlWebpackPlugin({
			template: './src/ui/index.html',
			filename: 'ui.html',
			inlineSource: '.(js)$',
			chunks: ['ui'],
		}),

		new HtmlWebpackInlineSourcePlugin(),

		new webpack.ProvidePlugin({
			__assign: ['@microsoft/applicationinsights-shims', '__assignFn'],
			__extends: ['@microsoft/applicationinsights-shims', '__extendsFn'],
		}),

		(ENV_CONFIG = new Dotenv({ path: '.env' })),
	],

	resolve: {
		extensions: ['.tsx', '.ts', '.jsx', '.js'],
		modules: ['src', 'node_modules'],
		alias: {
			'*': path.resolve(__dirname, 'src/'),
			assets: path.resolve(__dirname, 'src/ui/assets/'),
			shared: path.resolve(__dirname, 'src/ui/components/Shared/'),
		},
	},

	performance: { hints: false },
})
