module.exports = {
	moduleFileExtensions: ['js', 'ts', 'tsx', 'json'],
	roots: ['./src'],
	transform: {
		'^.+\\.tsx?$': 'ts-jest',
	},
}
