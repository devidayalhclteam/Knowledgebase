const path = require('path')

module.exports = {
	mode: 'production',
	entry: {
		index: './src/index.ts',
	},
	resolve: {
		extensions: ['.ts', '.tsx', '.js'],
	},
	module: {
		rules: [
			{
				test: /\.(js)$/,
				exclude: /node_modules/,
				use: ['babel-loader'],
			},
			{
				test: /\.ts(x?)$/,
				use: ['ts-loader'],
				exclude: ['/node_modules/', '/src/**/__tests__/*', '/src/**/*.story.tsx'],
			},
		],
	},
	devtool: 'source-map',
	externals: {
		react: {
			commonjs: 'react',
			commonjs2: 'react',
			amd: 'React',
			root: 'React',
		},
		'react-dom': {
			commonjs: 'react-dom',
			commonjs2: 'react-dom',
			amd: 'ReactDOM',
			root: 'ReactDOM',
		},
	},
	output: {
		filename: '[name].js',
		path: path.resolve(__dirname, 'dist'),
		libraryTarget: 'umd',
		library: '@ms-design/figma-ui-components',
		umdNamedDefine: true,
	},
}
