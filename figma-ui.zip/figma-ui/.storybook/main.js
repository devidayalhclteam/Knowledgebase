// .storybook/main.js
const path = require('path')
const fs = require('fs')
const { merge } = require('webpack-merge')

function getPackageDir(filepath) {
	let currDir = path.dirname(require.resolve(filepath))
	while (true) {
		if (fs.existsSync(path.join(currDir, 'package.json'))) {
			return currDir
		}
		const { dir, root } = path.parse(currDir)
		if (dir === root) {
			throw new Error(`Could not find package.json in the parent directories starting from ${filepath}.`)
		}
		currDir = dir
	}
}

module.exports = {
	stories: ['../src/**/*.story.tsx'],
	addons: ['@storybook/addon-essentials', '@storybook/addon-actions', '@storybook/addon-links'],
	webpackFinal: async (config) => {
		config.module.rules.push({
			test: /\.(ts|tsx)$/,
			loader: require.resolve('babel-loader'),
			options: {
				presets: [['@babel/preset-typescript']],
			},
		})
		config.resolve.extensions.push('.ts', '.tsx')
		return merge(config, {
			resolve: {
				alias: {
					'@emotion/core': getPackageDir('@emotion/react'),
					'@emotion/styled': getPackageDir('@emotion/styled'),
				},
			},
		})
	},
	core: {
		builder: 'webpack5',
	},
}
