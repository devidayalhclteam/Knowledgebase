# Figma UI Components

This project aims to get you started on developing plugins for [Figma][figma].

The components are built with [React][react], [TypeScript][typescript], and [Emotion][emotion].

We strongly suggest reading through the introduction to [Figma plugin development][plugin-dev].

Figma has also provided extensive [plugin documenation][plugin-docs] which is an essential resource.

## Getting started

- [Getting started](#getting-started)
- [Setup](#setup)
- [Install](#install)
- [Storybook](#storybook)
- [Running Storybook](#running-storybook)
- [Adding a story](#adding-a-story)
- [Writing a story](#writing-a-story)
- [Publishing](#publishing)
- [Feedback](#feedback)
- [Teams](#teams)

## Setup

Node.js is required to install and build the project.

You can find it on the [Node.js downloads page][node].

### Install

Once you have Node setup on your local environment you can install the project dependencies.

```bash
yarn install
```

## Storybook

Building isolated, reusable components is one of our project goals. If you are starting work on a new feature or want to isolate a component for development / debugging, it is recommended to use [Storybook][storybook].

`Storybook v6` is currenlty not compatible with `react v17`.  Do not upgrade react as this will effect publishing.

## Running Storybook

```
yarn run storybook
```

## Adding a story

To add a story to Storybook, place a `<Component>.story.tsx` file in your component directory and `yarn run storybook` from the command line, where `<Component>` is the name of your component.

_You might have to restart the storybook server if your story does not show up._

## Writing a story

You can reference the [Storybook documentation][storybookdocs] for an introduction on “Writing Stories”.

You can find examples of stories in this repository by searching for `.story.tsx` files.

## Publishing

### Publish step 1: Connect to internal feed

@ms-design/figma-ui-components is a private dependency that provides figma ui components for the boilerplate. You must connect to the feed in order to run the project. Follow the link, and search for figma-ui-components.  Click on the "Connect to feed" button, select "npm", and follow the instructions. Note the Windows and Other setups differ, so be sure to select the correct platform, and be sure to include the registry setting in your npmrc file.

[@ms-design][https://dev.azure.com/microsoftdesign/design%20system/_packaging?_a=feed&feed=ms-design]

### Publish step 2: Do not include React

Do not allow React to be included in the package (package.json), add it as `peer dependency` (User does not need 2 versions of react).  Make sure react is not apart of any other dependency.  React is needed as a `dev dependency` to run storybook, remove it now for publishing only.  There are ways to leave it as a dev dependency and publish without including it in the package, but I haven't been able to get it to work successfully.

```
"peerDependencies": {
    "react": "^16.13.1",
    "react-dom": "^16.13.1"
}
```

### Publish step 3: Build

Build the project (especially after making changes to package.json).  Build files are located in `dist folder`.

```
yarn build
```

### Publish step 4: Publish

Publish the package.  Make sure you are connected to the internal feed (step 1).  It needs to be publised to the private repo, so if it asks for an npm username/password start again and make sure you have a .npmrc file.

```
yarn publish
```

### Publish step 5: Issues

If you are getting an error `Invalid hook call. Hooks can only be called inside of the body of a function component` this is likely caused by an issue with Storybook and React.  `Storybook v6` is currenlty not compatible with `react v17`, so we are using `"react": "^16.13.1",`.  There is a beta release for Storybook that is suppose to fix this, but it didn't.

## Feedback

If you have any feedback or suggestions please feel free to [reach out][mailto].

## Teams

If you want to get involved in a wider conversation about tooling and plugin development drop into our [Teams channel][teams].

[mailto]: mailto:zstp@microsoft.com
[node]: https://nodejs.org/en/download/
[figma]: https://figma.com/
[react]: https://reactjs.org/
[emotion]: https://emotion.sh/docs/introduction
[teams]: https://teams.microsoft.com/l/channel/19%3ad4eae03a8f5c427a972402700c076c06%40thread.skype/Workstream%2520-%2520Tooling?groupId=6189a5ca-e64d-40d0-a0cb-9b6e26200da1&tenantId=72f988bf-86f1-41af-91ab-2d7cd011db47
[plugin-dev]: https://help.figma.com/article/331-making-plugins
[plugin-docs]: https://www.figma.com/plugin-docs/intro/
[fabric]: https://developer.microsoft.com/en-us/fabric#/
[typescript]: https://www.typescriptlang.org/
