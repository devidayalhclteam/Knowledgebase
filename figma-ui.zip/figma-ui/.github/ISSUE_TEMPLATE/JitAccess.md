---
name: JIT Request
about: This template is used to create request for JIT admin access.
title: 'JIT request'
labels: jit
assignees: 
  - gimsvc_microsoft
  - 
---

Justification: __why you need admin access__
Hours: 24