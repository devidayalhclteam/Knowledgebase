module.exports = {
	arrowParens: 'always',
	bracketSpacing: true,
	jsxBracketSameLine: false,
	printWidth: 140,
	semi: false,
	singleQuote: true,
	tabWidth: 4,
	trailingComma: 'es5',
	useTabs: true,
}
