import React from 'react'
import { Story, Meta } from '@storybook/react'
import { Progress } from '.'
import { IProgressProps } from './Progress'

export default {
	title: 'Figma/Progress',
	component: Progress,
	argTypes: {
		isLoading: {
			defaultValue: true,
		},
	},
} as Meta

export const Default: Story<IProgressProps> = (props: IProgressProps) => <Progress {...props} />
