import * as React from 'react'
import { keyframes } from '@emotion/core'
import styled from '@emotion/styled'
import { Colors } from '../Styles/Themes'
import { ProgressIcon } from './ProgressIcon'

export interface IProgressProps {
	/** Show/hide loading */
	isLoading: boolean
}

export const Progress = (props: IProgressProps) => {
	return (
		<Loader
			style={{ opacity: props.isLoading ? 1 : 0, display: props.isLoading ? 'flex' : '' }}
			onTransitionEnd={(e) => {
				e.currentTarget.style.display = 'none'
			}}
			aria-busy={props.isLoading}
			aria-live="polite"
		>
			<Spinner role="img" aria-label="loading">
				<ProgressIcon />
			</Spinner>
		</Loader>
	)
}

const Loader = styled.div`
	position: absolute;
	display: flex;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	align-items: center;
	justify-content: center;
	background-color: ${Colors.white.primary};
	transition: opacity 250ms ease-in 250ms; // Add slight delay to mask pages loading in
`
const spinner = keyframes`
  to {transform: rotate(360deg);}
`
const Spinner = styled.div`
	display: flex;
	width: 16px;
	height: 16px;
	animation: ${spinner} 0.6s linear infinite;
`
