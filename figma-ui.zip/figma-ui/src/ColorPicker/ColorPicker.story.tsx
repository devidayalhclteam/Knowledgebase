import React from 'react'
import { Story, Meta } from '@storybook/react'

import { ColorPicker, IColorPickerProps } from './ColorPicker'
import styled from '@emotion/styled'
import { Rgba2Interface } from '../Shared/Rgba2Interface'
import { IRGBA } from '../Shared/consts'

export default {
	title: 'Figma/ColorPicker',
	component: ColorPicker,
	argTypes: {
		color: {
			control: { type: 'none' },
		},
	},
} as Meta

const Template: Story<IColorPickerProps> = (props: any) => {
	const color: IRGBA = props.color && props.color.includes('rgb') ? Rgba2Interface(props.color) : props.color

	return (
		<Container>
			<div style={{ marginBottom: '20px' }}>Broken :/ </div>
			<ColorPicker {...props} color={color} />
		</Container>
	)
}
export const Default = Template.bind({})

const Container = styled.div`
	display: flex;
	flex-direction: column;
	width: 100%;
	height: 100%;
	justify-content: center;
	align-items: center;
	padding: 20px;
	background-color: #f8f8f8;
`
