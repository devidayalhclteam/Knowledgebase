import * as React from 'react'
import styled from '@emotion/styled'
import { IRGBA, MAX_COLOR_VALUE, MAX_COLOR_SATURATION, IHSV, IRGB } from '../Shared/consts'
import { GetFullColorString } from '../Shared/GetFullColorString'
import { Hsv2Rgb } from '../Shared/Hsv2Rgb'
import { Clamp } from '../Shared/Clamp'
import { Rgb2Hsv } from '../Shared/Rgb2Hsv'
import { Rgb2Hex } from '../Shared/Rgb2Hex'

interface IColorSquareProps {
	color: IRGBA
	updateColor: (color: IRGBA) => void
}

export const ColorSquare = (props: IColorSquareProps) => {
	const ref = React.useRef<HTMLDivElement>()
	const [isDragging, setIsDragging] = React.useState(false)

	const hsv = Rgb2Hsv(props.color)
	const hex = `#${Rgb2Hex(props.color)}`

	React.useEffect(() => {
		document.addEventListener('mousemove', handleMouseMove)
		document.addEventListener('mouseup', handleMouseUp)

		return () => {
			// Unbind the event listener on clean up
			document.removeEventListener('mousemove', handleMouseMove)
			document.removeEventListener('mouseup', handleMouseUp)
		}
	}, [isDragging])

	const handleMouseDown = (e: React.MouseEvent) => {
		setIsDragging(true)
		const newColor: IRGB = GetNewColor(e, ref, hsv)

		if (newColor) {
			props.updateColor({ ...newColor, a: props.color.a })
		}
	}

	const handleKeyDown = (e: React.KeyboardEvent) => {
		let { s, v } = hsv
		const increment = e.shiftKey ? 10 : 1

		switch (e.key) {
			case 'ArrowUp':
				const up = v + increment
				v = up <= MAX_COLOR_VALUE ? up : MAX_COLOR_VALUE
				break
			case 'ArrowDown':
				const down = v - increment
				v = down >= 0 ? down : 0
				break
			case 'ArrowLeft':
				const left = s - increment
				s = left >= 0 ? left : 0
				break
			case 'ArrowRight':
				const right = s + increment
				s = right <= MAX_COLOR_SATURATION ? right : MAX_COLOR_SATURATION
				break
			default:
				break
		}

		const newColor: IRGB = Hsv2Rgb(hsv.h, s, v)

		if (newColor) {
			props.updateColor({ ...newColor, a: props.color.a })
		}
	}

	const handleMouseUp = () => {
		setIsDragging(false)
	}

	const handleMouseMove = (e: React.MouseEvent | MouseEvent) => {
		if (isDragging) {
			handleMouseDown(e as React.MouseEvent)
		}
	}

	return (
		<Container
			ref={ref}
			tabIndex={0}
			aria-label={hex}
			style={{ backgroundColor: GetFullColorString(hsv) }}
			onMouseDown={handleMouseDown}
			onKeyDown={handleKeyDown}
		>
			<Light />
			<Dark />
			<Thumb
				onMouseDown={(e: React.MouseEvent) => e.preventDefault()}
				style={{
					left: hsv.s + '%',
					top: MAX_COLOR_VALUE - hsv.v + '%',
					backgroundColor: hex,
				}}
			/>
		</Container>
	)
}

const GetNewColor = (e: React.MouseEvent, containerRef: any, hsv: IHSV): IRGB => {
	const squareSize = containerRef.current.getBoundingClientRect()

	let s = (e.clientX - squareSize.left) / squareSize.width
	s = Clamp(Math.round(s * MAX_COLOR_SATURATION), MAX_COLOR_SATURATION)
	let v = (e.clientY - squareSize.top) / squareSize.height
	v = Clamp(Math.round(MAX_COLOR_VALUE - v * MAX_COLOR_VALUE), MAX_COLOR_VALUE)

	return Hsv2Rgb(hsv.h, s, v)
}

const Container = styled.div`
	position: relative;
	width: 240px;
	height: 240px;

	/* hide focus styles on button click */
	:focus:not(:focus-visible) {
		outline: 0;
		box-shadow: none;
	}
`

const Light = styled.div`
	position: absolute;
	left: 0;
	right: 0;
	top: 0;
	bottom: 0;
	background: linear-gradient(to right, white 0%, transparent 100%);
`

const Dark = styled.div`
	position: absolute;
	left: 0;
	right: 0;
	top: 0;
	bottom: 0;
	background: linear-gradient(to bottom, transparent 0, #000 100%);
`

export const Thumb = styled.div`
	position: absolute;
	width: 12px;
	height: 12px;
	background: white;
	border-radius: 100%;
	border: 2px solid white;
	transform: translate(-50%, -50%);
`
