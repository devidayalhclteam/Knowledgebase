import * as React from 'react'
import styled from '@emotion/styled'
import { Colors, Fonts } from '../Styles/Themes'
import { ColorSquare } from './ColorSquare'
import { IRGBA } from '../Shared/consts'
import { Rgb2Hex } from '../Shared/Rgb2Hex'
import { Hex2Rgb } from '../Shared/Hex2Rgb'
import { Sanitize } from '../Shared/Sanatize'
import { ColorSlider } from '../ColorSlider'
import { SliderType } from '../ColorSlider/ColorSlider'
import { Value } from '../Value'

export interface IColorPickerProps {
	/** Customize default color.  Default color is #FF0000 */
	color?: IRGBA
	/** Callback when color is changed */
	updateColor?: (color: IRGBA) => void
}

export const ColorPicker = (props: IColorPickerProps) => {
	const [color, setColor] = React.useState(props.color ? props.color : { r: 255, g: 0, b: 0, a: 1 })
	const [hexInput, setHexInput] = React.useState(null)
	const [percentInput, setPercentInput] = React.useState<string>(null)
	const isSameColor =
		`${props.color.r},${props.color.g},${props.color.b},${props.color.a}` === `${color.r},${color.g},${color.b},${color.a}`

	React.useEffect(() => {
		if (color) {
			const hex = Rgb2Hex(color).toUpperCase()
			setHexInput('#' + hex)
			const percent = Math.round(color.a * 100)?.toString()
			setPercentInput(percent + '%')

			if (props.updateColor && !isSameColor) {
				props.updateColor(color)
			}
		}
	}, [color, hexInput, percentInput])

	React.useEffect(() => {
		if (props.color && !isSameColor) {
			setColor(props.color)
		}
	}, [props.color])

	const updateHex = (e: React.FocusEvent) => {
		const value = (e.target as HTMLInputElement).value
		let newColor = value.replace('#', '')
		// Update hex if written in shorthand
		newColor = newColor.length === 3 ? newColor + newColor : newColor
		if (newColor.length === 6) {
			const rgb = Hex2Rgb(`#${newColor}`)

			const isSameColor = `${rgb.r},${rgb.g},${rgb.b}` === `${color.r},${color.g},${color.b}`
			if (!isSameColor) {
				setColor({ ...rgb, a: color.a })
			}
		}
	}

	const updateHexField = (text: string) => {
		setHexInput(Sanitize(text))
	}

	const updatePercent = (e: React.FocusEvent) => {
		const value = (e.target as HTMLInputElement).value
		let newPercent = parseInt(value, 10)
		if (newPercent || newPercent === 0) {
			newPercent = (newPercent > 100 ? 100 : newPercent) / 100

			if (newPercent !== color.a) {
				setColor({ ...color, a: newPercent })
			}
		}
	}

	const updatePercentField = (text: string) => {
		const numberOnly = text.replace('%', '')
		setPercentInput(Sanitize(numberOnly))
	}

	return (
		<Container>
			<ColorSquare color={color} updateColor={setColor} />
			<Sliders>
				<SelectedColor style={{ backgroundColor: `rgba(${color.r},${color.g},${color.b},${color.a})` }} />
				<SliderWrapper>
					<ColorSlider color={color} updateColor={setColor} />
					<ColorSlider type={SliderType.Alpha} color={color} updateColor={setColor} />
				</SliderWrapper>
			</Sliders>
			<Readout>
				<FormatButton>HEX</FormatButton>
				<Value defaultValue={hexInput ? hexInput : ''} blur={updateHex} submit={updateHex} onChange={updateHexField} />
				<Value
					defaultValue={percentInput ? percentInput : ''}
					blur={updatePercent}
					submit={updatePercent}
					onChange={updatePercentField}
					style={{ width: '50px', marginLeft: '10px' }}
				/>
			</Readout>
		</Container>
	)
}

const Container = styled.div`
	display: flex;
	flex-direction: column;
	width: 240px;
	height: 344px;
	font-family: ${Fonts.inter.family};
	font-size: 11px;
	box-sizing: content-box;
	background-color: ${Colors.white.primary};
	box-shadow: 0 2px 14px 0 rgba(0, 0, 0, 0.15);
`
const Sliders = styled.div`
	display: flex;
	padding: 16px 8px 0px 10px;
`
const SelectedColor = styled.div`
	display: flex;
	width: 40px;
	height: 40px;
	min-width: 40px;
	margin-right: 10px;
`

const SliderWrapper = styled.div`
	display: flex;
	width: 100%;
	flex-direction: column;
	justify-content: space-between;
	padding: 0 5px;
`

const Readout = styled.div`
	display: flex;
	align-items: center;
	padding: 8px;
`
const FormatButton = styled.div`
	display: flex;
	justify-content: center;
	align-items: center;
	width: 40px;
	min-width: 40px;
	height: 32px;
	margin-right: 10px;
`

ColorPicker.defaultProps = {
	color: 'rgba(255,0,0,1)',
}
