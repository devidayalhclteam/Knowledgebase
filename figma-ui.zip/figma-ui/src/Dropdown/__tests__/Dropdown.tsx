import * as React from 'react'
import { render, cleanup } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import { Dropdown } from '..'

const List = ['Animal Man', 'Flash', 'Metamorpho', 'Power Girl', 'Crimson Fox', 'Blue Jay', 'Silver Sorceress', 'Maya']

afterEach(cleanup)

describe('Loading component ', () => {
	test('renders correctly', () => {
		const { container } = render(<Dropdown list={List} selected={0} onListClick={(index) => console.log('update', index)} />)

		expect(container).toBeVisible()
	})
})
