import * as React from 'react'
import styled from '@emotion/styled'
import { Colors, Fonts } from '../Styles/Themes'
import { Caret, Checked } from '.'
import { OutsideClick } from '../Shared/OutsideClick'

export interface IDropdownProps {
	/** Dropdown list */
	list: string[]
	/** Default selection from the dropdown menu (selection index). */
	selected?: number
	/** Add placeholder text to the first list item */
	placeholder?: string
	/** Is dropdown in a disabled state. */
	disabled?: boolean
	/** Add icon to dropdown menu */
	icon?: React.ReactNode
	/**
	 * When in focus or hovered the menu expands to the full width of the parent container, and the dropdown arrow expands with it.
	 * This prop will keep the menu fully expanded so this doesn't happen and the dropdown arrow stays in the same place.
	 * */
	equalSize?: boolean
	/** Callback for when user opens/closes the dropdown menu */
	onClick?: (isOpen: boolean) => void
	/** Callback for when user makes a selection from the dropdown list.  Null indicates user has selected the placeholder text (no selection) */
	onListClick: (index: number | null) => void
}

interface IPositionData {
	indexPos: number
	totalHeight: number
	offset: number
	hasScroll: boolean
}

const paddingHeight = 8
const maxLines = 8
const listItemHeight = 24
const maxHeight = listItemHeight * maxLines + paddingHeight * 2

export const Dropdown = (props: IDropdownProps) => {
	const list = props.placeholder ? ['—', ...props.list] : props.list
	const ref = React.useRef<HTMLDivElement>(null)
	const refList = React.useRef<HTMLUListElement>(null)
	let refListItems = React.useRef<(HTMLLIElement | null)[]>([])
	/**
	 * I'm not sure why MouseEnter/MouseLeave was used over css hover.
	 * The hover + focus interaction doesn't seem too complex
	 * */
	const [isHover, setIsHover] = React.useState(false)
	const [isExpanded, setIsExpanded] = React.useState(false)
	// We add a new array item at index 0 when user has a placeholder, so we need to add a +1 to users selected state if they have one
	const [active, setActive] = React.useState(props.selected ? (props.placeholder ? props.selected + 1 : props.selected) : 0)
	const [ariaSelect, setAriaSelect] = React.useState<number | null>(null)
	const [keyboardSelection, setKeyboarSelection] = React.useState<string | null>(null)

	OutsideClick(refList, () => {
		if (props.onClick) {
			props.onClick(false)
		}
		setIsExpanded(false)

		setIsHover(false)
		setAriaSelect(null)
	})

	React.useEffect(() => {
		if (isExpanded && refList.current) {
			const postionData: IPositionData = getPostionData(active, list.length)
			const scrollTo = postionData.hasScroll ? postionData.indexPos : postionData.totalHeight

			refList.current!.scrollTo(0, scrollTo)

			refListItems!.current[active]!.focus()
		} else {
			// Do not set focus until user has started tab focus
			if (ariaSelect !== null && !props.disabled) {
				ref.current!.focus()
			}
			setKeyboarSelection(null)
			refListItems.current = []
		}
	}, [isExpanded])

	const handleKeydown = (e: React.KeyboardEvent<HTMLDivElement>) => {
		if (props.disabled) {
			return
		}

		switch (e.key) {
			case 'Enter':
				if (!isExpanded) {
					if (props.disabled) {
						return
					}

					if (props.onClick) {
						props.onClick(!isExpanded)
					}
					setAriaSelect(active)
					setIsExpanded(!isExpanded)
				} else {
					if (ariaSelect !== null) {
						handleListClick(ariaSelect)
					}
				}

				break
			case 'ArrowUp':
				if (isExpanded && ariaSelect !== null) {
					const select = ariaSelect > 0 ? ariaSelect - 1 : 0
					setAriaSelect(select)
					refListItems.current[select]!.focus()
				}
				break
			case 'ArrowDown':
				if (isExpanded && ariaSelect !== null) {
					const select = ariaSelect < list.length - 1 ? ariaSelect + 1 : list.length - 1
					setAriaSelect(select)
					refListItems.current[select]!.focus()
				}
				break
			case 'Escape':
				if (isExpanded) {
					if (props.onClick) {
						props.onClick(false)
					}
					setIsExpanded(false)

					setIsHover(false)
					setAriaSelect(null)
				}
				break
			default:
				// Allow user to type out word to make a selection (we have some very long lists)
				if ((/[a-z0-9]/i.test(e.key) && e.key.length === 1) || e.key === ' ') {
					const selection = keyboardSelection ? keyboardSelection + e.key : e.key
					// First check if start of string matches, then check whole string
					let matchIndex = list.findIndex((item) => item.toLowerCase().startsWith(selection))
					matchIndex = matchIndex > -1 ? matchIndex : list.findIndex((item) => item.toLowerCase().includes(selection))

					if (matchIndex > -1) {
						setKeyboarSelection(selection)
						if (matchIndex !== ariaSelect) {
							setAriaSelect(matchIndex)
							refListItems.current[matchIndex]!.focus()
						}
					} else {
						setKeyboarSelection(null)
						setAriaSelect(0)
						refListItems.current[0]!.focus()
					}
				}
				break
		}
	}

	const handleClick = () => {
		if (props.disabled) {
			return
		}

		if (props.onClick) {
			props.onClick(!isExpanded)
		}
		setAriaSelect(null)
		setIsExpanded(!isExpanded)
	}

	const handleMouseEnter = () => {
		if (props.disabled) {
			return
		}
		setIsHover(true)
	}

	const handleMouseLeave = () => {
		if (props.disabled) {
			return
		}
		if (!isExpanded) {
			setIsHover(false)
		}
	}

	const handleMouseMove = () => {
		if (props.disabled) {
			return
		}
		setIsHover(true)
	}

	const handleListClick = (index: number) => {
		// If we are adding a placeholder to the front of the list, we need to remove it because it won't be in the user-submitted list
		// If user is selecting the placeholder (index === 0) return null
		props.onListClick(props.placeholder ? (index === 0 ? null : index - 1) : index)

		setActive(index)
		setIsExpanded(false)
		setIsHover(false)
	}

	const setRef = (ref: HTMLLIElement | null) => {
		if (refListItems.current) {
			refListItems.current.push(ref)
		}
	}

	return (
		<Container
			ref={ref}
			tabIndex={0}
			role="button"
			aria-haspopup="listbox"
			aria-expanded={isExpanded}
			aria-disabled={props.disabled}
			disabled={props.disabled ? props.disabled : false}
			onClick={handleClick}
			onKeyDown={(e: React.KeyboardEvent<HTMLDivElement>) => handleKeydown(e)}
			onMouseEnter={handleMouseEnter}
			onMouseLeave={handleMouseLeave}
			onMouseMove={handleMouseMove}
			style={{
				borderColor: isHover ? Colors.silver.primary : 'transparent',
				paddingLeft: props.icon ? 0 : '8px',
				cursor: props.disabled ? 'default' : 'pointer',
			}}
		>
			<DropdownSelection
				style={{
					justifyContent: isHover ? 'space-between' : 'initial',
					color: props.disabled ? Colors.black.tint30 : Colors.black.tint80,
				}}
			>
				{
					<Title style={{ flex: props.equalSize ? '1' : '' }}>
						{props.icon && <Icon style={{ opacity: props.disabled ? 0.3 : 1 }}>{props.icon}</Icon>}
						{props.placeholder && active === 0 ? props.placeholder : list[active]}
					</Title>
				}
				{
					<CaretWrapper style={{ opacity: isHover ? 0.8 : 0.3 }}>
						<Caret />
					</CaretWrapper>
				}
			</DropdownSelection>
			{isExpanded && (
				<List ref={refList} role="listbox" style={{ top: getListPosition(active, list.length) }}>
					{list.map((item, index) => (
						<ListItem
							key={`${item}-selected-${active === index}`}
							ref={(ref) => setRef(ref)}
							role="option"
							tabIndex={0}
							aria-selected={active === index}
							onClick={() => handleListClick(index)}
							style={{ backgroundColor: ariaSelect === index ? Colors.blue.primary : '' }}
						>
							{item}

							<CheckedWrapper style={{ opacity: active === index ? 1 : 0 }}>
								<Checked />
							</CheckedWrapper>
						</ListItem>
					))}
				</List>
			)}
		</Container>
	)
}

/** We could be passing in refs instead of height constants */
const getPostionData = (index: number, length: number): IPositionData => {
	const indexPos = index * listItemHeight
	/* Total height of list items */
	const totalHeight = (length + 1) * listItemHeight // +1 is odd, not sure why this is working

	const scrollHeight = maxHeight - paddingHeight * 2
	const maxItemsWithoutScroll = Math.floor(scrollHeight / listItemHeight)
	const noScroll = length <= maxItemsWithoutScroll

	const offset = noScroll ? maxItemsWithoutScroll : totalHeight - maxHeight
	return { indexPos, totalHeight, offset, hasScroll: !noScroll }
}

const getListPosition = (index: number, length: number): number => {
	const postionData: IPositionData = getPostionData(index, length)

	if (postionData.offset < postionData.indexPos) {
		const posOffset = postionData.indexPos - postionData.offset + listItemHeight / 2
		return -posOffset
	} else {
		return -5 // Adjusted standard menu height
	}
}

interface IStyle {
	disabled: boolean
}
const Container = styled.div<IStyle>`
	display: flex;
	height: 32px;
	align-items: center;
	padding: ${paddingHeight}px;
	border: 1px solid transparent;
	width: 100%;
	font-family: ${Fonts.inter.family};
	font-size: 11px;
	transition: border-color 250ms ease-in;

	&:focus {
		outline-color: ${Colors.blue.primary};
		outline: ${(props) => props.disabled && '0'};
		> div {
			justify-content: ${(props) => !props.disabled && 'space-between !important'};
		}
	}
`
const DropdownSelection = styled.div`
	display: flex;
	width: 100%;
	min-width: 100px;

	&:focus {
		outline: 0;
	}
`

const Title = styled.div`
	display: flex;
	align-items: center;
	padding-right: 4px;
`

const CaretWrapper = styled.div`
	display: flex;
	align-items: center;
	padding-left: 4px;
`
const CheckedWrapper = styled.div`
	display: flex;
	align-items: center;
	padding-left: 4px;
`

const Icon = styled.div`
	display: flex;
	justify-content: center;
	align-items: center;
	width: 32px;
	min-width: 32px;
	height: 32px;
`

const List = styled.ul`
	position: absolute;
	left: 0;
	width: 100%;
	max-height: ${maxHeight}px;
	overflow-y: auto;
	color: ${Colors.white.primary};
	background-color: ${Colors.midnight.primary};
	padding: 8px 0;
	/*
	* The most robust way to position a dropdown list over all elements is to
	* create the list at the top of the dom, instead of doing this z-index hack
	*/
	z-index: 1000;
`
const ListItem = styled.li`
	display: flex;
	align-items: center;
	justify-content: space-between;
	white-space: nowrap;
	height: ${listItemHeight}px;
	padding: 0 8px;

	&:hover {
		background-color: ${Colors.blue.primary};
	}

	&:focus {
		outline: 0;
	}
`

Dropdown.defaultProps = {
	disabled: false,
	rightAlign: false,
}
