import React from 'react'

export const Caret = () => (
	<svg width="8" height="5" viewBox="0 0 8 5" fill="none" xmlns="http://www.w3.org/2000/svg">
		<path
			fillRule="evenodd"
			clipRule="evenodd"
			d="M3.64648 4.35359L0.646484 1.35359L1.35359 0.646484L4.00004 3.29293L6.64648 0.646484L7.35359 1.35359L4.35359 4.35359L4.00004 4.70714L3.64648 4.35359Z"
			fill="black"
			fillOpacity="1"
		/>
	</svg>
)
