import React from 'react'
import styled from '@emotion/styled'
import { Story, Meta } from '@storybook/react'
import { useArgs } from '@storybook/client-api'
import { Dropdown, IDropdownProps } from './Dropdown'
import { PiggyBank } from '../ButtonIcon/PiggyBank'

const List = ['Animal Man', 'Flash', 'Metamorpho', 'Power Girl', 'Crimson Fox', 'Blue Jay', 'Silver Sorceress', 'Maya']

export default {
	title: 'Figma/Dropdown',
	component: Dropdown,
	argTypes: {
		selected: {
			control: { type: 'number', min: 0 },
		},
		list: {
			defaultValue: List,
			control: {
				type: 'array',
			},
		},
		icon: {
			defaultValue: false,
			control: {
				type: 'boolean',
			},
		},
		placeholder: {
			defaultValue: 'No selection',
		},
	},
} as Meta

const Template: Story<IDropdownProps> = (props: IDropdownProps) => {
	const [args, updateArgs] = useArgs()

	return (
		<Container>
			<Dropdown
				{...props}
				{...args}
				list={args.list}
				icon={args.icon && <PiggyBank />}
				onListClick={(index: number) => updateArgs({ selected: index })}
			/>
		</Container>
	)
}
export const Default = Template.bind({})

const Container = styled.div`
	display: flex;
	height: 100%;
	min-height: 400px;
	max-width: 300px;
	align-items: center;
`
