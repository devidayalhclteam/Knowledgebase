import React from 'react'

export const Checked = () => (
	<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
		<path
			fillRule="evenodd"
			clipRule="evenodd"
			d="M3.17647 4.82377L5.05882 6.70613L8.82353 2.94141L10 4.11788L5.05882 9.05908L2 6.00024L3.17647 4.82377Z"
			fill="white"
		/>
	</svg>
)
