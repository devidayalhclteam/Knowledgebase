import * as React from 'react'

export const Arrow = () => (
	<svg width="6" height="8" viewBox="0 0 6 8" fill="none" xmlns="http://www.w3.org/2000/svg">
		<path d="M6 3.99976L0 -0.000244141V7.99976L6 3.99976Z" fill="white" />
	</svg>
)
