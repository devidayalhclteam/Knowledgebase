import { IList } from './Menu'

export const menuList: IList[] = [
	{
		text: 'Copy as',
	},
	{
		text: 'Hide UI',
		hint: '⌘/',
	},
	{
		isDivider: true,
	},
	{
		text: 'Bring Forward',
		hint: '⌘]',
	},
	{
		text: 'Bring to Front',
		hint: '⌥⌘]',
	},
	{
		text: 'Send Backward',
		hint: '⌘[',
	},
	{
		text: 'Send to Back',
		hint: '⌥⌘[',
	},
	{
		isDivider: true,
	},
	{
		text: 'Copy as...',
		list: [
			{
				text: 'Zoom in',
				hint: '+',
			},
			{
				text: 'Zoom out',
				hint: '-',
			},
			{
				text: 'Displayed on top',
				hint: '⌘/',
				checked: true,
			},
			{
				text: 'Aligned on items',
				hint: '⌘/',
				mixed: true,
			},
			{
				text: 'Hide UI',
				hint: '⌘/',
				bullet: true,
			},
		],
	},
	{
		text: 'Copy Properties',
		hint: '⌥⌘C',
	},
	{
		text: 'Paste Properties',
		hint: '⌥⌘V',
		disabled: true,
	},
	{
		text: 'Options',
		list: [
			{
				text: 'Zoom in',
				hint: '+',
			},
			{
				text: 'Zoom out',
				hint: '-',
			},
		],
	},
]

export const selectionList: IList[] = [
	{
		text: 'Recent',
	},
	{
		text: 'A-Z',
	},
	{
		text: 'Z-A',
	},
]
