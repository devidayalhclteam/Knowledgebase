import * as React from 'react'
import styled from '@emotion/styled'
import { Colors, Fonts } from '../Styles/Themes'
import { Arrow } from './Arrow'
import { Mixed } from './Mixed'
import { Bullet } from './Bullet'
import { Checked } from '../Dropdown'

export interface IList {
	isDivider?: boolean
	text?: string
	hint?: string
	list?: IList[]
	disabled?: boolean
	mixed?: boolean
	checked?: boolean
	bullet?: boolean
}

export interface IMenuProps {
	/** Menu list */
	list: IList[]
	/** We have a selected/checked item */
	selected?: number
	/** Callback when list item is clicked */
	onClick?: (item: IList, index: number) => void
	/** Private prop used by MenuList when list contains a submenu */
	_submenu?: boolean
	/** Private prop used by MenuList when submenu is open */
	_isOpen?: boolean
	/** Private prop used for callback when menu is opened/closed */
	_updateSubmenu?: () => void
}

export const Menu = (props: IMenuProps) => {
	const itemsRef = React.useRef([])
	const [tabIndex, setTabIndex] = React.useState(0)
	const [selected, setSelected] = React.useState(props.selected)
	const [subMenuIndex, setSubmenuIndex] = React.useState<number>()

	/** If a list contains a leading icon, we need all list items to align farther over */
	const leadingCheckmark = Boolean(props.list.find((x) => x.checked || x.bullet || x.mixed))

	const submenuStyles: React.CSSProperties = {
		position: 'absolute',
		left: '100%',
		top: 0,
		display: props._submenu ? (props._isOpen ? 'flex' : 'none') : '',
	}

	const handleKeyDown = (e: React.KeyboardEvent) => {
		switch (e.key) {
			case 'ArrowUp':
				if (tabIndex > 0) {
					const newIndex = tabIndex - 1
					const currentRef = itemsRef.current[newIndex]
					if (currentRef && currentRef.el) {
						currentRef.el.focus()
						setTabIndex(newIndex)
					}
				}

				break
			case 'ArrowDown':
				if (tabIndex < itemsRef.current.length - 1) {
					const newIndex = tabIndex + 1
					const currentRef = itemsRef.current[newIndex]
					if (currentRef && currentRef.el) {
						currentRef.el.focus()
						setTabIndex(newIndex)
					}
				}

				break
			case 'Enter':
				let itemIndex = 0
				const listItem = props.list.find((x, index) => {
					const match = x.text === itemsRef.current[tabIndex].item.text
					if (match) {
						itemIndex = index
					}
					return match
				})
				handleClick(listItem, itemIndex)

				break
			case 'Tab':
				// tab out of submenu
				if (props._submenu && props._isOpen) {
					props._updateSubmenu()
				}

				break
			default:
				break
		}

		e.stopPropagation()
	}

	const handleClick = (item: IList, index: number) => {
		if (item.disabled) {
			return
		}

		if (props.onClick) {
			props.onClick(item, index)
		}

		if (props.selected !== undefined) {
			setSelected(index)
		}

		if (item.list) {
			setSubmenuIndex(index)
		}
	}

	const handleMouseOver = (item: IList, index: number) => {
		if (item.disabled) {
			return
		}

		if (item.list) {
			setSubmenuIndex(index)
		}
	}

	const handleMouseLeave = (item: IList) => {
		if (item.list) {
			setSubmenuIndex(null)
		}
	}

	const updateSubmenu = (index: number) => {
		if (index !== tabIndex) {
			setSubmenuIndex(null)
			setTabIndex(0)
		}
	}

	/** Refs used for keyboard focus */
	const addToRefs = (el: HTMLLIElement, item: IList) => {
		if (!itemsRef.current.find((x) => x.el === el)) {
			itemsRef.current.push({ el: el, item: item })
		}
	}

	return (
		<List role="menu" style={props._submenu && submenuStyles} onKeyDown={handleKeyDown}>
			{props.list.map((item, index) =>
				item.isDivider ? (
					<Divider key={index} />
				) : (
					<ListItem
						key={index}
						ref={(el: HTMLLIElement) => addToRefs(el, item)}
						tabIndex={index === 0 ? 0 : -1}
						onClick={() => handleClick(item, index)}
						onMouseOver={() => handleMouseOver(item, index)}
						onMouseLeave={() => handleMouseLeave(item)}
						role="menuitem"
						aria-disabled={item.disabled}
						aria-expanded={Boolean(item.list) && subMenuIndex === index}
						aria-haspopup={Boolean(item.list)}
						style={{
							background: item.disabled ? 'transparent' : '',
							color: item.disabled ? Colors.white.tint40 : '',
							paddingLeft: leadingCheckmark ? '8px' : '',
						}}
					>
						<Text>
							{leadingCheckmark && (
								<IconWrapper style={{ opacity: item.checked || item.mixed || item.bullet ? 1 : 0 }}>
									{item.checked ? <Checked /> : item.mixed ? <Mixed /> : item.bullet && <Bullet />}
								</IconWrapper>
							)}
							{item.text}
						</Text>
						{item.list ? (
							<>
								<Arrow />
								<Menu
									_submenu={true}
									_isOpen={subMenuIndex === index}
									list={item.list}
									_updateSubmenu={() => updateSubmenu(index)}
								/>
							</>
						) : index === selected ? (
							<Checked />
						) : (
							<Hint>{item.hint}</Hint>
						)}
					</ListItem>
				)
			)}
		</List>
	)
}

const List = styled.ul`
	display: flex;
	flex-direction: column;
	width: 100%;
	padding: 8px 0;
	box-sizing: border-box;

	cursor: pointer;
	color: ${Colors.white.primary};
	background-color: ${Colors.midnight.primary};
	list-style-type: none;
	font-family: ${Fonts.inter.family};
	font-size: 11px;
	border-radius: 2px;
	box-shadow: 0 2px 14px 0 ${Colors.black.tint20};
`

const ListItem = styled.li`
	display: flex;
	box-sizing: border-box;
	display: flex;
	align-items: center;
	justify-content: space-between;
	height: 24px;
	padding: 0 16px;

	&:hover {
		background-color: ${Colors.blue.primary};
	}

	&:focus {
		outline: 0;
		box-shadow: inset 0 0 0 2px ${Colors.blue.primary};
		background-color: ${Colors.blue.primary};
	}

	/* hide focus styles on button click */
	:focus:not(:focus-visible) {
		outline: 0;
		box-shadow: none;
		background-color: transparent;
	}
`

const Text = styled.div`
	display: flex;
`
const Hint = styled.div``
const Divider = styled.div`
	margin: 8px 0;
	border-bottom: 1px solid ${Colors.white.tint20};
`
const IconWrapper = styled.div`
	display: flex;
	align-items: center;
	justify-content: center;
	padding-right: 8px;
	width: 20px;
`
