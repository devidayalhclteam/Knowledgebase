import * as React from 'react'
import { render, cleanup } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import { Menu } from '..'
import { menuList } from '../data'

afterEach(cleanup)

describe('Loading component ', () => {
	test('renders correctly', () => {
		const { container } = render(<Menu list={menuList} />)

		expect(container).toBeVisible()
	})
})
