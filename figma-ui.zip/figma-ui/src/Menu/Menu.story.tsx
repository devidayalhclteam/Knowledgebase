import React from 'react'
import styled from '@emotion/styled'
import { Story, Meta } from '@storybook/react'
import { Menu, IMenuProps } from './Menu'
import { menuList, selectionList } from './data'

export default {
	title: 'Figma/Menu',
	component: Menu,
	argTypes: {
		list: {
			defaultValue: menuList,
		},
		onClick: {},
		_submenu: {
			control: 'none',
		},
		_isOpen: {
			control: 'none',
		},
		_updateSubmenu: {
			control: 'none',
		},
	},
} as Meta

export const List: Story<IMenuProps> = (props: IMenuProps) => {
	return (
		<Container>
			<Menu {...props} />
		</Container>
	)
}

export const Selection: Story<IMenuProps> = (props: IMenuProps) => {
	return (
		<Container>
			<Menu {...props} list={selectionList} selected={0} />
		</Container>
	)
}

const Container = styled.div`
	min-height: 300px;
	width: 300px;
`
