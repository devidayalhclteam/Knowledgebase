import * as React from 'react'
import { render, cleanup } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import { Button } from '..'

afterEach(cleanup)

describe('Loading component ', () => {
	test('renders correctly', () => {
		const { container } = render(<Button label={`Button`} />)

		expect(container).toBeVisible()
	})
})