import * as React from 'react'
import styled from '@emotion/styled'
import { Colors, Fonts } from '../Styles/Themes'

export interface IButton {
	/** Button text */
	label: string

	/** Button aria-label, defaults to label */
	ariaLabel?: string

	/** Is button in a disabled state. */
	disabled?: boolean

	/** Alternative styling of outlined button. */
	outline?: boolean

	/** Alternative styling for destructive button. */
	destructive?: boolean

	/** Define the tab index of button, defaults to 0. */
	tabIndex?: number

	/** Element aria role */
	role?: string

	/** Callback for on focus handler */
	onFocus?: () => void

	/** Callback for on blur handler */
	onBlur?: () => void

	/** Callback for on click handler */
	onClick?: () => void

	/** Callback when mouse enter */
	onMouseEnter?: () => void

	/** Callback when mouse leave */
	onMouseLeave?: () => void

	/** Button can submit a form natively */
	submit?: boolean

	/** Create a custom button */
	children?: React.ReactNode
}

interface IButtonColors {
	fill: string
	border: string
	text: string
}

const Button = (props: IButton) => {
	const isDisabled = props.disabled ? true : false

	const buttonValue = props.submit ? 'submit' : 'button'

	const hasBackgroundFill = props.outline ? false : true

	let ButtonColors: IButtonColors = {
		fill: hasBackgroundFill ? Colors.blue.primary : 'transparent',
		border: hasBackgroundFill ? Colors.blue.primary : Colors.black.tint80,
		text: hasBackgroundFill ? Colors.white.primary : Colors.black.tint80,
	}

	if (props.destructive) {
		ButtonColors = {
			fill: hasBackgroundFill ? Colors.red.primary : 'transparent',
			border: props.disabled ? Colors.red.tint40 : Colors.red.primary,
			text: hasBackgroundFill ? Colors.white.primary : Colors.red.primary,
		}
	}

	if (isDisabled) {
		ButtonColors = {
			fill: hasBackgroundFill ? (props.destructive ? Colors.red.tint40 : Colors.black.tint30) : 'transparent',
			border: hasBackgroundFill ? 'transparent' : props.destructive ? Colors.red.tint40 : Colors.black.tint30,
			text: hasBackgroundFill ? Colors.white.primary : props.destructive ? Colors.red.tint40 : Colors.black.tint30,
		}
	}

	return (
		<StyledButton
			aria-label={props.ariaLabel ? props.ariaLabel : props.label}
			fillColor={ButtonColors.fill}
			boderColor={ButtonColors.border}
			textColor={ButtonColors.text}
			tabIndex={props.tabIndex}
			role={props.role}
			disabled={isDisabled}
			onFocus={props.onFocus}
			onBlur={props.onBlur}
			onClick={props.onClick}
			onMouseEnter={props.onMouseEnter}
			onMouseLeave={props.onMouseLeave}
			value={buttonValue}
		>
			{props.children ? props.children : props.label}
		</StyledButton>
	)
}

interface IButtonStyles {
	fillColor: string
	boderColor: string
	textColor: string
	disabled: boolean
}

const StyledButton = styled.button<IButtonStyles>`
	border-width: 1px;
	border-style: solid;
	border-color: ${(props: IButtonStyles) => props.boderColor};
	background-color: ${(props: IButtonStyles) => props.fillColor};
	color: ${(props: IButtonStyles) => props.textColor};
	border-radius: 6px;
	font-size: 12px;
	padding: 8px 10px 7px 10px;
	width: auto;
	min-width: 72px;
	font-family: ${Fonts.inter.family};
	cursor: ${(props: IButtonStyles) => (props.disabled ? 'default' : 'pointer')};
`

Button.defaultProps = {
	label: 'Button',
	disabled: false,
	outline: false,
	destructive: false,
	tabIndex: 0,
	role: 'button',
	onFocus: () => {},
	onBlur: () => {},
	onClick: () => {},
	onMouseEnter: () => {},
	onMouseLeave: () => {},
	submit: false,
}

export { Button }
