import * as React from 'react'

import { Story, Meta } from '@storybook/react'

import { Button, IButton } from './Button'

export default {
	title: 'Figma/Button',
	component: Button,
	argTypes: {
		label: {
			control: { type: 'text' },
		},
		disabled: {
			control: { type: 'boolean' },
		},
	},
} as Meta

const Template: Story<IButton> = (args: any) => <Button {...args} />

export const Default = Template.bind({})

Default.args = {
	disabled: false,
	label: 'Button',
}
