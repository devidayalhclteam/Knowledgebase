import React from 'react'
import { Story, Meta } from '@storybook/react'
import { OptionButton, IOptionButtonProps } from './OptionButton'
import { PiggyBank } from '../ButtonIcon/PiggyBank'

export default {
	title: 'Figma/Button (option)',
	component: OptionButton,
	argTypes: {
		children: {
			control: {
				type: 'none',
			},
		},
	},
} as Meta

/** Folder is named ButtonOption in order for Storybook list ordering to be alphabetical */
const Template: Story<IOptionButtonProps> = (props: IOptionButtonProps) => {
	return (
		<OptionButton {...props} onClick={(active) => console.log(active)}>
			<PiggyBank />
		</OptionButton>
	)
}
export const Default = Template.bind({})
