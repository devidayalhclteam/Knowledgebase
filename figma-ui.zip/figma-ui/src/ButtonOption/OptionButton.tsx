import * as React from 'react'
import styled from '@emotion/styled'
import { Colors } from '../Styles/Themes'

export interface IOptionButtonProps {
	/** Is button in a selected state */
	active?: boolean
	/** Is button in a disabled state. */
	disabled?: boolean
	/** Text label for accessibility */
	ariaLabel?: string
	/** Callback on button click */
	onClick?: (active: boolean) => void
	/** Icon component (svg recommended) */
	children: React.ReactNode
}

/** The option button is a switch */
export const OptionButton = (props: IOptionButtonProps) => {
	const [active, setActive] = React.useState(props.active ? props.active : false)
	const handleClick = () => {
		if (props.disabled) {
			return
		}

		setActive(!active)

		if (props.onClick) {
			props.onClick(active)
		}
	}

	const activeStyles: React.CSSProperties = {
		backgroundColor: Colors.black.tint10,
	}

	return (
		<Container aria-label={props.ariaLabel} disabled={props.disabled} onClick={handleClick}>
			<ActiveBox style={active ? activeStyles : {}}>{props.children}</ActiveBox>
		</Container>
	)
}

interface IStyles {
	disabled: boolean
}

const Container = styled.button<IStyles>`
	// Rest default Button styles
	background: none;
	color: inherit;
	border: none;
	cursor: default;
	outline: inherit;

	display: flex;
	align-items: center;
	justify-content: center;
	width: 32px;
	height: 32px;
	border-radius: 2px;

	path {
		fill: ${(props) => (props.disabled ? Colors.black.tint30 : Colors.black.tint80)};
	}

	&:hover {
		&:before {
			content: '';
			position: absolute;
			left: 1px;
			top: 1px;
			width: 30px;
			height: 30px;
			border-radius: 2px;
			border: 1px solid ${(props) => (props.disabled ? 'transparent' : Colors.black.tint10)};
		}
	}

	&:focus {
		border: 2px solid ${Colors.blue.primary};
	}

	/* hide focus styles on button click */
	:focus:not(:focus-visible) {
		outline: 0;
		border: 0;
		box-shadow: none;
	}
`

const ActiveBox = styled.div`
	display: flex;
	align-items: center;
	justify-content: center;
	width: 24px;
	height: 24px;
	border-radius: 2px;

	&:focus {
		outline: 0;
	}
`
