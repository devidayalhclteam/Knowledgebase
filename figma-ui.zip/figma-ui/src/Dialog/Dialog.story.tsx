import * as React from 'react'
import styled from '@emotion/styled'
import { Story, Meta } from '@storybook/react'
import { Dialog, IDialogProps } from './Dialog'

export default {
	title: 'Figma/Dialog',
	component: Dialog,
	argTypes: {
		buttonText: {
			defaultValue: 'Button',
		},
	},
} as Meta

const Template: Story<IDialogProps> = (props: IDialogProps) => {
	return (
		<Container>
			<Dialog
				{...props}
				onButtonClick={() => {
					console.log('Button clicked')
				}}
			/>
		</Container>
	)
}

const Container = styled.div`
	min-height: 350px;
`

export const Default = Template.bind({})
