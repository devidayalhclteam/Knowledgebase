import * as React from 'react'
import styled from '@emotion/styled'
import { Colors, Fonts } from '../Styles/Themes'
import { Weight } from '../Styles/Fonts'
import { Button } from '..'
import { IconButton } from '../ButtonIcon/IconButton'
import { Cancel } from './Cancel'

export interface IDialogProps {
	/** Header title */
	title: string
	/** Body description */
	description: string
	/** Button text */
	buttonText?: string
	/** Callback for on cancel button click handler */
	onCancelClick?: () => void
	/** Callback for on button click handler */
	onButtonClick?: () => void
}

export const Dialog = (props: IDialogProps) => {
	return (
		<Background>
			<Container onClick={(e) => e.stopPropagation()}>
				<HeaderWrapper>
					<Header>{props.title}</Header>
					<IconButtonWrapper>
						<IconButton onClick={props.onCancelClick}>
							<Cancel />
						</IconButton>
					</IconButtonWrapper>
				</HeaderWrapper>
				<Content>
					<Body>{props.description}</Body>
					{props.buttonText && (
						<ButtonWrapper>
							<Button label={props.buttonText} outline={true} onClick={props.onButtonClick} />
						</ButtonWrapper>
					)}
				</Content>
			</Container>
		</Background>
	)
}

const Background = styled.div`
	position: absolute;
	top: 0;
	left: 0;
	display: flex;
	align-items: center;
	justify-content: center;
	width: 100%;
	height: 100%;
	background-color: transparent;
	padding: 8px;
`
const Container = styled.div`
	display: flex;
	flex-direction: column;
	width: 100%;
	min-height: 96px;
	max-height: 300px;
	background: ${Colors.white.primary};
	border: 1px solid ${Colors.black.tint20};
	border-radius: 2px;
	box-shadow: 0 2px 14px 0 ${Colors.black.tint15};
	color: ${Colors.black.tint80};
	font-family: ${Fonts.inter.family};
	overflow: hidden;
`
const Content = styled.div`
	display: flex;
	flex-direction: column;
	overflow: hidden;
	overflow-y: auto;
	margin: 16px;
`
const HeaderWrapper = styled.div`
	display: flex;
	width: 100%;
	height: 40px;
	flex-direction: row;
	justify-content: space-between;
	align-items: center;
	border-bottom: 1px solid ${Colors.black.tint10};
	padding-left: 16px;
`
const Header = styled.div`
	display: flex;
	font-size: 11px;
	font-weight: ${Weight.bold};
`
const IconButtonWrapper = styled.div`
	display: flex;
	align-items: center;
	padding: 4px;
`
const Body = styled.div`
	display: flex;
	margin-bottom: 8px;
	font-size: 11px;
`
const ButtonWrapper = styled.footer`
	display: flex;
	justify-content: flex-end;
	align-items: center;
	width: 100%;
`

Dialog.defaultProps = {
	title: 'Dialog',
	description: "Hello, I'm a dialog",
}
