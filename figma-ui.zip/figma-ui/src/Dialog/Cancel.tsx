import { Colors } from '../Styles/Themes'
import * as React from 'react'

export const Cancel = (props: { color?: string }) => (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fillRule="evenodd" clipRule="evenodd" d="M6.00002 5.29304L10.6465 0.646576L11.3536 1.35368L6.70713 6.00015L11.3536 10.6466L10.6465 11.3537L6.00002 6.70725L1.35359 11.3537L0.646484 10.6466L5.29291 6.00015L0.646486 1.35376L1.35359 0.646651L6.00002 5.29304Z" fill={props.color ? props.color : Colors.black.tint80} />
    </svg>

)