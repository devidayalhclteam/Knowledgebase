import * as React from 'react'
import { render, cleanup } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import { Dialog } from '..'

afterEach(cleanup)

describe('Loading component ', () => {
	test('renders correctly', () => {
		const { container } = render(<Dialog title={"Dialog"} description={"Hello, I'm a dialog"}/>)

		expect(container).toBeVisible()
	})
})