import * as React from 'react'
import styled from '@emotion/styled'
import { Colors } from '../Styles/Themes'

export interface IIconButtonProps {
	/** Icon color (default: Colors.black.tint80) */
	iconColor?: string
	/** Background color */
	backgroundColor?: string
	/** Is button in a disabled state. */
	disabled?: boolean
	/** Text label for accessibility */
	ariaLabel?: string
	/** Callback on button click */
	onClick?: () => void
	/** Icon component (svg recommended) */
	children: React.ReactNode
}

export const IconButton = (props: IIconButtonProps) => {
	const handleClick = () => {
		return !props.disabled && props.onClick && props.onClick()
	}

	return (
		<Container
			aria-label={props.ariaLabel}
			disabled={props.disabled}
			iconColor={props.iconColor}
			backgroundColor={props.backgroundColor}
			onClick={handleClick}
		>
			{props.children}
		</Container>
	)
}

interface IStyles {
	iconColor: string
	backgroundColor: string
	disabled: boolean
}

const Container = styled.button<IStyles>`
	/* Reset default Button styles */
	background: none;
	color: inherit;
	border: none;
	cursor: default;
	outline: inherit;

	width: 32px;
	height: 32px;
	border-radius: 2px;
	background-color: ${(props) =>
		props.backgroundColor ? (!props.disabled ? props.backgroundColor : Colors.black.tint30) : 'transparent'};

	path {
		fill: ${(props) => (!props.disabled ? props.iconColor : props.backgroundColor ? Colors.white.primary : Colors.black.tint30)};
	}

	&:hover {
		background-color: ${(props) =>
			props.backgroundColor
				? !props.disabled
					? props.backgroundColor
					: Colors.black.tint30
				: !props.disabled
				? '#efefef'
				: 'transparent'}; // Todo: Add #efefef to colors (Hover color)
	}

	&:focus {
		border: 2px solid ${(props) => (props.backgroundColor ? Colors.black.tint30 : Colors.blue.primary)};
	}

	/* hide focus styles on button click */
	:focus:not(:focus-visible) {
		outline: 0;
		border: 0;
		box-shadow: none;
	}
`

IconButton.defaultProps = {
	iconColor: '#000000CC', // Using hex, Colors.black.tint30 is added as string
}
