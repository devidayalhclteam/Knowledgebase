import React from 'react'
import { Story, Meta } from '@storybook/react'

import { IconButton, IIconButtonProps } from './IconButton'
import { PiggyBank } from './PiggyBank'

export default {
	title: 'Figma/Button (icon)',
	component: IconButton,
	argTypes: {
		children: {
			control: {
				type: 'none',
			},
		},
		backgroundColor: {
			control: {
				type: 'color',
			},
		},
		iconColor: {
			control: {
				type: 'color',
			},
		},
	},
} as Meta

/** Folder is named ButtonIcon in order for Storybook list ordering to be alphabetical */
const Template: Story<IIconButtonProps> = (props: IIconButtonProps) => {
	return (
		<IconButton {...props} onClick={() => console.log('Click')}>
			<PiggyBank />
		</IconButton>
	)
}
export const Default = Template.bind({})
