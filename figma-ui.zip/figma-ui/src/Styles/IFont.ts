export interface IFont {
	family: string
}

export interface IWeight{
	regular:number,
	medium: number,
	bold: number

}

export interface ISize{
	size11: string,
	size12: string,
	size13: string,
	size14: string,
}