import { Black, Midnight, Charcoal, Grey, Silver, White, Blue, Purple, HotPink, Green, Red, Yellow } from './Colors'
import { IPalette } from './IPalette'

export const Neutrals: IPalette = {
	black: Black.primary,
	white: White.primary,
	grey: Grey.primary,
	charcoal: Charcoal.primary,
	midnight: Midnight.primary,
	silver: Silver.primary,
}

export const Bright: IPalette = {
	blue: Blue.primary,
	purple: Purple.primary,
	hotPink: HotPink.primary,
	green: Green.primary,
	red: Red.primary,
	yellow: Yellow.primary,
}

export const Selection: IPalette = {
	selectionA: Blue.tint20,
	selectionB: Blue.tint10,
}