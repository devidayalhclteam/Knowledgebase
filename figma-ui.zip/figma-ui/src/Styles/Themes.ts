import {
	Black,
	Midnight,
	Charcoal,
	Grey,
	Silver,
	White,
	Blue,
	Purple,
	HotPink,
	Green,
	Red,
	Yellow,
} from './Colors'

export const Colors = {
	black: Black,
	midnight: Midnight,
	charcoal: Charcoal,
	grey: Grey,
	silver: Silver,
	white: White,
	blue: Blue,
	purple: Purple,
	hotPink: HotPink,
	green: Green,
	red: Red,
	yellow: Yellow,
}

import {
	Inter, Size, Weight,
} from './Fonts'

export const Fonts = {
	inter: Inter,
	weight: Weight,
	size:Size
}