export interface IColor {
	primary: string
	tint90: string
	tint80: string
	tint70: string
	tint60: string
	tint50: string
	tint40: string
	tint35?: string
	tint30: string
	tint20: string
	tint15?: string
	tint10: string
	tint06?: string
}