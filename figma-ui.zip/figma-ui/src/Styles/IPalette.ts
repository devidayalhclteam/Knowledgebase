export interface IPalette {
	[prop: string]: string;
}