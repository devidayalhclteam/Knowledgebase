export interface IElevation {
    /** Cursor shadow */
	one: string
    /** HUD shadow */
    two: string
}