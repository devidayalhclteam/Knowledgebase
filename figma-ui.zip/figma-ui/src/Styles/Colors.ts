import { IColor } from './IColor'

export const Black: IColor = {
	primary: '#000000FF',
	tint90: '#000000E6',
	tint80: '#000000CC',
	tint70: '#000000B3',
	tint60: '#00000099',
	tint50: '#00000080',
	tint40: '#00000066',
	tint35: '#00000059',
	tint30: '#0000004D',
	tint20: '#00000033',
	tint15: '#00000026',
	tint10: '#0000001A',
	tint06: '#0000000F'
}

export const Midnight: IColor = {
	primary: '#222222FF',
	tint90: '#222222E6',
	tint80: '#222222CC',
	tint70: '#222222B3',
	tint60: '#22222299',
	tint50: '#22222280',
	tint40: '#22222266',
	tint30: '#2222224D',
	tint20: '#22222233',
	tint10: '#2222221A',
}

export const Charcoal: IColor = {
	primary: '#2C2C2CFF',
	tint90: '#2C2C2CE6',
	tint80: '#2C2C2CCC',
	tint70: '#2C2C2CB3',
	tint60: '#2C2C2C99',
	tint50: '#2C2C2C80',
	tint40: '#2C2C2C66',
	tint30: '#2C2C2C4D',
	tint20: '#2C2C2C33',
	tint10: '#2C2C2C1A',
}

export const Grey: IColor = {
	primary: '#F0F0F0FF',
	tint90: '#F0F0F0E6',
	tint80: '#F0F0F0CC',
	tint70: '#F0F0F0B3',
	tint60: '#F0F0F099',
	tint50: '#F0F0F080',
	tint40: '#F0F0F066',
	tint30: '#F0F0F04D',
	tint20: '#F0F0F033',
	tint10: '#F0F0F01A',
}

export const Silver: IColor = {
	primary: '#E5E5E5FF',
	tint90: '#E5E5E5E6',
	tint80: '#E5E5E5CC',
	tint70: '#E5E5E5B3',
	tint60: '#E5E5E599',
	tint50: '#E5E5E580',
	tint40: '#E5E5E566',
	tint30: '#E5E5E54D',
	tint20: '#E5E5E533',
	tint10: '#E5E5E51A',
}

export const White: IColor = {
	primary: '#FFFFFFFF',
	tint90: '#FFFFFFE6',
	tint80: '#FFFFFFCC',
	tint70: '#FFFFFFB3',
	tint60: '#FFFFFF99',
	tint50: '#FFFFFF80',
	tint40: '#FFFFFF66',
	tint30: '#FFFFFF4D',
	tint20: '#FFFFFF33',
	tint10: '#FFFFFF1A',
}

export const Blue: IColor = {
	primary: '#18A0FBFF',
	tint90: '#18A0FBE6',
	tint80: '#18A0FBCC',
	tint70: '#18A0FBB3',
	tint60: '#18A0FB99',
	tint50: '#18A0FB80',
	tint40: '#18A0FB66',
	tint30: '#18A0FB4D',
	tint20: '#18A0FB33',
	tint10: '#18A0FB1A',
}

export const Purple: IColor = {
	primary: '#7B61FFFF',
	tint90: '#7B61FFE6',
	tint80: '#7B61FFCC',
	tint70: '#7B61FFB3',
	tint60: '#7B61FF99',
	tint50: '#7B61FF80',
	tint40: '#7B61FF66',
	tint30: '#7B61FF4D',
	tint20: '#7B61FF33',
	tint10: '#7B61FF1A',
}

export const HotPink: IColor = {
	primary: '#FF00FFFF',
	tint90: '#FF00FFE6',
	tint80: '#FF00FFCC',
	tint70: '#FF00FFB3',
	tint60: '#FF00FF99',
	tint50: '#FF00FF80',
	tint40: '#FF00FF66',
	tint30: '#FF00FF4D',
	tint20: '#FF00FF33',
	tint10: '#FF00FF1A',
}

export const Green: IColor = {
	primary: '#1BC47DFF',
	tint90: '#1BC47DE6',
	tint80: '#1BC47DCC',
	tint70: '#1BC47DB3',
	tint60: '#1BC47D99',
	tint50: '#1BC47D80',
	tint40: '#1BC47D66',
	tint30: '#1BC47D4D',
	tint20: '#1BC47D33',
	tint10: '#1BC47D1A',
}

export const Red: IColor = {
	primary: '#F24822FF',
	tint90: '#F24822E6',
	tint80: '#F24822CC',
	tint70: '#F24822B3',
	tint60: '#F2482299',
	tint50: '#F2482280',
	tint40: '#F2482266',
	tint30: '#F248224D',
	tint20: '#F2482233',
	tint10: '#F248221A',
}

export const Yellow: IColor = {
	primary: '#FFEB00FF',
	tint90: '#FFEB00E6',
	tint80: '#FFEB00CC',
	tint70: '#FFEB00B3',
	tint60: '#FFEB0099',
	tint50: '#FFEB0080',
	tint40: '#FFEB0066',
	tint30: '#FFEB004D',
	tint20: '#FFEB0033',
	tint10: '#FFEB001A',
}
