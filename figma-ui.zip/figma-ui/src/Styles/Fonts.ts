import { IFont, ISize, IWeight } from './IFont'

export const Inter: IFont = {
	family: `'Inter', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif`,
}

export const Weight: IWeight = {
	regular: 400,
	medium: 500,
	bold: 600
}


export const Size: ISize = {
	size11: '11px',
	size12: '12px',
	size13: '13px',
	size14: '14px'
}