
import { IElevation } from './IElevation'
import { Colors } from './Themes'

export const Elevation: IElevation = {
	one: `0 1px 3px 0 ${Colors.black.tint35}`,
    two: `0 2px 7px 0 ${Colors.black.tint15}, 0 5px 17px 0 ${Colors.black.tint20}`,
}