import { IRGB, MAX_COLOR_RGB } from './consts';
import { Clamp } from './Clamp';

/** Converts RGB components to a hex color string (without # prefix). */
export function Rgb2Hex(props:IRGB): string {

  return [_rgbToPaddedHex(props.r), _rgbToPaddedHex(props.g), _rgbToPaddedHex(props.b)].join('');
}

/** Converts an RGB component to a 0-padded hex component of length 2. */
function _rgbToPaddedHex(num: number): string {
  num = Clamp(num, MAX_COLOR_RGB);
  const hex = num?.toString(16);

  return hex?.length === 1 ? '0' + hex : hex;
}