import { IHSV, MAX_COLOR_SATURATION, MAX_COLOR_VALUE } from './consts';
import { Hsv2Hex } from './Hsv2Hex';

/**
 * Converts a color hue to an HTML color string (with # prefix).
 * This implementation ignores all components of `color` except hue.
 */
export function GetFullColorString(color: IHSV): string {
  return `#${Hsv2Hex(color.h, MAX_COLOR_SATURATION, MAX_COLOR_VALUE)}`;
}