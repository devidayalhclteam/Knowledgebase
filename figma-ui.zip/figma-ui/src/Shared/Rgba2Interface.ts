import { IRGBA } from "./consts"

export const Rgba2Interface = (color: string): IRGBA => {
	const rgba = color.substring(color.indexOf('(') + 1, color.length - 1).split(',')

	return rgba ? ({ r: Number(rgba[0]), g: Number(rgba[1]), b: Number(rgba[2]), a: Number(rgba[3]) } as IRGBA) : { r: 0, g: 0, b: 0, a: 1 }
}