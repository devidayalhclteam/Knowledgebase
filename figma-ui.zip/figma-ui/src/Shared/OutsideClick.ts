import * as React from 'react'

/**
 * Hook that runs callback when clicks occur outside of the passed ref
 */
export function OutsideClick(ref: any, callback: () => void) {
	React.useEffect(() => {
		function handleClickOutside(event: any) {
			if (ref.current && !ref.current.contains(event.target)) {
				callback()
			}
		}

		// Bind the event listener
		document.addEventListener('mousedown', handleClickOutside)
		return () => {
			// Unbind the event listener on clean up
			document.removeEventListener('mousedown', handleClickOutside)
		}
	}, [ref])
}
