import * as React from 'react'
import styled from '@emotion/styled'
import { css } from '@emotion/react'
import { Colors, Fonts } from '../Styles/Themes'
import { Weight } from '../Styles/Fonts'
import { CheckedIcon } from './CheckedIcon'

export interface ICheckboxProps {
	/** Checkbox text */
	label?: string
	/** Starting checked state.  Use null to specify a mixed state. Default is unchecked */
	checked?: boolean | null
	/** Checkbox includes mixed state */
	mixed?: boolean
	/** Checkbox is in a disabled state */
	disabled?: boolean
	/** Additional descriptive text */
	description?: string
	/** Checkbox aria-label, defaults to label  */
	ariaLabel?: string
	/** Callback for onClick handler */
	onClick: (checked: boolean | null, label: string | undefined) => void
}

export const Checkbox = (props: ICheckboxProps) => {
	const [checked, setChecked] = React.useState(props.checked)
	const isMixed = checked === null || props.mixed

	// This helps storybook controls update the components
	React.useEffect(() => {
		setChecked(props.checked)
	}, [props.checked])

	const handleClick = () => {
		if (props.disabled) {
			return
		}
		let state: boolean | null = !checked

		if (isMixed) {
			state = checked ? null : checked === null ? false : true
		}

		setChecked(state)
		props.onClick(state, props.label)
	}

	const baseStyle = {
		borderColor: checked && !isMixed ? Colors.blue.primary : Colors.black.tint80,
		cursor: 'pointer',
	}

	const disabledStyle = {
		borderColor: checked ? 'transparent' : Colors.black.tint30,
		cursor: 'default',
	}

	return (
		<>
			<Container>
				<CheckboxWrapper
					tabIndex={0}
					role="checkbox"
					aria-label={props.ariaLabel ? props.ariaLabel : props.label}
					aria-checked={checked === null ? 'mixed' : checked}
					aria-disabled={props.disabled}
					checked={checked}
					onClick={handleClick}
				>
					<Box tabIndex={-1} style={props.disabled ? { ...disabledStyle } : { ...baseStyle }}>
						{checked && <CheckedIcon isDisabled={props.disabled} />}
						{checked === null && <Mixed style={{ color: props.disabled ? Colors.black.tint30 : Colors.black.tint80 }}>–</Mixed>}
					</Box>
				</CheckboxWrapper>
				{props.label && <Label style={{ color: props.disabled ? Colors.black.tint30 : Colors.black.tint80 }}>{props.label}</Label>}
			</Container>
			{props.description && <Description>{props.description}</Description>}
		</>
	)
}

const Container = styled.div`
	display: flex;
	align-items: center;
	width: 100%;
	height: 32px;
	font-family: ${Fonts.inter.family};
	font-size: 11px;
`

interface IStyle {
	checked: boolean | null | undefined
}

const CheckedFocused = css`
	box-shadow: 0 0 0 1px white, 0 0 0 2px ${Colors.blue.primary};
`
const UnCheckedFocused = css`
	border-color: ${Colors.blue.primary} !important;
	box-shadow: 0 0 0 1px ${Colors.blue.primary};
`

const Box = styled.div`
	display: flex;
	align-items: center;
	justify-content: center;
	width: 12px;
	height: 12px;
	border: 1px solid ${Colors.black.tint80};
	border-radius: 2px;

	&:focus {
		outline: 0;
	}
`

const CheckboxWrapper = styled.button<IStyle>`
	display: flex;
	align-items: center;
	justify-content: center;
	border: 0;
	margin: 0 10px;
	background-color: transparent;

	/* Prevent focus style on checkbox onClick */
	&:focus > ${Box} {
		${(props) => (props.checked ? CheckedFocused : UnCheckedFocused)};
	}

	&:focus {
		outline: 0;
	}
`

const Label = styled.div``

const Description = styled.div`
	color: ${Colors.black.tint30};
	padding-left: 32px;
	font-family: ${Fonts.inter.family};
	font-size: 11px;
`

const Mixed = styled.div`
	font-weight: ${Weight.bold};
	font-size: 11px;
	top: -1px;
`

Checkbox.defaultProps = {
	label: 'Checkbox',
}
