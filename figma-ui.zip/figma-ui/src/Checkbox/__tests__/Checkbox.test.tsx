import * as React from 'react'
import { render, cleanup } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import { Checkbox } from '..'

afterEach(cleanup)

describe('Loading component ', () => {
	test('renders correctly', () => {
		const { container } = render(<Checkbox label={`Button`} onClick={() => console.log('click')} />)

		expect(container).toBeVisible()
	})
})
