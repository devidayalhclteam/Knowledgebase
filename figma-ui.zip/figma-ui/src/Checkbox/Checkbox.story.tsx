import React from 'react'
import { Story, Meta } from '@storybook/react'
import { useArgs } from '@storybook/client-api'

import { Checkbox, ICheckboxProps } from './Checkbox'

export default {
	title: 'Figma/Checkbox',
	component: Checkbox,
	argTypes: {
		checked: {
			control: {
				type: 'select',
				options: [true, false, null],
			},
		},
	},
} as Meta

const Template: Story<ICheckboxProps> = (props: ICheckboxProps) => {
	const [args, updateArgs] = useArgs()
	return (
		<Checkbox
			{...props}
			{...args}
			onClick={(checked) => {
				updateArgs({ checked: checked })
			}}
		/>
	)
}
export const Default = Template.bind({})
