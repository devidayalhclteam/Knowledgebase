import * as React from 'react'
import { render, cleanup } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import { ModalDialog } from '..'

afterEach(cleanup)

describe('Loading component ', () => {
	test('renders correctly', () => {
		const { container } = render(<ModalDialog title={"Modal dialog"} description={"Hello, I'm a dialog that's modal"}/>)

		expect(container).toBeVisible()
	})
})