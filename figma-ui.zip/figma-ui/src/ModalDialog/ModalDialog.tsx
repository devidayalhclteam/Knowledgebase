import * as React from 'react'
import styled from '@emotion/styled'
import { Button } from '..'
import { Colors, Fonts } from '../Styles/Themes'
import { Weight } from '../Styles/Fonts'

export interface IModalDialogProps {
	/** Header title */
	title: string
	/** Body description */
	description?: string
	/** Cancel Button text */
	cancelButtonText?: string
	/** Next Button text */
	nextButtonText?: string
	/** Children can be any  React.ReactNode*/
	children?: React.ReactNode
	/** Callback for on cancel button click handler */
	cancelClick?: () => void
	/** Callback for on next button click handler */
	nextClick?: () => void
}

export const ModalDialog = (props: IModalDialogProps) => {
	return (
		<DimBackground onClick={props.cancelClick}>
			<Container onClick={(e) => e.stopPropagation()}>
				<Content>
					<Header>{props.title}</Header>
					{props.description && <Body>{props.description}</Body>}
					{props.children}
				</Content>
				<Footer>
					<ButtonWrapper>
						<Button
							label={props.cancelButtonText ? props.cancelButtonText : 'Cancel'}
							outline={true}
							onClick={props.cancelClick}
						/>
					</ButtonWrapper>
					<ButtonWrapper>
						<Button label={props.nextButtonText ? props.nextButtonText : 'Next'} onClick={props.nextClick} />
					</ButtonWrapper>
				</Footer>
			</Container>
		</DimBackground>
	)
}

const DimBackground = styled.div`
	position: absolute;
	top: 0;
	left: 0;
	display: flex;
	align-items: center;
	justify-content: center;
	width: 100%;
	height: 100%;
	background-color: ${Colors.black.tint10};
	padding: 8px;
`
const Container = styled.div`
	display: flex;
	flex-direction: column;
	width: 100%;
	min-height: 110px;
	max-height: 300px;
	background: ${Colors.white.primary};
	border: 0.5px solid ${Colors.black.tint20};
	border-radius: 2px;
	box-shadow: 0 2px 14px 0 ${Colors.black.tint15};
	color: ${Colors.black.tint80};
	font-family: ${Fonts.inter.family};
	overflow: hidden;
`
const Content = styled.div`
	display: flex;
	flex-direction: column;
	overflow: hidden;
	overflow-y: auto;
	margin: 16px;
	margin-bottom: 0px;
`
const Header = styled.div`
	display: flex;
	margin-bottom: 16px;
	font-size: 11px;
	font-weight: ${Weight.bold};
`
const Body = styled.div`
	display: flex;
	margin-bottom: 8px;
	font-size: 11px;
`
const Footer = styled.footer`
	display: flex;
	justify-content: flex-end;
	align-items: center;
	width: 100%;
	height: 64px;
	padding: 0 8px;
`
const ButtonWrapper = styled.div`
	padding-right: 8px;
`
ModalDialog.defaultProps = {
	title: 'Modal dialog',
}
