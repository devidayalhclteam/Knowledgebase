import * as React from 'react'
import styled from '@emotion/styled'
import { Story, Meta } from '@storybook/react'
import { ModalDialog, IModalDialogProps } from './ModalDialog'
import { useArgs } from '@storybook/addons'
import { Colors } from '../Styles/Themes'

export default {
	title: 'Figma/ModalDialog',
	component: ModalDialog,
	argTypes: {
		description: {
			defaultValue: "Hello, I'm a dialog that's modal",
		},
		nextButtonText: {
			defaultValue: 'Commit',
		},
		children: {
			defaultValue: false,
			control: {
				type: 'boolean',
			},
		},
	},
} as Meta

const Template: Story<IModalDialogProps> = (props: IModalDialogProps) => {
	const [args] = useArgs()

	return (
		<Container>
			<ModalDialog
				{...props}
				cancelClick={() => {
					console.log('Cancel clicked')
				}}
				nextClick={() => {
					console.log('Next clicked')
				}}
			>
				{args.children && <InputField />}
			</ModalDialog>
		</Container>
	)
}
export const Default = Template.bind({})

const Container = styled.div`
	min-height: 350px;
`
const InputField = () => <Input placeholder={'Search for username or email'} />

const Input = styled.input`
	width: 100%;
	height: 32px;
	min-height: 32px;
	padding: 8px;
	margin-bottom: 16px;
	outline: 1px inset transparent;
	border: 1px solid ${Colors.silver.primary};
	font-size: 11px;
	border-radius: 2px;

	&:focus {
		padding-left: 7px;
		border: 2px solid ${Colors.blue.primary} !important;
	}

	&:hover:not(:focus) {
		border: 1px solid ${Colors.silver.primary} !important;
	}

	transition: border 250ms ease-in, padding 250ms ease-in;
`
