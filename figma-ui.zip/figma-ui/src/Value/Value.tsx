import * as React from 'react'

import styled from '@emotion/styled'
import { Colors } from '../Styles/Themes'

export interface IValueProps {
	/** Set default value of input field */
	defaultValue?: string
	/** Add placeholder text to empty field */
	placeholder?: string
	/** Value is in a disabled state */
	disabled?: boolean
	/** Add border to field */
	hasBorder?: boolean
	/** Add icon to input field */
	icon?: React.ReactNode
	/** Add additional styles to the input field */
	style?: React.CSSProperties
	/** Callback for onChange event */
	onChange?: (value: string) => void
	/** Callback when input is submited (User hits return/enter key) */
	submit?: any
	/** Callback for onBlur event */
	blur?: (e: React.FocusEvent) => void
}

/** Basic input field */
export const Value = React.forwardRef((props: IValueProps, ref: any) => {
	const [value, setValue] = React.useState(props.defaultValue)
	const isEmpty = value?.replace(' ', '').length === 0 && !props.placeholder

	React.useEffect(() => {
		setValue(props.defaultValue)
	}, [props.defaultValue])

	/** Submit value on enter/return  */
	const handleKeyDown = (event: React.KeyboardEvent) => {
		if (event.key.toLowerCase() === 'enter' || event.key.toLowerCase() === 'return') {
			props.submit(event)
		}
	}

	const baseStyle = {
		color: Colors.black.tint80,
		borderColor: props.hasBorder ? Colors.black.tint10 : 'transparent',
		borderBottom: isEmpty || props.hasBorder ? `1px solid ${Colors.black.tint10}` : '',
		cursor: 'pointer',
	}

	const disabledStyle = {
		color: Colors.black.tint30,
		borderBottom: isEmpty ? `1px solid ${Colors.black.tint10}` : '',
		cursor: 'default',
	}

	const handleOnChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		setValue(e.target.value)
		if (props.onChange) {
			props.onChange(e.target.value)
		}
	}

	return (
		<>
			<Input
				type="text"
				ref={ref}
				icon={Boolean(props.icon)}
				disabled={props.disabled}
				value={value}
				placeholder={props.placeholder}
				onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleOnChange(e)}
				onKeyDown={handleKeyDown}
				onBlur={props.blur}
				aria-disabled={props.disabled}
				style={props.disabled ? { ...disabledStyle, ...props.style } : { ...baseStyle, ...props.style }}
			/>
			{props.icon && <Icon>{props.icon}</Icon>}
		</>
	)
})

interface IStyles {
	icon: boolean
}

const Input = styled.input<IStyles>`
	width: 100%;
	height: 32px;
	min-height: 32px;
	border: 0;
	padding: ${(props) => (props.icon ? '0 8px 0 32px' : '0 8px')};
	outline: 1px inset transparent;
	border: 1px solid transparent;
	font-size: 11px;
	border-radius: 2px;

	&:focus {
		padding-left: ${(props) => (props.icon ? '31px' : '7px')};
		border: 2px solid ${Colors.blue.primary} !important;
	}

	&:hover:not(:focus) {
		border: 1px solid ${Colors.black.tint10} !important;
	}

	&:disabled {
		background-color: transparent;
	}
	transition: border 250ms ease-in, padding 250ms ease-in;
`
const Icon = styled.div`
	pointer-events: none;
	position: absolute;
	display: flex;
	justify-content: center;
	align-items: center;
	top: 0;
	left: 0;
	width: 32px;
	height: 32px;
`
