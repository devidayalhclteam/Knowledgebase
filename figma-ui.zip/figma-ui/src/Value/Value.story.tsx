import React from 'react'
import { Story, Meta } from '@storybook/react'
import { useArgs } from '@storybook/client-api'
import { Value, IValueProps } from './Value'
import { PiggyBank } from '../ButtonIcon/PiggyBank'

export default {
	title: 'Figma/Value',
	component: Value,
	argTypes: {
		defaultValue: {
			defaultValue: 'Value',
		},
		placeholder: {
			defaultValue: 'Placeholder',
		},
		style: {
			control: 'none',
		},
		icon: {
			defaultValue: false,
			control: {
				type: 'boolean',
			},
		},
	},
} as Meta

const Template: Story<IValueProps> = (props: IValueProps) => {
	const [args, updateArgs] = useArgs()
	return (
		<Value
			{...props}
			{...args}
			icon={args.icon && <PiggyBank />}
			onChange={(value: string) => {
				updateArgs({ defaultValue: value })
			}}
		/>
	)
}
export const Default = Template.bind({})
