import React from 'react'
import { Story, Meta } from '@storybook/react'
import { TabStrip } from '.'
import { ITabStripProps } from './TabStrip'
import styled from '@emotion/styled'

enum TabType {
	Home = 'Home',
	One = 'One',
	Two = 'Two',
	Three = 'Three',
	About = 'About',
}

export default {
	title: 'Figma/TabStrip',
	component: TabStrip,
	argTypes: {
		tabs: {
			defaultValue: Object.keys(TabType).map((key) => key),
		},
	},
} as Meta

const Template: Story<ITabStripProps> = (props: ITabStripProps) => {
	const [tab, setTab] = React.useState(TabType.Home)
	return (
		<Container>
			<TabStrip
				{...props}
				onClick={(tab: string) => {
					setTab(tab as TabType)
				}}
			/>
			{props.tabs.map((key) => tab === (key as TabType) && <Page key={tab}>{tab}</Page>)}
		</Container>
	)
}

export const Default = Template.bind({})

const Container = styled.div`
	display: flex;
	flex-direction: column;
	width: 304px;
	height: 300px;
`
const Page = styled.div`
	display: flex;
	width: 100%;
	height: 100%;
	align-items: center;
	justify-content: center;
`
