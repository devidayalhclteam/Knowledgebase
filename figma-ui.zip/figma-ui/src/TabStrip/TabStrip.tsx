import * as React from 'react'

import styled from '@emotion/styled'
import { Colors, Fonts } from '../Styles/Themes'
import { Weight } from '../Styles/Fonts'

export interface ITabStripProps {
	/** Array of tab names */
	tabs: string[]
	/** Callback for clicked tab */
	onClick?: (tab: string) => void
}

/** Standard tab menu navigation */
export const TabStrip = (props: ITabStripProps) => {
	const [active, setActive] = React.useState(0)

	const handleClick = (tab: string, index: number) => {
		setActive(index)
		if (props.onClick) {
			props.onClick(tab)
		}
	}

	return (
		<Nav>
			{props.tabs.map((tab, index) => (
				<Tab
					key={tab}
					style={{ color: active === index ? Colors.black.tint80 : Colors.black.tint30 }}
					onClick={() => handleClick(tab, index)}
				>
					{tab}
				</Tab>
			))}
		</Nav>
	)
}

const Nav = styled.nav`
	display: flex;
	height: 40px;
	min-height: 40px;
	padding: 0 8px;
	font-family: ${Fonts.inter.family};
	font-size: 11px;
	border-bottom: 1px solid ${Colors.silver.primary};
`

const Tab = styled.button`
	display: flex;
	justify-content: center;
	align-items: center;
	padding: 0 8px;
	height: 100%;
	background: none;
	border: none;
	font: inherit;
	outline: inherit;
	font-weight: ${Weight.bold};

	&:hover {
		color: ${Colors.black.tint80} !important;
	}

	&:focus {
		outline: 2px solid ${Colors.blue.primary};
	}

	/* hide focus styles on button click */
	:focus:not(:focus-visible) {
		outline: 0;
		box-shadow: none;
	}
`
