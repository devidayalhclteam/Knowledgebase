import * as React from 'react'

export const PrevIcon = () => (
	<svg style={{ transform: 'rotate(180deg)' }} width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
		<path
			d="M4.49447 8.14453L8.139 4.5L4.49447 0.855468L3.79135 1.55469L6.23275 3.99219H0.0999413V5.00781H6.23275L3.79135 7.44922L4.49447 8.14453Z"
			fill="black"
			fillOpacity="0.8"
		/>
	</svg>
)
