import * as React from 'react'
import { render, cleanup } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import { FirstRun } from '..'

afterEach(cleanup)

describe('Loading component ', () => {
	test('renders correctly', () => {
		const { container } = render(
			<FirstRun
				data={[
					{
						header: 'Welcome',
						description:
							'Select one or multiple icons on your canvas to get the process started. Pick the sizes and weights you need to generate.',
					},
				]}
				onButtonClick={() => console.log('End FRE')}
			/>
		)

		expect(container).toBeVisible()
	})
})
