import * as React from 'react'
import styled from '@emotion/styled'
import lottie from 'lottie-web/build/player/lottie_light'
import { Colors, Fonts } from '../Styles/Themes'
import { Weight } from '../Styles/Fonts'
import { Button } from '../'
import { PrevIcon } from './PrevIcon'
import { NextIcon } from './NextIcon'

export interface IFirstRun {
	/** lottie animation json file */
	lottieAnimationData?: any
	/** Header text */
	header: string
	/** Description text */
	description: string
	/** Arial label text for image animation description,  Default is Image animation */
	ariaLabel?: string
}

export interface IFirstRunProps {
	/** Array of IFirstRun */
	data: IFirstRun[]
	/** Callback for when button is clicked */
	onButtonClick?: (index: number, text: string) => void
}

export const FirstRun = (props: IFirstRunProps) => {
	const [index, setIndex] = React.useState(0)
	const ref = React.useRef(null)
	const isEnd = index === props.data.length - 1

	React.useEffect(() => {
		lottie.loadAnimation({
			container: ref.current,
			animationData: props.data[index].lottieAnimationData,
			loop: false,
			autoplay: true,
		})
	}, [index])

	const handleNextClick = () => {
		if (isEnd) {
			/* FRE is complete */
			props.onButtonClick(index, 'Start')
		} else {
			/* Advance FRE screen */
			setIndex(index + 1)
			props.onButtonClick(index, 'Next')
		}
	}

	const handlePrevClick = () => {
		setIndex(index - 1)
		props.onButtonClick(index, 'Prev')
	}

	return (
		<Container>
			<Hero
				style={{ backgroundColor: props.data[index].lottieAnimationData ? 'transparent' : Colors.purple.primary }}
				role="img"
				aria-label={props.data[index].ariaLabel ? props.data[index].ariaLabel : 'Image'}
			>
				<LottieWrapper key={index} ref={ref} />
			</Hero>
			<Content>
				<Header>{props.data[index].header}</Header>
				<Body>{props.data[index].description}</Body>
				<Footer>
					{index > 0 ? (
						<Button label={'Prev'} outline={true} onClick={handlePrevClick}>
							<PrevIcon /> Prev
						</Button>
					) : (
						<span />
					)}
					<Button label={isEnd ? 'Start' : 'Next'} outline={true} onClick={handleNextClick}>
						{isEnd ? (
							'Start'
						) : (
							<>
								Next <NextIcon />
							</>
						)}
					</Button>
				</Footer>
			</Content>
		</Container>
	)
}

const Container = styled.div`
	display: flex;
	flex-direction: column;
	width: 100%;
	height: 100%;
	font-family: ${Fonts.inter.family};
`
const Hero = styled.div`
	display: flex;
	justify-content: center;
	align-items: center;
	flex: 1;
	background-color: transparent;
`
const LottieWrapper = styled.div`
	width: 240px;
	height: 100%;
`
const Content = styled.div`
	display: flex;
	flex-direction: column;
	min-height: 144px;
	padding: 16px;
	padding-top: 19px;
	font-size: 11px;
	line-height: 1.5em;
`
const Header = styled.div`
	font-weight: ${Weight.bold};
`
const Body = styled.div`
	flex: 1;
`
const Footer = styled.div`
	display: flex;
	justify-content: space-between;
`
