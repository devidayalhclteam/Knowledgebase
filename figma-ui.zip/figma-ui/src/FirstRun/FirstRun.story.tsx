import * as React from 'react'

import { Story, Meta } from '@storybook/react'
/** Index.ts needs to be lowercase, it isn't being treated like a real index file.  I can't changing it to lowercase right now because the case change won't register as a change.  Temporarily changing it to this name */
import { FirstRun, IFirstRunProps, IFirstRun } from './FirstRun'

const data: IFirstRun[] = [
	{
		header: 'Welcome',
		description:
			'Select one or multiple icons on your canvas to get the process started. Pick the sizes and weights you need to generate.',
	},
	{
		header: 'Generate and check for errors',
		description:
			'Click on Generate and check the items on your canvas for errors. Correct any issues you have such as pixel placement or naming.',
	},
	{
		header: 'Get ready for export',
		description:
			'Select all the sizes you wish to export and add them to the plugin. Have a final check for even-diff errors and click ‘Export’ to download as a .zip file.',
	},
]

export default {
	title: 'Figma/FirstRun',
	component: FirstRun,
	argTypes: {
		data: {
			defaultValue: data,
			control: { type: 'none' },
		},
	},
} as Meta

const Template: Story<IFirstRunProps> = (props: IFirstRunProps) => {
	return (
		<FirstRun
			{...props}
			onButtonClick={(index, text) => {
				if (text === 'Start') {
					console.log('End FRE', index)
				}
			}}
		/>
	)
}

export const Default = Template.bind({})
