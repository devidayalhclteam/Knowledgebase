import * as React from 'react'

export const SwitchOn = (props: { disabled: boolean | undefined }) => (
	<svg width="24" height="12" viewBox="0 0 24 12" fill="none" xmlns="http://www.w3.org/2000/svg">
		<path
			fillRule="evenodd"
			clipRule="evenodd"
			d="M6 0C2.68629 0 0 2.68629 0 6C0 9.31371 2.68629 12 6 12H18C21.3137 12 24 9.31371 24 6C24 2.68629 21.3137 0 18 0H6ZM18 1C15.2386 1 13 3.23858 13 6C13 8.76142 15.2386 11 18 11C20.7614 11 23 8.76142 23 6C23 3.23858 20.7614 1 18 1Z"
			fill="black"
			fillOpacity={props.disabled ? 0.3 : 0.8}
		/>
	</svg>
)
