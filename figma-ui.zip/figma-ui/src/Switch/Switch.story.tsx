import React from 'react'
import { Story, Meta } from '@storybook/react'
import { useArgs } from '@storybook/client-api'
import { Switch, ISwitchProps } from './Switch'

export default {
	title: 'Figma/Switch',
	component: Switch,
	argTypes: {
		checked: {
			control: {
				type: 'select',
				options: [true, false, null],
			},
		},
	},
} as Meta

const Template: Story<ISwitchProps> = (props: ISwitchProps) => {
	const [args, updateArgs] = useArgs()
	return (
		<Switch
			{...props}
			{...args}
			onClick={(checked: boolean | null) => {
				updateArgs({ checked: checked })
			}}
		/>
	)
}
export const Default = Template.bind({})
