import * as React from 'react'
import styled from '@emotion/styled'
import { Colors, Fonts } from '../Styles/Themes'
import { SwitchOn } from './SwitchOn'
import { SwitchOff } from './SwitchOff'
import { SwitchMixed } from './SwitchMixed'

export interface ISwitchProps {
	/** Switch text */
	label?: string
	/** Switch is on/off. Use null to specify a mixed state. Default is off (false)*/
	checked?: boolean | null
	/** Switch includes mixed state */
	mixed?: boolean
	/** Switch is in a disabled state */
	disabled?: boolean
	/** Arial label text.  Default is label text */
	ariaLabel?: string
	/** Callback for on click handler */
	onClick: (checked: boolean | null, label: string) => void
}

export const Switch = (props: ISwitchProps) => {
	const [checked, setChecked] = React.useState(props.checked)
	const isMixed = checked === null || props.mixed

	React.useEffect(() => {
		setChecked(props.checked)
	}, [props.checked])

	const handleClick = () => {
		if (props.disabled) {
			return
		}

		let state: boolean | null = !checked

		if (isMixed) {
			state = checked ? null : checked === null ? false : true
		}

		setChecked(state)
		props.onClick(state, props.label)
	}

	return (
		<Container>
			<SwitchWrapper
				role="switch"
				aria-checked={checked === null ? 'mixed' : checked}
				aria-disabled={props.disabled}
				aria-label={props.ariaLabel ? props.ariaLabel : props.label}
				onClick={handleClick}
			>
				{checked ? (
					<SwitchOn disabled={props.disabled} />
				) : checked === null ? (
					<SwitchMixed disabled={props.disabled} />
				) : (
					<SwitchOff disabled={props.disabled} />
				)}
			</SwitchWrapper>
			<Label tabIndex={-1} style={{ color: props.disabled ? Colors.black.tint30 : Colors.black.tint80 }}>
				{props.label}
			</Label>
		</Container>
	)
}
const SwitchWrapper = styled.button`
	display: flex;
	justify-content: center;
	align-items: center;
	border-radius: 8px;
	outline: 0;
	border: 0;
	background: transparent;

	&:focus {
		box-shadow: inset 0 0 0 2px ${Colors.blue.primary}, 0 0 0 1px ${Colors.blue.primary};
	}

	/* hide focus styles on button click */
	:focus:not(:focus-visible) {
		outline: 0;
		box-shadow: none;
	}
`
const Container = styled.div`
	display: flex;
	align-items: center;
	height: 32px;
	min-height: 32px;
	font-size: 11px;
	font-family: ${Fonts.inter.family};
`

const Label = styled.div`
	margin-left: 8px;
`
Switch.defaultProps = {
	label: 'Switch',
	disabled: false,
	mixed: false,
	checked: false,
}
