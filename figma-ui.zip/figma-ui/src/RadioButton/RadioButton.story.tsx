import React from 'react'
import { Story, Meta } from '@storybook/react'
import { RadioButton } from '.'
import { IRadioButtonProps } from './RadioButton'
import styled from '@emotion/styled'

export default {
	title: 'Figma/Radio Button',
	component: RadioButton,
	argTypes: {
		name: {
			defaultValue: 'henryCavill',
		},
	},
} as Meta

export const Default: Story<IRadioButtonProps> = (props: IRadioButtonProps) => (
	<Container>
		<RadioButton label={'Snog'} {...props} />
		<RadioButton label={'Marry'} {...props} />
		<RadioButton label={'Avoid'} {...props} />
	</Container>
)

const Container = styled.div`
	display: flex;
	flex-direction: column;
`
