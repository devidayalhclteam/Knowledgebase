import * as React from 'react'
import styled from '@emotion/styled'
import { Colors, Fonts } from '../Styles/Themes'

export interface IRadioButtonProps {
	/** Radio label text */
	label?: string
	/** Group radio buttons together by assigning the same name */
	name?: string
	/** Arial label text,  Default is label */
	ariaLabel?: string
	/** Callback for click event */
	onClick?: () => void
}

export const RadioButton = (props: IRadioButtonProps) => {
	const handleClick = () => {
		return props.onClick && props.onClick()
	}

	const handleKeyDown = (e: React.KeyboardEvent) => {
		switch (e.key) {
			case 'Enter':
				const target = e.target as HTMLInputElement
				target.click()
				break

			default:
				break
		}
	}

	return (
		<Label>
			<Radio>
				<RadioIcon
					type="radio"
					name={props.name}
					value={props.label}
					aria-label={props.ariaLabel ? props.ariaLabel : props.label}
					onClick={handleClick}
					onKeyDown={handleKeyDown}
				/>
			</Radio>
			{props.label}
		</Label>
	)
}

const Label = styled.label`
	display: flex;
	align-items: center;
	height: 32px;
	font-size: 11px;
	font-family: ${Fonts.inter.family};
`

const Radio = styled.div`
	display: flex;
	align-items: center;
	justify-content: center;
	width: 32px;
	height: 32px;
`
const RadioIcon = styled.input`
	/* remove standard background appearance */
	-webkit-appearance: none;
	-moz-appearance: none;
	appearance: none;

	display: flex;
	width: 12px;
	height: 12px;
	padding: 2px;
	box-sizing: border-box;
	background-clip: content-box;
	border: 1px solid ${Colors.black.primary};
	background-color: transparent;
	border-radius: 100%;

	&:checked {
		background-color: ${Colors.black.primary};
	}

	&:focus {
		outline: 0;
		border: 1px solid ${Colors.blue.primary};
		box-shadow: 0 0 0 1px ${Colors.blue.primary};
	}
`
