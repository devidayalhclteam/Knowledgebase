import * as React from 'react'
import styled from '@emotion/styled'
import { Colors, Fonts } from '../Styles/Themes'

export interface IHyperlinkProps {
	/** Hyperlink text */
	text: string
	/** Add external link (optional) */
	url?: string
	/** Callback for click event */
	onClick?: () => void
}

export const Hyperlink = (props: IHyperlinkProps) => {
	const handleClick = () => {
		if (props.url) {
			window.open(props.url, '_blank')
		}

		if (props.onClick) {
			props.onClick()
		}
	}

	return (
		<Link role="link" tabIndex={0} aria-label={props.text} onClick={handleClick}>
			{props.text}
		</Link>
	)
}

/* Using <div> with role=link over <a>.  <a> is only accessible when href is filled */
const Link = styled.div`
	border-radius: 8px;
	text-decoration: none;
	color: ${Colors.blue.primary};
	cursor: default;
	font-size: 11px;
	font-family: ${Fonts.inter.family};

	/* hide focus styles on button click */
	:focus:not(:focus-visible) {
		outline: 0;
		box-shadow: none;
	}
`
