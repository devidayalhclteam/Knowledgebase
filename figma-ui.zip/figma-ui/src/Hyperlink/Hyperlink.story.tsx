import React from 'react'
import { Story, Meta } from '@storybook/react'
import { Hyperlink, IHyperlinkProps } from './Hyperlink'

export default {
	title: 'Figma/Hyperlink',
	component: Hyperlink,
	argTypes: {
		text: {
			defaultValue: 'Link',
		},
		url: {
			defaultValue: 'https://isitchristmas.com/',
		},
	},
} as Meta

export const Default: Story<IHyperlinkProps> = (props: IHyperlinkProps) => <Hyperlink {...props} onClick={() => console.log('click')} />
