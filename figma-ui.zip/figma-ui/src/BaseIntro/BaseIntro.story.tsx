import * as React from 'react'
import styled from '@emotion/styled'
import { Story, Meta } from '@storybook/react'
import { useArgs } from '@storybook/addons'
import { Colors } from '../Styles/Themes'

import { BaseIntro, IBaseIntro } from './BaseIntro'

export default {
	title: 'Figma/BaseIntro',
	component: BaseIntro,
	argTypes: {
		img: {
			defaultValue: true,
			control: { type: 'none' },
		},
		children: {
			defaultValue: false,
			control: {
				type: 'boolean',
			},
		},
		imgStyle: {
			control: { type: 'none' },
		},
	},
} as Meta

const Template: Story<IBaseIntro> = (props: IBaseIntro) => {
	const [args] = useArgs()
	return (
		<BaseIntro {...props} {...args} img={args.img && <Hero />}>
			{args.children && <InputField />}
		</BaseIntro>
	)
}

export const Default = Template.bind({})

const Hero = () => (
	<svg width="160" height="160" viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg">
		<rect width="160" height="160" fill="white" />
		<path
			d="M35 64C45.4934 64 54 55.4934 54 45C54 34.5066 45.4934 26 35 26C24.5066 26 16 34.5066 16 45C16 55.4934 24.5066 64 35 64Z"
			fill="#F0EFEE"
		/>
		<path
			d="M127.5 128C132.747 128 137 123.747 137 118.5C137 113.253 132.747 109 127.5 109C122.253 109 118 113.253 118 118.5C118 123.747 122.253 128 127.5 128Z"
			fill="#F0EFEE"
		/>
		<path
			d="M100.913 123.245L45.194 130.91C38.5969 131.817 32.512 127.204 31.6045 120.607L23.9397 64.8879C23.0322 58.2908 27.6454 52.206 34.2425 51.2984L89.9614 43.6336C96.5586 42.7261 102.643 47.3393 103.551 53.9364L111.216 109.655C112.123 116.252 107.51 122.337 100.913 123.245Z"
			fill="#8BF78B"
		/>
		<path
			d="M64.5657 64.3853C58.1469 65.2683 53.5983 71.1625 54.4813 77.5814C55.3643 84.0002 61.2586 88.5488 67.7665 87.6535C74.2745 86.7583 78.7339 80.8762 77.8387 74.3683C76.9557 67.9495 70.9845 63.5023 64.5657 64.3853Z"
			fill="white"
		/>
		<path
			d="M54.7397 93.9876C51.976 94.3678 50.143 96.8909 50.5109 99.5654L50.6336 100.457C51.2345 104.825 53.917 107.817 57.6759 109.389C61.3457 110.974 66.1164 111.317 71.0197 110.642C75.9229 109.968 80.3347 108.362 83.5295 105.833C86.712 103.215 88.4993 99.699 87.8984 95.3307L87.7757 94.4392C87.3956 91.6755 84.8725 89.8425 82.198 90.2104L54.7397 93.9876Z"
			fill="white"
		/>
		<path
			d="M84.8087 62.816V79.494C84.8087 80.6531 86.2253 81.2327 86.998 80.3955L104.771 62.6873L84.8087 62.816Z"
			fill="url(#paint0_radial)"
		/>
		<path
			d="M141.537 66.8347H87.3872C85.969 66.8347 84.8087 65.6806 84.8087 64.2701V30.9302C84.8087 29.5197 85.969 28.3656 87.3872 28.3656H141.537C142.955 28.3656 144.115 29.5197 144.115 30.9302V64.2701C144.115 65.6806 142.955 66.8347 141.537 66.8347Z"
			fill="#CF8FFF"
		/>
		<rect x="94.4259" y="37.9829" width="40.072" height="6.41152" fill="white" />
		<rect x="94.4259" y="50.8059" width="26.4475" height="6.41152" fill="white" />
		<defs>
			<radialGradient
				id="paint0_radial"
				cx="0"
				cy="0"
				r="1"
				gradientUnits="userSpaceOnUse"
				gradientTransform="translate(98.2098 64.0171) scale(9.18255)"
			>
				<stop stop-color="#B764FF" />
				<stop offset="1" stop-color="#CF8FFF" />
			</radialGradient>
		</defs>
	</svg>
)

const InputField = () => <Input placeholder={'Search for username or email'} />

const Input = styled.input`
	width: 100%;
	height: 32px;
	min-height: 32px;
	padding: 8px;
	margin-bottom: 16px;
	outline: 1px inset transparent;
	border: 1px solid ${Colors.silver.primary};
	font-size: 11px;
	border-radius: 2px;

	&:focus {
		padding-left: 7px;
		border: 2px solid ${Colors.blue.primary} !important;
	}

	&:hover:not(:focus) {
		border: 1px solid ${Colors.silver.primary} !important;
	}

	transition: border 250ms ease-in, padding 250ms ease-in;
`
