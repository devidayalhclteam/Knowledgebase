import * as React from 'react'
import styled from '@emotion/styled'
import { Fonts } from '../Styles/Themes'
import { Button, Hyperlink } from '..'

export interface IBaseIntro {
	/** Img can be  React.ReactNode of svg*/
	img?: React.ReactNode
	/** Header text */
	header: string
	/** Subheader text*/
	subheader: string
	/** Children can be any  React.ReactNode*/
	children?: React.ReactNode
	/** Button text */
	buttonLabel?: string
	/** Is footer is visible */
	isFooterVisible?: boolean
	/** Img style like top margin and bottom margin can be updated through this prop */
	imgStyle?: React.CSSProperties
	/** Arial label text for image description,  Default is Image */
	ariaLabel?: string
	/** Callback for on button click handler */
	onButtonClick?: () => void
	onLicenseClick?: () => void
	onPrivacyClick?: () => void
}

const defaultHeroStyle = {
	marginTop: '49px',
	marginBottom: '20px',
}

export const BaseIntro = (props: IBaseIntro) => {
	const heroStyle = props.img ? defaultHeroStyle : {}
	return (
		<Container>
			<Content>
				<Hero style={{ ...heroStyle, ...props.imgStyle }} role="img" aria-label={props.ariaLabel ? props.ariaLabel : 'Image'}>
					{props.img}
				</Hero>
				<Header>{props.header}</Header>
				<Body>{props.subheader}</Body>
				{props.children}
				{props.buttonLabel && <Button label={props.buttonLabel} onClick={props.onButtonClick} />}
			</Content>
			{props.isFooterVisible && (
				<Footer>
					© {new Date().getFullYear()} Microsoft. All rights reserved.
					<Hyperlink
						onClick={props.onLicenseClick}
						text="Microsoft Software License Terms"
						url="https://www.microsoft.com/en-us/useterms"
					/>
					<Hyperlink
						onClick={props.onPrivacyClick}
						text="Microsoft Privacy Statement"
						url="https://privacy.microsoft.com/en-us/privacystatement"
					/>
				</Footer>
			)}
		</Container>
	)
}

const Container = styled.div`
	display: flex;
	flex-direction: column;
	align-items: center;
	width: 100%;
`
const Content = styled.div`
	display: flex;
	flex-direction: column;
	align-items: center;
	overflow: hidden;
	overflow-y: auto;
	width: 100%;
	padding: 0px 16px;
	font-family: ${Fonts.inter.family};
`
const Hero = styled.div`
	display: flex;
	align-items: center;
	justify-content: center;
`

const Header = styled.h2`
	font-size: 14px;
	font-weight: normal;
	margin-bottom: 16px;
`
const Body = styled.div`
	margin-bottom: 16px;
	font-size: 11px;
	text-align: center;
`
const Footer = styled.div`
	display: flex;
	justify-content: flex-end;
	flex-direction: column;
	position: fixed;
	align-items: center;
	width: 100%;
	height: 65px;
	bottom: 0;
	padding: 16px;
	font-size: 11px;
`

BaseIntro.defaultProps = {
	header: 'Basic layout view',
	subheader: 'Introduction, About, Success and empty state screen layout view',
	isButtonVisible: false,
	isFooterVisible: false,
	checked: false,
}
