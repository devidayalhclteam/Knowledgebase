import * as React from 'react'
import styled from '@emotion/styled'

interface IThumbProps {
	color: string
	top: string
	left: string
}

export const Thumb = (props: IThumbProps) => <Container style={{ backgroundColor: props.color, top: props.top, left: props.left }} />

const Container = styled.div`
	position: absolute;
	width: 12px;
	height: 12px;
	background: white;
	border-radius: 100%;
	border: 2px solid white;
	transform: translate(-50%, -50%);
`
