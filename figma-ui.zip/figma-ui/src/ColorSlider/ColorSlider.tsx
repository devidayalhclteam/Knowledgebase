import * as React from 'react'
import styled from '@emotion/styled'
import { Thumb } from './Thumb'
import { MAX_COLOR_ALPHA, MAX_COLOR_HUE, IRGBA, IHSV } from '../Shared/consts'
import { Clamp } from '../Shared/Clamp'
import { Hsv2Rgb } from '../Shared/Hsv2Rgb'
import { Rgb2Hsv } from '../Shared/Rgb2Hsv'

export interface IColorSliderProps {
	/** Default slider color */
	color?: IRGBA
	/** Type of slider */
	type?: SliderType
	/** Callback when color is changed */
	updateColor?: (color: IRGBA) => void
}

export enum SliderType {
	Hue = 'Hue',
	Alpha = 'Alpha',
	Thumb = 'Thumb',
}

const hueStyle = {
	background: `linear-gradient(${[
		'to left',
		'red 0',
		'#f09 10%',
		'#cd00ff 20%',
		'#3200ff 30%',
		'#06f 40%',
		'#00fffd 50%',
		'#0f6 60%',
		'#35ff00 70%',
		'#cdff00 80%',
		'#f90 90%',
		'red 100%',
	].join(',')})`,
}

const alphaStyle = {
	backgroundImage:
		'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAJUlEQVQYV2N89erVfwY0ICYmxoguxjgUFKI7GsTH5m4M3w1ChQC1/Ca8i2n1WgAAAABJRU5ErkJggg==)',
}

export const ColorSlider = (props: IColorSliderProps) => {
	const ref = React.useRef<HTMLDivElement>(null)
	const [color, setColor] = React.useState<IRGBA>(props.color ? props.color : { r: 255, g: 0, b: 0, a: 1 })
	const [percent, setPercent] = React.useState(0)
	const [isDragging, setIsDragging] = React.useState(false)

	const isSameColor =
		`${props.color.r},${props.color.g},${props.color.b},${props.color.a}` === `${color.r},${color.g},${color.b},${color.a}`
	const isAlpha = props.type && props.type === SliderType.Alpha
	const maxValue = isAlpha ? MAX_COLOR_ALPHA : MAX_COLOR_HUE
	const hsv = Rgb2Hsv(color)
	const currentValue = isAlpha ? percent : hsv.h
	const thumbColor = isAlpha ? `rgba(${color.r},${color.g},${color.b},${color.a})` : getFullSaturatedColor(hsv)

	React.useEffect(() => {
		document.addEventListener('mousemove', handleMouseMove)
		document.addEventListener('mouseup', handleMouseUp)

		return () => {
			// Unbind the event listener on clean up
			document.removeEventListener('mousemove', handleMouseMove)
			document.removeEventListener('mouseup', handleMouseUp)
		}
	}, [isDragging])

	React.useEffect(() => {
		if (color) {
			const value = isAlpha ? color.a * 100 : Rgb2Hsv(color).h
			const maxValue = isAlpha ? MAX_COLOR_ALPHA : MAX_COLOR_HUE
			const p = (100 * value) / maxValue
			setPercent(p)

			if (props.updateColor && !isSameColor) {
				props.updateColor(color)
			}
		}
	}, [color])

	React.useEffect(() => {
		if (props.color && !isSameColor) {
			setColor(props.color)
		}
	}, [props.color])

	const handleKeyDown = (e: React.KeyboardEvent) => {
		let value = currentValue
		const increment = e.shiftKey ? 10 : 1

		switch (e.key) {
			case 'ArrowLeft':
				const left = value - increment
				value = left >= 0 ? left : 0
				break
			case 'ArrowRight':
				const right = value + increment
				value = right <= maxValue ? right : maxValue
				break
			default:
				break
		}

		if (isAlpha) {
			setColor({ ...color, a: value / 100 })
		} else {
			const rgb = Hsv2Rgb(value, hsv.s, hsv.v)
			setColor({ ...rgb, a: color.a })
		}
	}

	const handleMouseDown = (e: React.MouseEvent) => {
		setIsDragging(true)
		const newColor = GetNewColor(e)

		if (newColor) {
			setColor(newColor)
		}
	}

	const GetNewColor = (e: React.MouseEvent): IRGBA => {
		const rectSize = ref.current.getBoundingClientRect()

		const currentPercent = (e.clientX - rectSize.left) / rectSize.width
		const newVal = Clamp(Math.round(currentPercent * maxValue), maxValue)

		setPercent((100 * newVal) / maxValue)

		if (isAlpha) {
			return { ...color, a: newVal / 100 }
		}

		const rgb = Hsv2Rgb(newVal, hsv.s, hsv.v)
		return { ...rgb, a: color.a }
	}

	const handleMouseUp = () => {
		setIsDragging(false)
	}

	const handleMouseMove = (e: any) => {
		if (isDragging) {
			handleMouseDown(e)
		}
	}

	// Show thumb only
	if (props.type === SliderType.Thumb) {
		return <Thumb color={thumbColor} top="50%" left="initial" />
	}

	return (
		<Container
			ref={ref}
			role="slider"
			tabIndex={0}
			aria-valuenow={currentValue}
			// Narrator doesn't read aria-valuenow properly
			aria-valuetext={String(currentValue)}
			aria-valuemin={0}
			aria-valuemax={maxValue}
			aria-label={props.type}
			onKeyDown={handleKeyDown}
			onMouseDown={handleMouseDown}
			style={isAlpha ? alphaStyle : hueStyle}
		>
			{isAlpha && (
				<Transparency
					style={{
						background: `linear-gradient(to right, transparent, rgb(${(color as IRGBA).r},${(color as IRGBA).g},${
							(color as IRGBA).b
						}))`,
					}}
				/>
			)}

			<Thumb color={thumbColor} top="50%" left={percent + '%'} />
		</Container>
	)
}

const getFullSaturatedColor = (hsv: IHSV) => {
	const rgb = Hsv2Rgb(hsv.h, 100, 100)
	return `rgb(${rgb.r},${rgb.g},${rgb.b})`
}

const Container = styled.div`
	position: relative;
	height: 12px;
	border-radius: 10px;
	box-sizing: content-box;

	/* hide focus styles on button click */
	:focus:not(:focus-visible) {
		outline: 0;
		box-shadow: none;
	}
`

const Transparency = styled.div`
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	border-radius: 10px;
`

ColorSlider.defaultProps = {
	color: 'rgba(255,0,0,1)',
	type: SliderType.Hue,
}
