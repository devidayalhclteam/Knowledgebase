import React from 'react'
import { Story, Meta } from '@storybook/react'
import { useArgs } from '@storybook/client-api'
import { IRGBA } from '../Shared/consts'
import { Rgba2Interface } from '../Shared/Rgba2Interface'
import { ColorSlider, IColorSliderProps } from './ColorSlider'

export default {
	title: 'Figma/ColorSlider',
	component: ColorSlider,
	argTypes: {
		color: {
			control: { type: 'color' },
		},
		type: {
			control: { type: 'select', options: ['Hue', 'Alpha', 'Thumb'] },
		},
	},
} as Meta

const Template: Story<IColorSliderProps> = (props: IColorSliderProps) => {
	const [args, updateArgs] = useArgs()
	const color: IRGBA = args.color && args.color.includes('rgb') ? Rgba2Interface(args.color) : args.color

	return (
		<ColorSlider
			{...props}
			{...args}
			color={color}
			updateColor={(color: IRGBA) => {
				updateArgs({ color: `rgba(${color.r},${color.g},${color.b},${color.a})` })
			}}
		/>
	)
}
export const Default = Template.bind({})
